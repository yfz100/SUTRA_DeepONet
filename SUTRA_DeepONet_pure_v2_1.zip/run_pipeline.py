"""SUTRA–DeepONet pure-supervised v2.1 unified pipeline.

User workflow:
1. Edit only the parameter block near the top of this file.
2. Run: python run_pipeline.py
3. The pipeline performs fail-closed data checks, training, one-time full inference,
   metrics generation, run verification, and optional diagnostic plots.
4. Publication figures are independent scripts under paper_plots/ and NEVER rerun the model.
"""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path
from typing import Any

from src.utils import collect_environment, ensure_dir, load_yaml, save_json, save_yaml, timestamp


# =============================================================================
# A. 最常改参数区
# =============================================================================

PROJECT_ROOT = Path(__file__).resolve().parent

# --- Canonical SUTRA reference library ---------------------------------------
REFERENCE_LIBRARY_ROOT = Path(
    r"D:\办公\同济大学\5、试验\ModelMuse文件\SUTRA22_manifest_reference_v2_1\reference_library"
)
SOURCE_PROCESSED_DIR = REFERENCE_LIBRARY_ROOT / "source_range" / "processed"
OOD_PROCESSED_DIR = REFERENCE_LIBRARY_ROOT / "higher_amplitude" / "processed"
MANIFEST_PATH = REFERENCE_LIBRARY_ROOT / "SUTRA_case_manifest_v2.1_2026-09-29.csv"

# --- Run output ---------------------------------------------------------------
RUN_ROOT = PROJECT_ROOT / "runs"
RUN_NAME_PREFIX = "pure_supervised_v2_1"
USE_TIMESTAMP_IN_RUN_NAME = True

# If DO_TRAIN=False and you want to continue an existing run, set this path.
# Downstream stages then use that run's saved config_used.yaml.
EXISTING_RUN_DIR: str | None = None

# --- Pipeline stages ----------------------------------------------------------
DO_PREFLIGHT = True
DO_TRAIN = True
DO_EXPORT_SOURCE = False
DO_EVALUATE_SOURCE = False
DO_EXPORT_OOD = True
DO_EVALUATE_OOD = False
DO_DIAGNOSTIC_PLOTS = True
DO_VERIFY_RUN = False

CHECKPOINT_FOR_EXPORT = "best"  # best or last
OVERWRITE_EXPORTS = False

# --- Reproducibility / device -------------------------------------------------
SEED = 20260602
DEVICE = "auto"                 # auto, cpu, cuda, cuda:0, ...
CUDA_VISIBLE_DEVICES: str | None = None

# --- Physics / trunk ----------------------------------------------------------
TIDAL_PERIOD_S = 43200.0
X_SCALE_M = 10.0
Z_SCALE_M = 4.0
T_SCALE_S = 259200.0

# --- DeepONet architecture ----------------------------------------------------
LATENT_DIM = 256
BRANCH_HIDDEN = [128, 128, 128]
TRUNK_HIDDEN = [256, 256, 256, 256]
ACTIVATION = "silu"
DROPOUT = 0.0

# --- Training -----------------------------------------------------------------
EPOCHS = 1    #800
BATCH_SIZE = 4096   #8192
NUM_SAMPLES_PER_EPOCH = 16384   #524288
LEARNING_RATE = 1.0e-3
WEIGHT_DECAY = 1.0e-6
GRAD_CLIP_NORM = 1.0
LOSS_WEIGHTS = [1.0, 1.0]  # normalized pressure head : normalized concentration

VAL_EVERY_EPOCHS = 5
VAL_POINTS_PER_CASE = 10602  # 24 * 10602 = 254448 fixed validation points
VALIDATION_SEED = 20260602 + 1000003
EARLY_STOPPING_PATIENCE_EPOCHS = 120

USE_REDUCE_ON_PLATEAU = True
SCHEDULER_FACTOR = 0.5
SCHEDULER_PATIENCE = 6
MIN_LR = 1.0e-5

# --- Full inference ------------------------------------------------------------
INFERENCE_BATCH_SIZE = 65536

# --- Normalization -------------------------------------------------------------
NORMALIZATION_EPS = 1.0e-12

# =============================================================================
# B. 参数区结束
# =============================================================================


def make_run_name() -> str:
    return f"{RUN_NAME_PREFIX}_{timestamp()}" if USE_TIMESTAMP_IN_RUN_NAME else RUN_NAME_PREFIX


def build_config() -> dict[str, Any]:
    return {
        "project": {
            "name": "SUTRA_DeepONet_pure_v2_1",
            "version": "2.1.2",
            "description": "Pure-supervised two-output DeepONet for formal SUTRA Canonical Reference Data Schema v2.1 with hardware/timing instrumentation",
            "seed": int(SEED),
        },
        "paths": {
            "source_processed_dir": str(SOURCE_PROCESSED_DIR.expanduser().resolve()),
            "ood_processed_dir": str(OOD_PROCESSED_DIR.expanduser().resolve()),
            "manifest_path": str(MANIFEST_PATH.expanduser().resolve()),
            "run_root": str(Path(RUN_ROOT).expanduser().resolve()),
        },
        "physics": {
            "tidal_period_s": float(TIDAL_PERIOD_S),
            "x_scale_m": float(X_SCALE_M),
            "z_scale_m": float(Z_SCALE_M),
            "t_scale_s": float(T_SCALE_S),
            "pressure_head_definition": "pressure_pa / 9810.0",
            "branch_order": ["amplitude_m", "h_land_m"],
            "trunk_order": ["x_scaled", "z_scaled", "t_scaled", "sin_wt", "cos_wt", "sin_2wt", "cos_2wt"],
            "target_order": ["pressure_head_m", "concentration"],
        },
        "normalization": {
            "fit_library": "source_range",
            "fit_split": "train",
            "eps": float(NORMALIZATION_EPS),
        },
        "model": {
            "branch_dim": 2,
            "trunk_dim": 7,
            "latent_dim": int(LATENT_DIM),
            "output_dim": 2,
            "branch_hidden": list(BRANCH_HIDDEN),
            "trunk_hidden": list(TRUNK_HIDDEN),
            "activation": ACTIVATION,
            "dropout": float(DROPOUT),
        },
        "training": {
            "device": DEVICE,
            "epochs": int(EPOCHS),
            "batch_size": int(BATCH_SIZE),
            "num_samples_per_epoch": int(NUM_SAMPLES_PER_EPOCH),
            "learning_rate": float(LEARNING_RATE),
            "weight_decay": float(WEIGHT_DECAY),
            "grad_clip_norm": float(GRAD_CLIP_NORM),
            "loss_weights": [float(v) for v in LOSS_WEIGHTS],
            "val_every_epochs": int(VAL_EVERY_EPOCHS),
            "val_points_per_case": int(VAL_POINTS_PER_CASE),
            "validation_seed": int(VALIDATION_SEED),
            "early_stopping_patience_epochs": int(EARLY_STOPPING_PATIENCE_EPOCHS),
            "scheduler": {
                "use_reduce_on_plateau": bool(USE_REDUCE_ON_PLATEAU),
                "factor": float(SCHEDULER_FACTOR),
                "patience": int(SCHEDULER_PATIENCE),
                "min_lr": float(MIN_LR),
            },
        },
        "inference": {
            "batch_size": int(INFERENCE_BATCH_SIZE),
            "checkpoint": CHECKPOINT_FOR_EXPORT,
        },
        "metrics": {
            "physical_space": True,
            "reduction_dtype": "float64",
            "names": ["rmse", "mae", "rl2e", "bias", "max_abs_error", "p95_abs_error", "p99_abs_error"],
        },
    }


def run_module(module: str, args: list[str], env: dict[str, str]) -> None:
    cmd = [sys.executable, "-m", module, *args]
    print("\n>>> " + " ".join(cmd))
    subprocess.run(cmd, cwd=PROJECT_ROOT, env=env, check=True)


def main() -> None:
    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    if CUDA_VISIBLE_DEVICES is not None:
        env["CUDA_VISIBLE_DEVICES"] = str(CUDA_VISIBLE_DEVICES)
        # Keep parent-side hardware metadata consistent with the subprocesses.
        os.environ["CUDA_VISIBLE_DEVICES"] = str(CUDA_VISIBLE_DEVICES)

    if EXISTING_RUN_DIR:
        run_dir = Path(EXISTING_RUN_DIR).expanduser().resolve()
        config_path = run_dir / "config_used.yaml"
        if not config_path.exists():
            raise FileNotFoundError(config_path)
        if DO_TRAIN and (run_dir / "checkpoints" / "best.pt").exists():
            raise FileExistsError(
                "DO_TRAIN=True but the existing run already has best.pt. "
                "Automatic training resume/overwrite is intentionally disabled."
            )
        print(f"Using frozen existing-run config: {config_path}")
    else:
        # A new run directory can be created for preflight-only, smoke, or full training.
        run_dir = ensure_dir(Path(RUN_ROOT) / make_run_name())
        config_path = run_dir / "config_used.yaml"
        if config_path.exists():
            raise FileExistsError(f"Refusing to overwrite existing run config: {config_path}")
        save_yaml(build_config(), config_path)
        env_info = collect_environment()
        env_info["requested_device"] = DEVICE
        env_info["cuda_visible_devices_for_subprocess"] = CUDA_VISIBLE_DEVICES
        save_json(env_info, run_dir / "environment.json")

    print(f"Run directory: {run_dir}")

    if DO_PREFLIGHT:
        preflight_args = ["--config", str(config_path), "--run-dir", str(run_dir)]
        # Data-only preflight must work without PyTorch. Require torch/model smoke
        # only when this invocation also requests a model-dependent stage.
        if DO_TRAIN or DO_EXPORT_SOURCE or DO_EXPORT_OOD:
            preflight_args.append("--require-torch")
        run_module("scripts.quick_check", preflight_args, env)

    if DO_TRAIN:
        run_module("scripts.train", ["--config", str(config_path), "--run-dir", str(run_dir)], env)

    export_extra = ["--overwrite"] if OVERWRITE_EXPORTS else []
    if DO_EXPORT_SOURCE:
        run_module(
            "scripts.export_predictions",
            ["--config", str(config_path), "--run-dir", str(run_dir), "--library", "source", "--checkpoint", CHECKPOINT_FOR_EXPORT, *export_extra],
            env,
        )
    if DO_EVALUATE_SOURCE:
        run_module("scripts.evaluate_exports", ["--config", str(config_path), "--run-dir", str(run_dir), "--library", "source"], env)

    if DO_EXPORT_OOD:
        run_module(
            "scripts.export_predictions",
            ["--config", str(config_path), "--run-dir", str(run_dir), "--library", "higher_amplitude", "--checkpoint", CHECKPOINT_FOR_EXPORT, *export_extra],
            env,
        )
    if DO_EVALUATE_OOD:
        run_module("scripts.evaluate_exports", ["--config", str(config_path), "--run-dir", str(run_dir), "--library", "higher_amplitude"], env)

    if DO_DIAGNOSTIC_PLOTS:
        run_module("diagnostics.plot_training_history", ["--run-dir", str(run_dir)], env)

    if DO_VERIFY_RUN:
        run_module("scripts.verify_run", ["--config", str(config_path), "--run-dir", str(run_dir)], env)

    print("\nPipeline completed successfully.")
    print(f"Run directory: {run_dir}")


if __name__ == "__main__":
    main()

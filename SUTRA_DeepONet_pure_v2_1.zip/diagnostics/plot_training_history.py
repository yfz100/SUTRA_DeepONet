from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--run-dir", required=True)
    args = p.parse_args()
    run = Path(args.run_dir)
    csv_path = run / "training" / "training_history.csv"
    df = pd.read_csv(csv_path)
    out = run / "diagnostics"
    out.mkdir(parents=True, exist_ok=True)

    fig, ax = plt.subplots(figsize=(7.2, 4.6))
    ax.semilogy(df["epoch"], df["train_loss_norm"], label="Training")
    if "val_combined_mse_norm" in df.columns:
        valid = df["val_combined_mse_norm"].notna()
        ax.semilogy(df.loc[valid, "epoch"], df.loc[valid, "val_combined_mse_norm"], marker="o", markersize=3, label="Validation")
    ax.set_xlabel("Epoch")
    ax.set_ylabel("Normalized MSE")
    ax.grid(True, linestyle="--", alpha=0.25)
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(out / "training_history.png", dpi=300)
    fig.savefig(out / "training_history.pdf")
    plt.close(fig)


if __name__ == "__main__":
    main()

# Version verification — pure-supervised v2.1.2

Patch purpose: add hardware provenance and synchronized wall-clock timing before the formal baseline run.

Unchanged scientific / ML logic from v2.1.1:

- canonical source/OOD data contract;
- branch `[A, H_land]` and 7-D trunk;
- DeepONet architecture and output combination;
- train/validation/test/OOD split authority;
- train-only normalizer;
- uniform random training sampler;
- fixed validation sample;
- normalized two-output MSE and loss weights;
- AdamW, gradient clipping, scheduler and early stopping;
- best-checkpoint criterion;
- physical-space prediction and metrics definitions;
- paper plotting interfaces.

Instrumentation additions only:

1. `environment.json` records best-effort CPU/RAM/GPU/driver/cuDNN information.
2. `training_history.csv` records synchronized train/validation/epoch timings and throughput.
3. `training/timing_summary.json` records aggregate training wall times.
4. `training_summary.json` references the timing summary and stores key total times.
5. full exports write `inference_timing.csv` and `inference_timing_summary.json`.
6. CUDA timing boundaries explicitly synchronize the device.

The instrumentation patch must not be interpreted as changing model results. It only observes runtime/hardware metadata.

from __future__ import annotations

import math
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch

from .features import build_trunk_features
from .losses import weighted_component_mse
from .model import build_model
from .normalization import fit_train_only_normalizer, save_normalizer
from .reference_data import CanonicalReferenceData
from .sampling import UniformTripletBatchSampler, create_fixed_validation_indices
from .utils import ensure_dir, save_json, set_seed, sha256_file, synchronize_device


@torch.no_grad()
def evaluate_fixed_validation(
    model: torch.nn.Module,
    data: CanonicalReferenceData,
    normalizer,
    trunk_all: np.ndarray,
    sample: dict[str, np.ndarray],
    batch_size: int,
    device: torch.device,
    loss_weights: torch.Tensor,
) -> dict[str, float]:
    model.eval()
    ci = np.asarray(sample["case_index"], dtype=np.int64)
    ti = np.asarray(sample["time_index"], dtype=np.int64)
    ni = np.asarray(sample["node_index"], dtype=np.int64)
    branch_norm_all = normalizer.branch_to_norm(np.asarray(data.branch))

    sum_sq = np.zeros(2, dtype=np.float64)
    n = 0
    for start in range(0, len(ci), int(batch_size)):
        end = min(start + int(batch_size), len(ci))
        b_np = np.asarray(branch_norm_all[ci[start:end]], dtype=np.float32)
        x_np = np.asarray(trunk_all[ti[start:end], ni[start:end]], dtype=np.float32)
        y_raw = data.get_target_batch(ci[start:end], ti[start:end], ni[start:end])
        y_np = normalizer.target_to_norm(y_raw)
        b = torch.from_numpy(b_np).to(device, non_blocking=True)
        x = torch.from_numpy(x_np).to(device, non_blocking=True)
        y = torch.from_numpy(y_np).to(device, non_blocking=True)
        pred = model(b, x)
        diff = pred - y
        sum_sq += torch.sum(diff * diff, dim=0).detach().cpu().numpy().astype(np.float64)
        n += end - start

    comp = sum_sq / max(n, 1)
    w = loss_weights.detach().cpu().numpy().astype(np.float64)
    combined = float(np.sum(w * comp) / np.sum(w))
    return {
        "combined_mse_norm": combined,
        "pressure_head_mse_norm": float(comp[0]),
        "concentration_mse_norm": float(comp[1]),
        "num_points": int(n),
    }


def train_model(
    config: dict[str, Any],
    source: CanonicalReferenceData,
    run_dir: str | Path,
    device: torch.device,
) -> dict[str, Any]:
    """Train the formal model and record synchronized wall-clock timings.

    Timing instrumentation is observational only. CUDA is synchronized at the
    boundaries of measured GPU phases so host wall-clock measurements do not
    under-report asynchronous GPU work. No model, loss, optimizer, sampling,
    normalization, or checkpoint-selection logic is changed by the timers.
    """
    function_wall_start = time.perf_counter()

    run_dir = Path(run_dir)
    ckpt_dir = ensure_dir(run_dir / "checkpoints")
    norm_dir = ensure_dir(run_dir / "normalization")
    sampling_dir = ensure_dir(run_dir / "sampling")
    training_dir = ensure_dir(run_dir / "training")

    seed = int(config["project"]["seed"])
    set_seed(seed)

    norm, norm_meta = fit_train_only_normalizer(
        source,
        config["physics"],
        eps=float(config.get("normalization", {}).get("eps", 1e-12)),
    )
    save_normalizer(norm, norm_meta, norm_dir)

    trunk_all = build_trunk_features(source, norm, float(config["physics"]["tidal_period_s"]))
    train_sampler = UniformTripletBatchSampler(source, norm, trunk_all, "train", seed=seed)

    tr_cfg = config["training"]
    val_sample_path = sampling_dir / "validation_sample_indices.npz"
    val_sample = create_fixed_validation_indices(
        source,
        points_per_case=int(tr_cfg["val_points_per_case"]),
        seed=int(tr_cfg.get("validation_seed", seed + 1000003)),
        path=val_sample_path,
        overwrite=False,
    )

    model = build_model(config).to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=float(tr_cfg["learning_rate"]),
        weight_decay=float(tr_cfg.get("weight_decay", 0.0)),
    )
    scheduler = None
    sch_cfg = tr_cfg.get("scheduler", {})
    if bool(sch_cfg.get("use_reduce_on_plateau", True)):
        scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
            optimizer,
            mode="min",
            factor=float(sch_cfg.get("factor", 0.5)),
            patience=int(sch_cfg.get("patience", 6)),
            min_lr=float(sch_cfg.get("min_lr", 1e-5)),
        )

    loss_weights = torch.tensor(tr_cfg.get("loss_weights", [1.0, 1.0]), dtype=torch.float32, device=device)
    batch_size = int(tr_cfg["batch_size"])
    samples_per_epoch = int(tr_cfg["num_samples_per_epoch"])
    n_batches = int(math.ceil(samples_per_epoch / batch_size))
    epochs = int(tr_cfg["epochs"])
    val_every = int(tr_cfg.get("val_every_epochs", 5))
    val_batch = int(config["inference"].get("batch_size", 65536))
    patience_epochs = int(tr_cfg.get("early_stopping_patience_epochs", 120))
    grad_clip = float(tr_cfg.get("grad_clip_norm", 0.0))

    best_val = float("inf")
    best_epoch = -1
    history: list[dict[str, Any]] = []

    synchronize_device(device)
    training_loop_wall_start = time.perf_counter()
    setup_wall_time_s = float(training_loop_wall_start - function_wall_start)

    for epoch in range(1, epochs + 1):
        epoch_wall_start = time.perf_counter()
        model.train()
        sum_loss = 0.0
        sum_comp = np.zeros(2, dtype=np.float64)
        seen = 0

        synchronize_device(device)
        train_phase_start = time.perf_counter()
        for batch_no in range(n_batches):
            remaining = samples_per_epoch - batch_no * batch_size
            current_bs = min(batch_size, remaining)
            if current_bs <= 0:
                break
            sample = train_sampler.batch(epoch=epoch, batch_number=batch_no, size=current_bs)
            branch = torch.from_numpy(sample.branch).to(device, non_blocking=True)
            trunk = torch.from_numpy(sample.trunk).to(device, non_blocking=True)
            target = torch.from_numpy(sample.target).to(device, non_blocking=True)

            optimizer.zero_grad(set_to_none=True)
            pred = model(branch, trunk)
            loss, comp = weighted_component_mse(pred, target, loss_weights)
            loss.backward()
            if grad_clip > 0:
                torch.nn.utils.clip_grad_norm_(model.parameters(), grad_clip)
            optimizer.step()

            bs = int(branch.shape[0])
            sum_loss += float(loss.detach().cpu()) * bs
            sum_comp += comp.detach().cpu().numpy().astype(np.float64) * bs
            seen += bs
        synchronize_device(device)
        train_phase_time_s = float(time.perf_counter() - train_phase_start)

        row: dict[str, Any] = {
            "epoch": epoch,
            "train_loss_norm": sum_loss / max(seen, 1),
            "train_pressure_head_mse_norm": float(sum_comp[0] / max(seen, 1)),
            "train_concentration_mse_norm": float(sum_comp[1] / max(seen, 1)),
            "learning_rate": float(optimizer.param_groups[0]["lr"]),
            "train_num_samples": int(seen),
            "train_phase_time_s": train_phase_time_s,
            "train_samples_per_s": float(seen / train_phase_time_s) if train_phase_time_s > 0 else float("nan"),
            "validation_time_s": float("nan"),
        }

        do_val = epoch == 1 or epoch % val_every == 0 or epoch == epochs
        if do_val:
            synchronize_device(device)
            validation_start = time.perf_counter()
            val = evaluate_fixed_validation(
                model, source, norm, trunk_all, val_sample, val_batch, device, loss_weights
            )
            synchronize_device(device)
            validation_time_s = float(time.perf_counter() - validation_start)
            row["validation_time_s"] = validation_time_s
            row["validation_points_per_s"] = (
                float(val["num_points"] / validation_time_s) if validation_time_s > 0 else float("nan")
            )

            val_score = float(val["combined_mse_norm"])
            row.update({f"val_{k}": v for k, v in val.items()})
            if scheduler is not None:
                scheduler.step(val_score)
            is_best = val_score < best_val
            if is_best:
                best_val = val_score
                best_epoch = epoch
                torch.save(
                    {
                        "epoch": epoch,
                        "model_state_dict": model.state_dict(),
                        "optimizer_state_dict": optimizer.state_dict(),
                        "best_val_combined_mse_norm": best_val,
                        "config": config,
                    },
                    ckpt_dir / "best.pt",
                )
            flag = " [best]" if is_best else ""
            print(
                f"Epoch {epoch:04d}: train={row['train_loss_norm']:.6e}, "
                f"val={val_score:.6e}, lr={row['learning_rate']:.3e}, "
                f"train_time={train_phase_time_s:.2f}s, val_time={validation_time_s:.2f}s{flag}"
            )
        else:
            print(
                f"Epoch {epoch:04d}: train={row['train_loss_norm']:.6e}, "
                f"lr={row['learning_rate']:.3e}, train_time={train_phase_time_s:.2f}s"
            )

        # Preserve the original checkpoint behavior: last.pt is written every epoch.
        torch.save(
            {
                "epoch": epoch,
                "model_state_dict": model.state_dict(),
                "optimizer_state_dict": optimizer.state_dict(),
                "best_val_combined_mse_norm": best_val,
                "config": config,
            },
            ckpt_dir / "last.pt",
        )

        synchronize_device(device)
        row["epoch_wall_time_s"] = float(time.perf_counter() - epoch_wall_start)
        row["elapsed_training_wall_time_s"] = float(time.perf_counter() - training_loop_wall_start)
        history.append(row)
        pd.DataFrame(history).to_csv(training_dir / "training_history.csv", index=False, encoding="utf-8-sig")

        if best_epoch > 0 and (epoch - best_epoch) >= patience_epochs:
            print(f"Early stopping at epoch {epoch}; best_epoch={best_epoch}, best_val={best_val:.6e}")
            break

    synchronize_device(device)
    training_loop_wall_time_s = float(time.perf_counter() - training_loop_wall_start)

    if best_epoch < 0 or not (ckpt_dir / "best.pt").exists():
        raise RuntimeError("Training ended without a best checkpoint")

    train_times = np.asarray([float(r["train_phase_time_s"]) for r in history], dtype=np.float64)
    val_times = np.asarray(
        [float(r["validation_time_s"]) for r in history if np.isfinite(float(r["validation_time_s"]))],
        dtype=np.float64,
    )
    epoch_times = np.asarray([float(r["epoch_wall_time_s"]) for r in history], dtype=np.float64)

    train_model_total_wall_time_s = float(time.perf_counter() - function_wall_start)
    timing_summary = {
        "timing_instrumentation_version": "1.0",
        "timing_clock": "time.perf_counter",
        "cuda_synchronized_at_gpu_phase_boundaries": bool(device.type == "cuda"),
        "device": str(device),
        "setup_wall_time_s": setup_wall_time_s,
        "training_loop_wall_time_s": training_loop_wall_time_s,
        "training_loop_wall_time_h": training_loop_wall_time_s / 3600.0,
        "train_model_total_wall_time_s": train_model_total_wall_time_s,
        "train_model_total_wall_time_h": train_model_total_wall_time_s / 3600.0,
        "train_phase_total_time_s": float(train_times.sum()),
        "validation_total_time_s": float(val_times.sum()) if val_times.size else 0.0,
        "mean_train_phase_time_per_epoch_s": float(train_times.mean()),
        "median_train_phase_time_per_epoch_s": float(np.median(train_times)),
        "mean_epoch_wall_time_s": float(epoch_times.mean()),
        "median_epoch_wall_time_s": float(np.median(epoch_times)),
        "validation_events": int(val_times.size),
        "epochs_completed": int(history[-1]["epoch"]),
    }
    save_json(timing_summary, training_dir / "timing_summary.json")

    summary = {
        "best_epoch": int(best_epoch),
        "best_val_combined_mse_norm": float(best_val),
        "epochs_completed": int(history[-1]["epoch"]),
        "train_cases": int(len(source.get_split_indices("train"))),
        "validation_cases": int(len(source.get_split_indices("validation"))),
        "validation_points_per_case": int(tr_cfg["val_points_per_case"]),
        "validation_total_points": int(len(val_sample["case_index"])),
        "normalizer_sha256": sha256_file(norm_dir / "normalizer.json"),
        "validation_sample_sha256": sha256_file(val_sample_path),
        "timing_instrumentation_version": "1.0",
        "training_loop_wall_time_s": training_loop_wall_time_s,
        "training_loop_wall_time_h": training_loop_wall_time_s / 3600.0,
        "train_model_total_wall_time_s": train_model_total_wall_time_s,
        "train_model_total_wall_time_h": train_model_total_wall_time_s / 3600.0,
        "timing_summary_sha256": sha256_file(training_dir / "timing_summary.json"),
    }
    save_json(summary, training_dir / "training_summary.json")
    return summary

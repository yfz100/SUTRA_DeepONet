from __future__ import annotations

from pathlib import Path
from typing import Any


def validate_config(cfg: dict[str, Any]) -> None:
    required_top = ["project", "paths", "physics", "model", "training", "inference", "metrics"]
    missing = [k for k in required_top if k not in cfg]
    if missing:
        raise ValueError(f"Config missing top-level keys: {missing}")

    paths = cfg["paths"]
    for key in ["source_processed_dir", "ood_processed_dir", "manifest_path", "run_root"]:
        if key not in paths or not str(paths[key]).strip():
            raise ValueError(f"Config paths.{key} is required")

    physics = cfg["physics"]
    for key in ["tidal_period_s", "x_scale_m", "z_scale_m", "t_scale_s"]:
        if float(physics[key]) <= 0:
            raise ValueError(f"physics.{key} must be > 0")

    model = cfg["model"]
    if int(model.get("branch_dim", -1)) != 2:
        raise ValueError("Pure-supervised v2.1 requires model.branch_dim = 2 for [A, H_land]")
    if int(model.get("trunk_dim", -1)) != 7:
        raise ValueError("Pure-supervised v2.1 requires model.trunk_dim = 7")
    if int(model.get("output_dim", -1)) != 2:
        raise ValueError("Pure-supervised v2.1 requires model.output_dim = 2")

    tr = cfg["training"]
    for key in ["epochs", "batch_size", "num_samples_per_epoch", "val_points_per_case"]:
        if int(tr[key]) <= 0:
            raise ValueError(f"training.{key} must be positive")
    if int(tr["num_samples_per_epoch"]) < int(tr["batch_size"]):
        raise ValueError("num_samples_per_epoch must be >= batch_size")
    if float(tr["learning_rate"]) <= 0:
        raise ValueError("training.learning_rate must be > 0")

    loss_weights = tr.get("loss_weights", [1.0, 1.0])
    if len(loss_weights) != 2 or any(float(x) < 0 for x in loss_weights) or sum(float(x) for x in loss_weights) <= 0:
        raise ValueError("training.loss_weights must contain two nonnegative values with positive sum")


def normalized_config_for_hash(cfg: dict[str, Any]) -> dict[str, Any]:
    """Return the semantically important config for reproducibility hashing.

    Runtime-only switches such as pipeline stages are intentionally retained if present;
    caller can remove them if a model-only hash is desired.
    """
    return cfg


def ensure_input_paths_exist(cfg: dict[str, Any]) -> None:
    paths = cfg["paths"]
    for key in ["source_processed_dir", "ood_processed_dir", "manifest_path"]:
        p = Path(paths[key])
        if not p.exists():
            raise FileNotFoundError(f"Configured input path does not exist: paths.{key}={p}")

from __future__ import annotations

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import json

import numpy as np
import pandas as pd
import pytest


def make_processed(root: Path, group: str = "source_range", splits=None, n_time: int = 4, n_node: int = 6) -> Path:
    root.mkdir(parents=True, exist_ok=True)
    if splits is None:
        splits = ["train", "train", "validation", "test"] if group == "source_range" else ["ood", "ood"]
    n_case = len(splits)
    branch = np.zeros((n_case, 2), dtype=np.float32)
    for i in range(n_case):
        branch[i] = [0.1 + 0.1 * i, 2.5 + 0.1 * (i % 2)]
    base_coords = np.array([[0.0,0.0],[1.0,0.0],[0.0,1.0],[1.0,1.0],[0.5,0.2],[0.2,0.5]], dtype=np.float64)
    if n_node <= len(base_coords):
        coords = base_coords[:n_node].copy()
    else:
        extra = np.stack([np.linspace(0.1,0.9,n_node-len(base_coords)), np.linspace(0.8,0.1,n_node-len(base_coords))], axis=1)
        coords = np.vstack([base_coords, extra]).astype(np.float64)
    times = np.arange(n_time, dtype=np.float64) * 3600.0
    psi = np.empty((n_case, n_time, n_node), dtype=np.float32)
    con = np.empty_like(psi)
    for c in range(n_case):
        for t in range(n_time):
            psi[c, t] = c + 0.1 * t + np.arange(n_node) * 0.01
            con[c, t] = 0.001 * c + 0.0001 * t + np.arange(n_node) * 1e-5
    np.save(root / "branch_inputs.npy", branch)
    np.save(root / "coords_xz_m.npy", coords)
    np.save(root / "times_s.npy", times)
    np.save(root / "pressure_head_m.npy", psi)
    np.save(root / "concentration.npy", con)
    rows = []
    for i, split in enumerate(splits):
        rows.append({
            "case_index": i,
            "manifest_row_index": i,
            "case_id": f"case_{i}",
            "amplitude_m": round(float(branch[i, 0]), 6),
            "h_land_m": round(float(branch[i, 1]), 6),
            "canonical_library_group": group,
            "library_group": group,
            "split": split,
            "design_regime": "synthetic",
            "raw_case_relpath": f"cases/case_{i}",
            "nod_sha256": f"hash{i}",
        })
    pd.DataFrame(rows).to_csv(root / "case_metadata.csv", index=False)
    meta = {
        "schema_name": "SUTRA Canonical Reference Data Schema",
        "schema_version": "2.1",
        "canonical_library_group": group,
        "manifest_sha256": "synthetic",
        "n_case": n_case,
        "n_time": n_time,
        "n_node": n_node,
        "split_counts": {str(k): int(v) for k, v in pd.Series(splits).value_counts().items()},
        "branch_columns": ["amplitude_m", "h_land_m"],
        "branch_dtype": "float32",
        "coords_columns": ["x_m", "z_m"],
        "coords_dtype": "float64",
        "times_units": "s",
        "times_dtype": "float64",
        "field_axis_order": ["case", "time", "node"],
        "pressure_head_dtype": "float32",
        "pressure_head_units": "m",
        "pressure_head_definition": "pressure_pa / 9810.0",
        "concentration_dtype": "float32",
        "concentration_definition": "raw SUTRA transport variable U / solute mass fraction",
        "concentration_clipping": False,
        "normalization_included": False,
    }
    (root / "dataset_metadata.json").write_text(json.dumps(meta), encoding="utf-8")
    (root / "processed_validation.json").write_text(json.dumps({"passed": True, "failures": []}), encoding="utf-8")
    return root


@pytest.fixture
def mini_source(tmp_path):
    return make_processed(tmp_path / "source", "source_range")


@pytest.fixture
def mini_ood(tmp_path):
    return make_processed(tmp_path / "ood", "higher_amplitude", splits=["ood", "ood"])

from __future__ import annotations

import json

import pandas as pd
import torch

from src.export_store import export_library_predictions, validate_prediction_export
from src.reference_data import CanonicalReferenceData
from src.training import train_model
from src.utils import collect_environment


def _mini_config():
    return {
        "project": {"seed": 123},
        "physics": {
            "tidal_period_s": 43200.0,
            "x_scale_m": 10.0,
            "z_scale_m": 4.0,
            "t_scale_s": 259200.0,
        },
        "normalization": {"eps": 1e-12},
        "model": {
            "branch_dim": 2,
            "trunk_dim": 7,
            "latent_dim": 8,
            "output_dim": 2,
            "branch_hidden": [8],
            "trunk_hidden": [8],
            "activation": "silu",
            "dropout": 0.0,
        },
        "training": {
            "epochs": 2,
            "batch_size": 8,
            "num_samples_per_epoch": 32,
            "learning_rate": 1e-3,
            "weight_decay": 0.0,
            "grad_clip_norm": 1.0,
            "loss_weights": [1.0, 1.0],
            "val_every_epochs": 1,
            "val_points_per_case": 5,
            "validation_seed": 456,
            "early_stopping_patience_epochs": 10,
            "scheduler": {"use_reduce_on_plateau": True, "factor": 0.5, "patience": 2, "min_lr": 1e-5},
        },
        "inference": {"batch_size": 16},
    }


def test_environment_metadata_is_best_effort():
    env = collect_environment()
    assert "cpu_model" in env
    assert "cpu_logical_cores" in env
    assert "system_memory_total_gb" in env
    assert "torch_installed" in env
    assert "gpu_devices" in env
    assert "nvidia_driver_version" in env


def test_training_and_inference_timing_files(mini_source, tmp_path):
    data = CanonicalReferenceData(mini_source)
    cfg = _mini_config()
    run = tmp_path / "run"

    summary = train_model(cfg, data, run, torch.device("cpu"))
    assert summary["timing_instrumentation_version"] == "1.0"
    assert summary["training_loop_wall_time_s"] > 0
    assert summary["train_model_total_wall_time_s"] > 0

    history = pd.read_csv(run / "training" / "training_history.csv")
    for col in [
        "train_phase_time_s",
        "train_samples_per_s",
        "validation_time_s",
        "epoch_wall_time_s",
        "elapsed_training_wall_time_s",
    ]:
        assert col in history.columns
    assert (history["train_phase_time_s"] > 0).all()
    assert (history["epoch_wall_time_s"] > 0).all()

    timing_summary = json.loads((run / "training" / "timing_summary.json").read_text(encoding="utf-8"))
    assert timing_summary["timing_instrumentation_version"] == "1.0"
    assert timing_summary["device"] == "cpu"
    assert timing_summary["cuda_synchronized_at_gpu_phase_boundaries"] is False

    out = export_library_predictions(cfg, data, run, "best", torch.device("cpu"), overwrite=False)
    assert validate_prediction_export(data, out)["passed"]

    timing = pd.read_csv(out / "inference_timing.csv")
    assert len(timing) == data.n_case
    assert (timing["prediction_time_s"] > 0).all()
    assert (timing["n_query_points"] == data.n_time * data.n_node).all()

    export_meta = json.loads((out / "export_metadata.json").read_text(encoding="utf-8"))
    assert export_meta["timing_instrumentation_version"] == "1.0"
    assert export_meta["inference_timing_summary"]["n_cases"] == data.n_case

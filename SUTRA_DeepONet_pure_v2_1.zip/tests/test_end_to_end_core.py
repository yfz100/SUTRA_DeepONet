from pathlib import Path

import torch

from src.export_store import export_library_predictions, validate_prediction_export
from src.metrics import evaluate_prediction_export
from src.reference_data import CanonicalReferenceData
from src.training import train_model


def test_train_export_metrics_core(mini_source, tmp_path):
    data = CanonicalReferenceData(mini_source)
    cfg = {
        "project": {"seed": 123},
        "physics": {"tidal_period_s": 43200.0, "x_scale_m": 10.0, "z_scale_m": 4.0, "t_scale_s": 259200.0},
        "normalization": {"eps": 1e-12},
        "model": {"branch_dim": 2, "trunk_dim": 7, "latent_dim": 8, "output_dim": 2, "branch_hidden": [8], "trunk_hidden": [8], "activation": "silu", "dropout": 0.0},
        "training": {
            "epochs": 2,
            "batch_size": 8,
            "num_samples_per_epoch": 32,
            "learning_rate": 1e-3,
            "weight_decay": 0.0,
            "grad_clip_norm": 1.0,
            "loss_weights": [1.0, 1.0],
            "val_every_epochs": 1,
            "val_points_per_case": 5,
            "validation_seed": 456,
            "early_stopping_patience_epochs": 10,
            "scheduler": {"use_reduce_on_plateau": True, "factor": 0.5, "patience": 2, "min_lr": 1e-5},
        },
        "inference": {"batch_size": 16},
    }
    run = tmp_path / "run"
    summary = train_model(cfg, data, run, torch.device("cpu"))
    assert summary["best_epoch"] >= 1
    out = export_library_predictions(cfg, data, run, "best", torch.device("cpu"), overwrite=False)
    assert validate_prediction_export(data, out)["passed"]
    m = evaluate_prediction_export(data, out, run / "metrics" / "source")
    assert m["n_case_rows"] == 4
    assert m["n_case_time_rows"] == 16

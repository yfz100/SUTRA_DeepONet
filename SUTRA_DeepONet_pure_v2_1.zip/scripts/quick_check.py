from __future__ import annotations

import argparse
from pathlib import Path

from src.config_schema import ensure_input_paths_exist, validate_config
from src.contracts import run_full_data_contract
from src.utils import load_yaml, save_json


def _run_model_smoke(cfg: dict, report: dict) -> None:
    """Run the PyTorch/model smoke test only for model-dependent pipeline stages."""
    try:
        import torch
        from src.model import build_model
        from src.utils import get_device
    except ModuleNotFoundError as exc:
        raise RuntimeError(
            "PyTorch is required because a model-dependent stage (training or "
            "prediction export) is enabled, but torch is not installed in the "
            "current Python environment. For data-only preflight keep all "
            "model-dependent stages disabled. Before GPU training, install the "
            "PyTorch build appropriate for that training environment."
        ) from exc

    device = get_device(cfg["training"].get("device", "auto"))
    model = build_model(cfg).to(device)
    with torch.no_grad():
        b = torch.zeros((4, 2), dtype=torch.float32, device=device)
        x = torch.zeros((4, 7), dtype=torch.float32, device=device)
        y = model(b, x)
    if tuple(y.shape) != (4, 2):
        raise ValueError(f"Model smoke forward failed: output shape={tuple(y.shape)}")
    report["model_smoke"] = {
        "required": True,
        "device": str(device),
        "output_shape": list(y.shape),
        "passed": True,
    }


def main() -> None:
    p = argparse.ArgumentParser(description="Fail-closed preflight for SUTRA DeepONet pure-supervised v2.1")
    p.add_argument("--config", required=True)
    p.add_argument("--run-dir", required=True)
    p.add_argument(
        "--require-torch",
        action="store_true",
        help=(
            "Also require PyTorch and run a model forward smoke test. "
            "The unified pipeline enables this automatically when training "
            "or prediction export is requested."
        ),
    )
    args = p.parse_args()

    cfg = load_yaml(args.config)
    validate_config(cfg)
    ensure_input_paths_exist(cfg)
    run_dir = Path(args.run_dir)
    report = run_full_data_contract(
        cfg["paths"]["source_processed_dir"],
        cfg["paths"]["ood_processed_dir"],
        cfg["paths"]["manifest_path"],
        run_dir / "data_contract_report.json",
    )

    if args.require_torch:
        _run_model_smoke(cfg, report)
    else:
        report["model_smoke"] = {
            "required": False,
            "passed": None,
            "status": "skipped_data_only_preflight",
        }

    save_json(report, run_dir / "data_contract_report.json")
    print("Preflight passed.")
    if not args.require_torch:
        print("Model smoke skipped (data-only preflight; PyTorch not required).")


if __name__ == "__main__":
    main()

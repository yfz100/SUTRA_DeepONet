from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

from src.export_store import validate_prediction_export
from src.normalization import load_normalizer
from src.reference_data import CanonicalReferenceData
from src.sampling import validate_fixed_validation_indices
from src.utils import load_json, load_yaml, save_json


def main() -> None:
    p = argparse.ArgumentParser(description="Verify a completed pure-supervised v2.1 run")
    p.add_argument("--config", required=True)
    p.add_argument("--run-dir", required=True)
    args = p.parse_args()
    cfg = load_yaml(args.config)
    run = Path(args.run_dir)
    failures: list[str] = []

    source = CanonicalReferenceData(cfg["paths"]["source_processed_dir"])
    ood = CanonicalReferenceData(cfg["paths"]["ood_processed_dir"])

    norm_path = run / "normalization" / "normalizer.json"
    norm_meta_path = run / "normalization" / "normalizer_metadata.json"
    if not norm_path.exists() or not norm_meta_path.exists():
        failures.append("normalizer files missing")
    else:
        _ = load_normalizer(norm_path)
        nm = load_json(norm_meta_path)
        train_ids = source.case_metadata.iloc[source.get_split_indices("train")]["case_id"].astype(str).tolist()
        if nm.get("fit_split") != "train" or nm.get("fit_case_ids") != train_ids:
            failures.append("normalizer fit cases are not exactly source train cases")

    val_path = run / "sampling" / "validation_sample_indices.npz"
    if not val_path.exists():
        failures.append("fixed validation sample missing")
    else:
        try:
            sample = dict(np.load(val_path))
            validate_fixed_validation_indices(source, sample, int(cfg["training"]["val_points_per_case"]))
        except Exception as exc:
            failures.append(f"fixed validation sample invalid: {exc}")

    for ck in ["best.pt", "last.pt"]:
        if not (run / "checkpoints" / ck).exists():
            failures.append(f"checkpoint missing: {ck}")

    for data, name in [(source, "source"), (ood, "higher_amplitude")]:
        export_dir = run / "exports" / name
        if export_dir.exists():
            rep = validate_prediction_export(data, export_dir)
            failures.extend([f"{name} export: {x}" for x in rep["failures"]])
        else:
            failures.append(f"export missing: {name}")

    source_metrics = run / "metrics" / "source"
    if source_metrics.exists():
        by_case = pd.read_csv(source_metrics / "metrics_by_case.csv")
        by_time = pd.read_csv(source_metrics / "metrics_by_case_time.csv")
        if len(by_case) != 168:
            failures.append(f"source metrics_by_case rows={len(by_case)} !=168")
        if len(by_time) != 168 * 73:
            failures.append(f"source metrics_by_case_time rows={len(by_time)} !=12264")
    else:
        failures.append("source metrics missing")

    ood_metrics = run / "metrics" / "higher_amplitude"
    if ood_metrics.exists():
        by_case = pd.read_csv(ood_metrics / "metrics_by_case.csv")
        by_time = pd.read_csv(ood_metrics / "metrics_by_case_time.csv")
        if len(by_case) != 18:
            failures.append(f"OOD metrics_by_case rows={len(by_case)} !=18")
        if len(by_time) != 18 * 73:
            failures.append(f"OOD metrics_by_case_time rows={len(by_time)} !=1314")
    else:
        failures.append("OOD metrics missing")

    report = {"passed": not failures, "failures": failures}
    save_json(report, run / "run_verification.json")
    if failures:
        raise ValueError("Run verification failed:\n- " + "\n- ".join(failures))
    print("Run verification passed.")


if __name__ == "__main__":
    main()

from __future__ import annotations

import argparse
from pathlib import Path

from src.config_schema import validate_config
from src.reference_data import CanonicalReferenceData
from src.training import train_model
from src.utils import get_device, load_yaml


def main() -> None:
    p = argparse.ArgumentParser(description="Train SUTRA DeepONet pure-supervised v2.1")
    p.add_argument("--config", required=True)
    p.add_argument("--run-dir", required=True)
    args = p.parse_args()
    cfg = load_yaml(args.config)
    validate_config(cfg)
    data = CanonicalReferenceData(cfg["paths"]["source_processed_dir"])
    device = get_device(cfg["training"].get("device", "auto"))
    print(f"Training device: {device}")
    summary = train_model(cfg, data, Path(args.run_dir), device)
    print(summary)


if __name__ == "__main__":
    main()

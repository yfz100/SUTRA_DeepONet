# SUTRA–DeepONet Pure-Supervised v2.1
## 完整目录结构与模块功能设计（Implementation Baseline Draft）

**日期：2026-09-29**  
**定位：在现有 pure-supervised 包基础上进行源码级重构；本文件是进入代码实现前的架构设计基线。**

---

# 1. 设计目标

新版 pure-supervised v2.1 不再只是“训练脚本 + 临时评价/绘图脚本”，而是建立一条稳定的数据链：

\[
\text{SUTRA canonical reference}
\rightarrow
\text{DeepONet training}
\rightarrow
\text{one-time full inference}
\rightarrow
\text{standard prediction export}
\rightarrow
\text{metrics}
\rightarrow
\text{paper plotting}
\]

核心原则：

1. reference-data layer 与 ML experiment layer 分离；
2. source / OOD 使用同一数据接口；
3. split 只来自 canonical metadata / manifest，不在模型 config 中重复定义；
4. normalizer 只由 source train cases 拟合；
5. test / OOD 永不参与训练、normalizer、early stopping；
6. inference 只做一次，论文绘图不重新加载模型；
7. true field 不在 run 目录重复保存；
8. prediction、metrics、paper plotting 共享统一 case ordering；
9. paper plotting 每图独立，但共享 case-selection / point-selection helper；
10. 所有中间产物可追溯到 checkpoint、normalizer、manifest 和 canonical dataset。

---

# 2. 推荐目录结构

```text
SUTRA_DeepONet_pure_v2_1/
│
├─ run_pipeline.py
├─ README.md
├─ requirements.txt
│
├─ src/
│  ├─ __init__.py
│  ├─ config_schema.py
│  ├─ contracts.py
│  ├─ reference_data.py
│  ├─ normalization.py
│  ├─ features.py
│  ├─ sampling.py
│  ├─ model.py
│  ├─ losses.py
│  ├─ training.py
│  ├─ inference.py
│  ├─ metrics.py
│  ├─ export_store.py
│  ├─ case_selection.py
│  └─ utils.py
│
├─ scripts/
│  ├─ quick_check.py
│  ├─ train.py
│  ├─ export_predictions.py
│  ├─ evaluate_exports.py
│  └─ verify_run.py
│
├─ diagnostics/
│  └─ plot_training_history.py
│
├─ paper_plots/
│  ├─ common.py
│  ├─ representative_points.py
│  ├─ plot_field_reconstruction.py
│  ├─ plot_pressure_timeseries.py
│  └─ plot_concentration_timeseries.py
│
├─ tests/
│  ├─ test_data_contract.py
│  ├─ test_no_data_leakage.py
│  ├─ test_normalizer.py
│  ├─ test_sampling.py
│  ├─ test_case_selection.py
│  ├─ test_metrics.py
│  └─ test_prediction_export.py
│
├─ docs/
│  ├─ architecture.md
│  ├─ prediction_export_contract.md
│  └─ metrics_contract.md
│
└─ runs/
   └─ .gitkeep
```

Canonical SUTRA data **不复制进该代码包**。`run_pipeline.py` 只保存路径，例如：

```text
REFERENCE_ROOT/
├─ source_range/processed/
└─ higher_amplitude/processed/
```

---

# 3. 模块功能图

```mermaid
flowchart TD
    A[Canonical source processed<br/>168 cases] --> B[contracts.py<br/>source data gate]
    O[Canonical OOD processed<br/>18 cases] --> C[contracts.py<br/>OOD + cross-library gate]
    M[Manifest v2.1] --> B
    M --> C

    B --> D[reference_data.py<br/>CanonicalReferenceData]
    C --> E[reference_data.py<br/>CanonicalReferenceData]

    D --> F[normalization.py<br/>fit on train=120 only]
    D --> G[features.py<br/>shared 7-D trunk]
    D --> H[sampling.py<br/>random training triplets]
    D --> I[sampling.py<br/>fixed validation sample]

    F --> J[model.py<br/>2-D branch DeepONet]
    G --> J
    H --> K[training.py]
    I --> K
    J --> K

    K --> L[best.pt / last.pt]
    K --> N[training_history.csv]
    F --> P[normalizer.json]

    L --> Q[inference.py]
    P --> Q
    D --> Q
    E --> Q

    Q --> R[export_store.py<br/>source prediction archive]
    Q --> S[export_store.py<br/>OOD prediction archive]

    D --> T[metrics.py]
    E --> U[metrics.py]
    R --> T
    S --> U

    T --> V[source metrics tables]
    U --> W[OOD metrics tables]

    D --> X[paper_plots/common.py]
    E --> X
    R --> X
    S --> X

    X --> Y[field reconstruction plot]
    X --> Z[pressure time-series plot]
    X --> AA[concentration time-series plot]
```

---

# 4. `run_pipeline.py`：唯一人工操作入口

新版仍保持用户偏好的“文件顶部集中参数 + 一键流程”。

## 4.1 只保留一个配置源

旧包同时存在根目录 `config.yaml` 和 `run_pipeline.py` 中的参数，存在双 source-of-truth 风险。

新版建议：
- 人工只修改 `run_pipeline.py` 顶部参数；
- pipeline 自动生成 `runs/<run>/config_used.yaml`；
- 不再提供一个需要人工同步维护的根目录 `config.yaml`。

## 4.2 建议的流程开关

```python
DO_PREFLIGHT = True
DO_TRAIN = True
DO_EXPORT_SOURCE = True
DO_EVALUATE_SOURCE = True
DO_EXPORT_OOD = True
DO_EVALUATE_OOD = True
DO_DIAGNOSTIC_PLOTS = True
DO_PAPER_PLOTS = False
```

`DO_PAPER_PLOTS=False` 建议作为默认值。论文图仍是独立脚本，可按需运行。

若只想对已有 run 重做 metrics/plot：

```python
DO_TRAIN = False
EXISTING_RUN_DIR = r"..."
```

不得重新做 model inference，除非 prediction export 缺失或用户显式要求 overwrite。

---

# 5. 数据接口层

## 5.1 `src/contracts.py`

职责：任何训练之前先阻断错误数据。

核心函数建议：

```python
validate_source_contract(...)
validate_ood_contract(...)
validate_manifest_alignment(...)
validate_cross_library_alignment(...)
write_data_contract_report(...)
```

必须检查：

### source
- schema version = 2.1
- `n_case=168`
- branch `(168,2)`
- psi/C `(168,73,3534)`
- split = 120 train + 24 validation + 24 test
- train/val/test 不重叠且覆盖 168 cases
- branch columns = `[A,H_land]`
- `case_metadata` 与 branch exact alignment
- `processed_validation.passed == true`
- field finite

### OOD
- `n_case=18`
- split 全部 `ood`
- branch `(18,2)`
- psi/C `(18,73,3534)`
- metadata alignment
- processed validation PASS

### source ↔ OOD
- coords 相同，建议 `np.allclose(..., rtol=0, atol=1e-12)`
- times exact identical
- node/time count 相同
- schema version 相同
- pressure-head definition 相同
- concentration definition相同
- manifest SHA256相同

任何一项失败：**fail closed**。

---

## 5.2 `src/reference_data.py`

核心对象：

```python
class CanonicalReferenceData:
    ...
```

职责：
- 用 `np.load(..., mmap_mode="r")` 读取大场数组；
- 不在初始化时把 psi 和 C 再复制堆叠成一个巨大 4-D array；
- 暴露统一接口。

建议属性：

```text
branch              (N_case,2)
coords              (3534,2)
times               (73,)
pressure_head       (N_case,73,3534)
concentration       (N_case,73,3534)
case_metadata
split_indices
```

建议方法：

```python
get_target_batch(case_idx, time_idx, node_idx)
get_case_pressure_head(case_idx)
get_case_concentration(case_idx)
get_case_targets(case_idx)
get_split_indices(split)
```

---

# 6. Branch / trunk 设计

## 6.1 Branch

正式固定：

\[
\mathbf b=[A,H_{\rm land}]
\]

shape：

\[
(N_{\rm case},2)
\]

不再保留：
- eta0
- phase
- constant

因为它们在本数据族中不变化，不属于 operator branch variable。

## 6.2 Trunk

保留旧模型中已经验证的 7-D 表示：

\[
[x,z,t,\sin\omega t,\cos\omega t,\sin 2\omega t,\cos 2\omega t]
\]

其中前三项尺度化：

\[
x/10,\quad z/4,\quad t/259200.
\]

harmonic features 保持原值。

`src/features.py` 负责一次性生成：

```text
trunk_all_raw  (73,3534,7)
trunk_all_norm (73,3534,7)
```

不写入 canonical processed dataset。

---

# 7. Normalization

`src/normalization.py`

## 7.1 只用 source train

仅允许：

\[
120\text{ training cases}
\]

参与：

- branch mean/std
- pressure-head mean/std
- concentration mean/std

validation/test/OOD 不得参与。

## 7.2 内存与精度

建议对 target statistics 分 case/chunk 以 `float64` 累积，再保存统计量到 JSON。

模型输入输出仍使用 `float32`。

## 7.3 输出

```text
normalizer.json
normalizer_metadata.json
```

metadata 至少记录：
- fit split = train
- number of training cases = 120
- case IDs / hash
- target names
- branch column order
- manifest hash

---

# 8. Training sampling

`src/sampling.py`

## 8.1 Training

继续采用已经确认的：

\[
(case,time,node)
\]

uniform random sampling。

每个 sample：
1. 120 train cases 等概率；
2. 73 times 等概率；
3. 3534 nodes 等概率。

**不做 regime-balanced training。**

建议改为 vectorized batch sampler，而不是 Python 一点一点 `yield`，减少 524288 samples/epoch 的解释器开销。

每个 epoch 用 `seed + epoch`，保证可复现且 epoch 间样本不同。

---

# 9. Fixed validation sampling

这是 v2.1 相对旧包的重要改造。

旧包每次 validation 会随 epoch seed 改变抽样点，新版改为**训练开始前固定一套 validation sample**。

当前：

\[
24\text{ validation cases}
\]

旧 `val_num_points=254448` 恰好满足：

\[
254448 / 24 = 10602.
\]

因此推荐：

- 每个 validation case 固定抽 10,602 个 `(time,node)`；
- 每 case 内从 \(73\times3534=257982\) 个点中无放回随机抽样；
- 24 cases 权重完全相同；
- 一次生成后保存：

```text
sampling/validation_sample_indices.npz
```

包含：

```text
case_index
time_index
node_index
```

以后每次 validation 使用完全相同的 254,448 points。

这不是 regime balancing；只是让每个 validation case 在 checkpoint selection 中拥有相同权重，同时消除 validation sampling noise。

---

# 10. Model

`src/model.py`

保留旧包的 multi-output DeepONet 基本结构：

\[
B(\mathbf b)\rightarrow (2,p)
\]

\[
T(\mathbf x)\rightarrow (2,p)
\]

\[
\hat y_o=\sum_{k=1}^{p}B_{o,k}T_{o,k}+b_o
\]

输出：

\[
[\hat\psi,\hat C]
\]

主要结构变化只有：

```text
branch_dim: 4 -> 2
```

默认保留：
- latent_dim = 256
- branch hidden = 128-128-128
- trunk hidden = 256-256-256-256
- SiLU
- dropout = 0

这些参数继续放在 `run_pipeline.py` 可调，而不是在源码硬编码。

---

# 11. Loss 与 checkpoint selection

## 11.1 Training loss

两个 target 各自使用 train-only mean/std 标准化。

在 normalized space：

\[
L_\psi = {\rm MSE}(\hat\psi_n,\psi_n)
\]

\[
L_C = {\rm MSE}(\hat C_n,C_n)
\]

默认：

\[
L = \frac{L_\psi+L_C}{2}.
\]

## 11.2 Validation metric

固定 validation subset 上计算：

\[
L_{\rm val}=\frac{L_{\psi,\rm val}+L_{C,\rm val}}{2}.
\]

best checkpoint 只由该固定 validation metric 决定。

test 和 OOD 不参与 checkpoint selection。

---

# 12. Run directory

推荐每次训练形成：

```text
runs/<run_name>/
│
├─ config_used.yaml
├─ run_info.json
├─ environment.json
├─ data_contract_report.json
│
├─ checkpoints/
│  ├─ best.pt
│  └─ last.pt
│
├─ normalization/
│  ├─ normalizer.json
│  └─ normalizer_metadata.json
│
├─ sampling/
│  └─ validation_sample_indices.npz
│
├─ training/
│  ├─ training_history.csv
│  └─ training_summary.json
│
├─ exports/
│  ├─ source/
│  └─ higher_amplitude/
│
├─ metrics/
│  ├─ source/
│  └─ higher_amplitude/
│
├─ diagnostics/
│
└─ paper_figures/
```

---

# 13. Prediction Export Contract v1

这是模型层和论文绘图层之间最重要的接口。

## 13.1 Source

```text
exports/source/
├─ pred_pressure_head_m.npy
├─ pred_concentration.npy
├─ case_metadata.csv
├─ export_metadata.json
└─ EXPORT_COMPLETE
```

shape：

\[
(168,73,3534)
\]

dtype：`float32`

## 13.2 OOD

```text
exports/higher_amplitude/
├─ pred_pressure_head_m.npy
├─ pred_concentration.npy
├─ case_metadata.csv
├─ export_metadata.json
└─ EXPORT_COMPLETE
```

shape：

\[
(18,73,3534)
\]

## 13.3 不重复保存 true fields

true fields 始终读取 canonical reference：

```text
source_range/processed/pressure_head_m.npy
source_range/processed/concentration.npy
higher_amplitude/processed/...
```

run 目录只保存 prediction。

## 13.4 不保存 error arrays

error 是：

\[
e=\hat y-y
\]

属于可无损派生数据。

paper plots 或 metrics 直接从 true + prediction 计算，避免第三份大数组和 stale-error 风险。

## 13.5 export metadata

至少包含：
- library
- array shapes / dtype
- axis order
- case count
- case metadata hash
- manifest hash
- source reference metadata hash
- checkpoint filename / SHA256
- normalizer SHA256
- model config hash
- prediction batch size
- code version
- target names

写出过程建议使用临时目录 + `EXPORT_COMPLETE`，避免半成品被绘图脚本读取。

---

# 14. Metrics Export Contract

所有 publication metrics 都在**物理量空间**计算，且 reduction 使用 `float64`。

## 14.1 指标

对每个变量：

\[
{\rm RMSE}
=
\sqrt{\frac1N\sum_i(\hat y_i-y_i)^2}
\]

\[
{\rm MAE}
=
\frac1N\sum_i|\hat y_i-y_i|
\]

\[
{\rm RL2E}
=
\sqrt{
\frac{\sum_i(\hat y_i-y_i)^2}
{\sum_i y_i^2}
}
\]

以及 diagnostic：
- Bias
- Max absolute error
- P95 absolute error
- P99 absolute error

若 RL2E denominator = 0，则写 `NaN`，不人为填 0。

## 14.2 Source metrics

```text
metrics/source/
├─ metrics_by_case.csv
├─ metrics_by_case_time.csv
├─ metrics_pooled_by_split.csv
└─ metrics_case_summary_by_split.csv
```

### `metrics_by_case.csv`
168 rows。

包含：
- case_id
- case_index
- A
- H_land
- split
- design_regime
- pressure-head metrics
- concentration metrics

### `metrics_by_case_time.csv`
168 × 73 = 12,264 rows。

用于：
- 时间误差演变；
- t=63h 等时刻快速查表；
- 后续论文图不重新做 inference。

### `metrics_pooled_by_split.csv`
分别对 train / validation / test 的全部 point 做 pooled metric。

### `metrics_case_summary_by_split.csv`
统计 case-level metric 的：
- mean
- std
- min
- max

明确与 pooled metric 分开，避免统计口径混淆。

## 14.3 OOD metrics

```text
metrics/higher_amplitude/
├─ metrics_by_case.csv
├─ metrics_by_case_time.csv
└─ metrics_pooled_all.csv
```

其余按 A/H 的分组表可由 `metrics_by_case.csv` 轻量派生，不需要重新模型推理。

---

# 15. Inference 设计

`src/inference.py`

核心函数：

```python
predict_case(...)
predict_library_to_export(...)
```

对每 case：
- 构造该 case 的 branch；
- 使用共享 trunk；
- 以 batch 推理 73×3534 points；
- inverse normalization；
- 直接写入 `np.lib.format.open_memmap` 输出 array。

这样不需要一次把 168-case predictions 全放内存。

source 与 OOD 使用同一 inference code。

OOD 强制使用 source-training normalizer。

---

# 16. `evaluate_exports.py`

评价脚本**不加载 PyTorch model**。

只读取：

```text
canonical true fields
+
prediction export
```

然后生成 metrics。

这是非常重要的设计：保证论文表格与论文绘图使用的 prediction 与正式 export 完全一致。

---

# 17. Paper plotting interface

论文脚本不使用 Figure 编号命名，避免论文后期重编号。

推荐：

```text
paper_plots/
├─ representative_points.py
├─ plot_field_reconstruction.py
├─ plot_pressure_timeseries.py
└─ plot_concentration_timeseries.py
```

现有 Figure 11/12/13 的视觉参数、布局、字体、colorbar 和线型尽量原样移植，只替换 data access layer。

---

# 18. Representative points 共享

当前 5 个点：

```python
TARGET_POINTS = [
    (0.00, 2.00),
    (4.98, 2.00),
    (7.61, 1.37),
    (6.41, 2.05),
    (9.03, 0.47),
]
```

建议只定义一次：

`paper_plots/representative_points.py`

Figure field、pressure series、concentration series 全部 import 同一份。

输出时额外保存：

```text
representative_points_resolved.csv
```

记录：
- P1–P5
- target x/z
- nearest node index
- actual node x/z
- distance

确保三张图使用完全一致的节点。

---

# 19. Field reconstruction plot（现 Figure 11）

新脚本建议支持一次画多个 case：

```python
CASES_TO_PLOT = [
    {
        "amplitude": 0.60,
        "h_land": 2.55,
        "time_h": 63.0,
        "expected_split": "test",
        "show_points": False,
    },
    {
        "amplitude": 0.60,
        "h_land": 2.70,
        "time_h": 63.0,
        "expected_split": "test",
        "show_points": True,
    },
    {
        "amplitude": 0.60,
        "h_land": 3.30,
        "time_h": 63.0,
        "expected_split": "test",
        "show_points": False,
    },
]
```

已核查当前 manifest v2.1：

- `case_A0.600_H2.550` = test
- `case_A0.600_H2.700` = test
- `case_A0.600_H3.300` = test

而且三个 case 分别位于：
- saline-intrusion-side
- transition-near
- freshwater-dominated

在保持 \(A=0.60\)、\(t=63\) h 不变的情况下改变 \(H_{\rm land}\)，有利于展示 inland-head 变化对应的三种响应状态。

在当前相位定义下，63 h 对 12 h 潮周期对应：

\[
\sin(2\pi t/T)=1
\]

即一个潮位峰值时刻，这使该快照也具有清晰的物理解释。

## 19.1 points marker

`show_points=True` 的那一个 case，在指定 panel 上画 P1–P5：

```python
MARK_POINTS_ON_PANEL = "pressure_true"
SHOW_POINT_LABELS = True
```

可切换为 pressure prediction / concentration panel。

## 19.2 时间选择必须严格

旧脚本用 nearest time。

新版建议默认：

```python
REQUIRE_EXACT_TIME = True
```

若请求时间不是 canonical times 中的精确时间，则报错。

## 19.3 concentration 显示

保留当前论文图规则：

- raw C 不 clipping；
- concentration error 用 raw true/pred 计算；
- 仅状态场显示使用 `0–0.036` clip。

---

# 20. Pressure-head time-series plot（现 Figure 12）

顶部参数建议：

```python
REFERENCE_ROOT = ...
RUN_DIR = ...
LIBRARY = "source"

AMPLITUDE = 0.60
H_LAND = 2.70
EXPECTED_SPLIT = "test"

OUTPUT_DIR = ...
```

内部：
1. 根据 metadata 找唯一 case；
2. 校验 split；
3. 读取 true/pred pressure-head full field；
4. 从 shared representative points 得到 node indices；
5. 画 73 h 时序。

保持现有：
- 5 rows
- P1–P5 panel tag
- SUTRA solid / DeepONet dashed
- shared y label
- shared legend
- PNG + PDF

---

# 21. Concentration time-series plot（现 Figure 13）

与 pressure script 使用完全相同的 case/point interface。

唯一差别：
- target = concentration
- y label / y range 自动适配 concentration

不得对 time-series concentration clip。

---

# 22. Case selector

`src/case_selection.py`

建议：

```python
select_case_by_ah(
    metadata,
    amplitude,
    h_land,
    expected_split=None,
    atol=1e-9,
)
```

规则：
- 0 match -> error
- >1 match -> error
- split 不符合 -> error（不是 warning）
- 返回 `case_index + case_id + row metadata`

也支持：

```python
select_case_by_id(...)
```

这样以后 paper plots 不需要自己解析文件名。

---

# 23. 旧包 → 新包迁移表

| 旧文件 | 新版处理 |
|---|---|
| `run_pipeline.py` | 保留理念，重写 orchestration；成为唯一人工参数入口 |
| `config.yaml` | 不再作为第二个人工 source；改为 run 自动生成的 `config_used.yaml` |
| `quick_check.py` | 保留并扩展为 data/leakage/model smoke gate |
| `train.py` | 保留 wrapper，核心移入 `src/training.py` |
| `evaluate.py` | 拆成 `export_predictions.py` + `evaluate_exports.py` |
| 两个 extrap evaluate 脚本 | 废弃；source/OOD 合并到统一 inference/evaluation 接口 |
| `plot_results.py` | 废弃为正式结果入口；不再重新模型推理 |
| `src/dataset.py` | 拆成 reference_data / normalization / features / sampling |
| `src/model.py` | 保留主结构，branch_dim 改为 2 |
| `src/eval_utils.py` | 拆成 inference / export_store |
| `src/metrics.py` | 重写为统一 RMSE/MAE/RL2E 等口径 |
| `src/utils.py` | 保留通用 I/O/hash/seed/device 功能 |
| 现 Figure11 | 移植为 `plot_field_reconstruction.py` |
| 现 Figure12 | 移植为 `plot_pressure_timeseries.py` |
| 现 Figure13 | 移植为 `plot_concentration_timeseries.py` |

---

# 24. Data-leakage gate

新版必须程序化保证：

\[
\text{train}
\cap
\text{validation}
=
\varnothing
\]

\[
\text{train}
\cap
\text{test}
=
\varnothing
\]

\[
\text{validation}
\cap
\text{test}
=
\varnothing
\]

且：
- normalizer fit IDs = train IDs only；
- training sampler IDs = train IDs only；
- validation sampler IDs = validation IDs only；
- checkpoint selection 不调用 test；
- OOD 不进入 train/validation；
- `design_regime` 不进入 network input；
- paper case selection 不影响模型训练。

---

# 25. Recommended run flow

```mermaid
flowchart LR
    A[Preflight] --> B[Train]
    B --> C[Best checkpoint frozen]
    C --> D[Export source predictions]
    D --> E[Evaluate source exports]
    C --> F[Export OOD predictions]
    F --> G[Evaluate OOD exports]
    E --> H[Verify run]
    G --> H
    H --> I[Paper plotting scripts]
```

注意：

**Paper plotting 不属于 checkpoint selection，也不触发 model inference。**

---

# 26. 最终建议

该设计的核心并不是增加更多脚本，而是把旧包中混在一起的四种职责拆清楚：

\[
\boxed{
\text{reference data}
\neq
\text{training}
\neq
\text{prediction export}
\neq
\text{paper plotting}
}
\]

但它们通过固定 contract 自动衔接，因此用户实际操作反而更简单：

1. `run_pipeline.py` 完成训练 + source/OOD full prediction + metrics；
2. 论文画图时只打开某个 `paper_plots/*.py`；
3. 修改 A、H_land、time、输出目录；
4. 直接出图，不再整理数据，不再推理模型。

这应作为 pure-supervised v2.1 的源码实现基线。

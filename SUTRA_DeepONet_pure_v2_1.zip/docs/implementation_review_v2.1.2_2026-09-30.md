# Pure-Supervised v2.1.2 Hardware & Timing Instrumentation — Implementation Review

**Date:** 2026-09-30

## Release decision

v2.1.2 is a narrow instrumentation patch on the fully integration-tested v2.1.1 baseline.
It is intended to be used for the formal baseline run after one short timing smoke.

## Scientific / ML behavior intentionally unchanged

No changes were made to:

- canonical source/OOD loader and split authority;
- DeepONet branch/trunk/output architecture;
- feature definitions;
- train-only normalization;
- uniform training triplet sampling;
- fixed validation sampling;
- loss function / weights;
- AdamW, gradient clipping, scheduler, early stopping;
- best-checkpoint selection;
- physical-space inference mathematics;
- evaluation metrics;
- paper plotting interfaces.

## Modified runtime files

- `run_pipeline.py`: version bump to 2.1.2; parent `CUDA_VISIBLE_DEVICES` is synchronized with subprocess hardware probing.
- `src/utils.py`: optional hardware probes + `synchronize_device()`.
- `src/training.py`: per-epoch and aggregate synchronized wall-clock timing.
- `src/export_store.py`: per-case synchronized full-inference timing and timing validation.

## Hardware provenance

`environment.json` now records, when available:

- CPU model;
- physical/logical CPU core counts;
- total RAM;
- NVIDIA driver and `nvidia-smi` GPU inventory;
- PyTorch/CUDA/cuDNN versions;
- PyTorch-visible GPU name, VRAM, compute capability and multiprocessor count;
- PyTorch intra/inter-op thread counts.

All optional probes are best-effort and cannot make data-only preflight fail.

## Training timing

CUDA timing boundaries call `torch.cuda.synchronize(device)` before and after measured GPU phases.

`training_history.csv` adds:

- `train_phase_time_s`;
- `train_samples_per_s`;
- `validation_time_s`;
- `validation_points_per_s`;
- `epoch_wall_time_s`;
- `elapsed_training_wall_time_s`.

`training/timing_summary.json` adds aggregate setup/training-loop/validation times.
`training_summary.json` stores key total times and the SHA256 of `timing_summary.json`.

## Inference timing

Each complete case is timed around `predict_case` with CUDA synchronization.
For the formal dataset one timed case corresponds to all:

`73 × 3534 = 257,982`

spatiotemporal query points for one `(A,H_land)` pair.

Measured prediction scope includes:

- branch encoding;
- trunk batches;
- latent combination;
- device-to-host transfer;
- inverse target normalization.

It excludes memmap writes, SHA256 hashing, metrics and plotting.

Each export adds:

- `inference_timing.csv`;
- `inference_timing_summary.json`;
- timing metadata/hash fields in `export_metadata.json`.

The primary mean includes the first case; a separate `mean_prediction_time_excluding_first_case_s` diagnostic is also stored to expose possible first-call warm-up overhead.

## Compatibility behavior

A v2.1.1 export without timing files is not silently reused as a v2.1.2 timed export. If its model/normalizer provenance matches, v2.1.2 asks the user to rebuild intentionally with `--overwrite`.

## Verification performed

- `python -m compileall -q .` — PASS
- `pytest -q` — **12 passed**
- synthetic end-to-end timing check — PASS
  - training timing files generated;
  - inference timing files generated;
  - export validation passed.

No GPU was available in the package-build container; CUDA synchronization behavior must therefore be confirmed once on the user's actual CUDA environment before starting the 800-epoch formal run.

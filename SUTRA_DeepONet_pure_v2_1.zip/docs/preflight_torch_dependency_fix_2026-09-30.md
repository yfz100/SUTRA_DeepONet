# Pure-Supervised v2.1.1 — data-only preflight PyTorch dependency fix

## Problem

The v2.1.0 package promised that a preflight-only run could be executed before GPU/model setup, but two top-level imports violated that contract:

1. `src/utils.py` imported `torch` at module import time;
2. `scripts/quick_check.py` imported both `torch` and `src.model` at module import time.

Therefore `python run_pipeline.py` failed before the pipeline stage switches could be evaluated when PyTorch was not installed.

## Fix

- Removed top-level `torch` import from `src/utils.py`.
- `set_seed()` and `get_device()` now import PyTorch lazily only when a model operation requires it.
- `collect_environment()` now records `torch_installed=False` and the import error rather than aborting data-only preflight.
- Removed top-level `torch` / model import from `scripts/quick_check.py`.
- Added `--require-torch` to `scripts.quick_check`.
- `run_pipeline.py` automatically requests `--require-torch` only if `DO_TRAIN`, `DO_EXPORT_SOURCE`, or `DO_EXPORT_OOD` is enabled.
- Pure data preflight therefore checks the canonical SUTRA datasets without requiring PyTorch.
- If a model-dependent stage is enabled and PyTorch is missing, the pipeline now fails early with an explicit actionable error.

## Scientific / numerical impact

None. The patch does not modify:

- source/OOD datasets;
- train/validation/test split;
- normalization definitions;
- branch/trunk features;
- network architecture;
- loss;
- random sampling;
- validation sampling;
- checkpoint selection;
- inference mathematics;
- metrics;
- paper-plot interfaces.

This is an orchestration/dependency-loading bug fix only.

## Verification

- `python -m compileall -q .` — PASS
- `pytest -q` — 10 passed
- simulated environment in which every `import torch` raises `ModuleNotFoundError`:
  - import `run_pipeline` — PASS
  - `collect_environment()` — PASS, records torch unavailable
  - import `scripts.quick_check` — PASS

Package version updated from 2.1.0 to 2.1.1.

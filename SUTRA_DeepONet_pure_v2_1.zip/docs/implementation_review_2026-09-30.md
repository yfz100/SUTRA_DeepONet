# Pure-Supervised v2.1 Implementation Review

**Date:** 2026-09-30

## Implemented layers

1. Canonical data contract / fail-closed loader
2. Train-only normalization
3. 7-D harmonic trunk feature construction
4. Vectorized uniform `(case,time,node)` training sampling
5. Fixed, equal-per-validation-case sampling
6. Two-input branch multi-output DeepONet
7. Training / scheduler / best+last checkpoints
8. One-time full source and OOD inference
9. Prediction Export Contract v1
10. Physical-space metrics export
11. Run verification
12. Paper plotting interfaces migrated from the supplied field/time-series scripts

## Leakage controls

- source split comes only from canonical metadata / manifest
- train / validation / test overlap is rejected
- normalizer is fitted only on source train cases
- training sampler sees only source train indices
- fixed validation sampler sees only validation indices
- best checkpoint is selected only from validation normalized MSE
- test and higher-amplitude OOD do not enter fitting or checkpoint selection
- `design_regime` is metadata only and is not a network input or sampling weight

## Old-package behaviors intentionally removed

- amplitude-list split logic in config
- 4-D branch `[H_land,A,phase,constant]`
- stacking entire raw target fields into another 4-D copy
- storing a second fully normalized target field array
- reevaluating the model inside plotting code
- amplitude-only prediction filenames
- duplicate `true_*.npy` exports
- separate ad-hoc extrapolation evaluator scripts
- epoch-varying validation samples

## Tests executed in the development environment

`pytest -q`: **10 passed**.

Coverage includes:

- canonical reader
- train-only normalizer
- normalization round-trip
- vectorized training sampler
- fixed validation sampling
- 2-D branch model forward
- RL2E definition including zero-denominator handling
- case selection + split gate
- one-time prediction export without duplicate true/error fields
- miniature train → checkpoint → prediction export → metrics integration
- paper plotting scripts reading reference + frozen exports without model inference

`python -m compileall -q .`: passed.

## Production limitation of this review

The actual 168-case and 18-case canonical `.npy` arrays were not present in this execution environment, so the full production GPU training was not run here. The package therefore still requires a user-side **preflight-only run** against the frozen formal reference library before launching the long training. The preflight is designed to validate the exact formal shapes, metadata, manifest SHA256, split counts, finite fields, and source/OOD coordinate/time identity.

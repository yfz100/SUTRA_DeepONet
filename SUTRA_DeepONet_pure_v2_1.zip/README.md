# SUTRA–DeepONet Pure-Supervised v2.1.2

This package is the formal pure-supervised baseline for the frozen SUTRA Canonical Reference Data Schema v2.1.

## Operator

\[
(A,H_{land}) \mapsto [\psi(x,z,t),C(x,z,t)]
\]

Branch input order:

```text
[amplitude_m, h_land_m]
```

Trunk input order:

```text
[x/10, z/4, t/259200, sin(wt), cos(wt), sin(2wt), cos(2wt)]
```

Output order:

```text
[pressure head, concentration]
```

Pressure head is the canonical SUTRA field `pressure_pa / 9810.0`. Concentration is the raw SUTRA transport variable; the ML pipeline does not clip it.

## Formal datasets

Source:

```text
168 cases = 120 train + 24 validation + 24 test
A = 0.05, 0.10, ..., 0.60
H_land = 2.50, 2.55, 2.60, 2.65, 2.70, 2.75, 2.80, 2.90, 3.00, 3.10, 3.20, 3.30, 3.40, 3.50
```

Higher-amplitude OOD:

```text
18 cases
A = 0.70, 0.80, ..., 1.20
H_land = 2.50, 2.70, 3.50
```

The package does **not** create or modify SUTRA reference data.


## Recommended first production action: preflight only

Before any GPU training, run the exact formal data gate by setting:

```python
DO_PREFLIGHT = True
DO_TRAIN = False
DO_EXPORT_SOURCE = False
DO_EVALUATE_SOURCE = False
DO_EXPORT_OOD = False
DO_EVALUATE_OOD = False
DO_DIAGNOSTIC_PLOTS = False
DO_VERIFY_RUN = False
EXISTING_RUN_DIR = None
```

This creates a new run directory containing `config_used.yaml`, `environment.json`, and `data_contract_report.json`, but does not train. Send that report for review before the long run.

If the preflight passes and you want to train in the same run directory, set `EXISTING_RUN_DIR` to that preflight run, set `DO_TRAIN=True`, and enable the later stages. The pipeline refuses to overwrite an existing `best.pt`.

## Main workflow

Edit only the parameter block at the top of:

```text
run_pipeline.py
```

then run:

```bash
python run_pipeline.py
```

Default full sequence:

```text
preflight
→ training
→ source full prediction export
→ source metrics
→ OOD full prediction export
→ OOD metrics
→ training-history diagnostic
→ run verification
```

### First production run: recommended smoke configuration

Before an 800-epoch job, temporarily set for example:

```python
EPOCHS = 2
NUM_SAMPLES_PER_EPOCH = 16384
BATCH_SIZE = 4096
DO_EXPORT_SOURCE = False
DO_EVALUATE_SOURCE = False
DO_EXPORT_OOD = False
DO_EVALUATE_OOD = False
DO_DIAGNOSTIC_PLOTS = True
DO_VERIFY_RUN = False
```

This checks the production data contract, normalization, sampler, GPU forward/backward, validation and checkpoint writing without committing to a long run.

After the smoke run is reviewed, restore the formal settings.

## Important data-leakage rules

The code enforces:

- split comes from canonical metadata / manifest;
- train, validation and test are disjoint;
- normalizer uses source train only;
- training sampler uses train only;
- fixed validation sample uses validation only;
- test and OOD are not used for checkpoint selection;
- `design_regime` is not a DeepONet input and is not used for training weights.

## Fixed validation

Each of the 24 validation cases contributes exactly 10,602 unique `(time,node)` points:

```text
24 × 10,602 = 254,448 points
```

The indices are generated once and saved to:

```text
runs/<run>/sampling/validation_sample_indices.npz
```

Every validation epoch therefore evaluates the same points.

## Prediction exports

After training, the best checkpoint performs full inference once.

Source:

```text
exports/source/
    pred_pressure_head_m.npy   (168,73,3534) float32
    pred_concentration.npy     (168,73,3534) float32
    case_metadata.csv
    export_metadata.json
    export_validation.json
    EXPORT_COMPLETE
```

OOD:

```text
exports/higher_amplitude/
    pred_pressure_head_m.npy   (18,73,3534) float32
    pred_concentration.npy     (18,73,3534) float32
    case_metadata.csv
    export_metadata.json
    export_validation.json
    EXPORT_COMPLETE
```

The run directory does not duplicate true SUTRA fields and does not store error arrays. Metrics and plots compute errors from canonical reference + frozen prediction export.

## Metrics

Source:

```text
metrics/source/
    metrics_by_case.csv
    metrics_by_case_time.csv
    metrics_pooled_by_split.csv
    metrics_case_summary_by_split.csv
    metrics_metadata.json
```

OOD has the analogous files under `metrics/higher_amplitude/`.

Core metrics are RMSE, MAE and RL2E; bias, maximum absolute error, P95 absolute error and P99 absolute error are retained as diagnostics.

## Paper plotting

Publication plotting is intentionally separated from model inference.

```text
paper_plots/plot_field_reconstruction.py
paper_plots/plot_pressure_timeseries.py
paper_plots/plot_concentration_timeseries.py
```

These scripts read:

```text
canonical SUTRA reference + frozen prediction export
```

They never load `best.pt` and never rerun the network.

### Field reconstruction default cases

The script is preconfigured for:

```text
A=0.60, H_land=2.55, t=63 h
A=0.60, H_land=2.70, t=63 h
A=0.60, H_land=3.30, t=63 h
```

All three are formal `test` cases in manifest v2.1. One of them can mark the shared P1–P5 points via `show_points=True`.

### Representative points

The P1–P5 targets are defined once in:

```text
paper_plots/representative_points.py
```

Every paper script resolves the same nearest SUTRA nodes. The resolved node IDs and actual coordinates are saved as:

```text
representative_points_resolved.csv
```

## Testing

Development checks:

```bash
python -m compileall -q .
pytest -q
```

The implementation release was built with all included tests passing. See:

```text
docs/implementation_review_2026-09-30.md
```


## v2.1.1 preflight dependency fix

Data-only preflight no longer requires PyTorch to be installed. `run_pipeline.py` asks
`scripts.quick_check` for a PyTorch/model smoke test only if training or prediction
export is enabled. Therefore a configuration with `DO_TRAIN=False`,
`DO_EXPORT_SOURCE=False`, and `DO_EXPORT_OOD=False` can validate the formal canonical
data library on a lightweight Python environment. PyTorch remains mandatory before
training or prediction export.


## v2.1.2 hardware and timing instrumentation

v2.1.2 is a deliberately narrow instrumentation patch. It does **not** change the
DeepONet architecture, split, normalization, sampling, loss, optimizer, scheduler,
checkpoint-selection rule, prediction mathematics, metrics, or paper-plot interfaces.

For every new run, `environment.json` now records best-effort hardware information in
addition to the existing software environment, including CPU model/core counts, total
system RAM, NVIDIA driver information when `nvidia-smi` is available, PyTorch-visible
GPU name(s), total GPU memory, compute capability, cuDNN version, and thread counts.
Optional hardware probes never make data-only preflight fail.

Training adds synchronized wall-clock fields to `training/training_history.csv`:

```text
train_phase_time_s
train_samples_per_s
validation_time_s
validation_points_per_s
epoch_wall_time_s
elapsed_training_wall_time_s
```

and writes:

```text
training/timing_summary.json
```

`training_summary.json` also stores total training-loop and `train_model` wall times.
On CUDA, timing boundaries call `torch.cuda.synchronize()` so asynchronous GPU work is
not under-counted.

Each full prediction export additionally writes:

```text
inference_timing.csv
inference_timing_summary.json
```

`prediction_time_s` is measured per complete parameter case and covers DeepONet
prediction of all `73 × 3534 = 257,982` spatiotemporal query points, including branch /
trunk evaluation, inverse normalization and device-to-host transfer inside
`predict_case`. It deliberately excludes memmap writes, SHA256 hashing and metric
evaluation. Source and OOD timing therefore have a clear, identical scope.

If a v2.1.1 export already exists without timing fields, v2.1.2 will not silently reuse
it as a timed export. Rebuild intentionally with `--overwrite` if timing is required.

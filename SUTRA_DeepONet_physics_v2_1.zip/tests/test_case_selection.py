import pandas as pd
import pytest

from src.case_selection import select_case_by_ah


def test_case_selection_and_split_gate():
    df = pd.DataFrame([
        {"case_index": 0, "case_id": "a", "amplitude_m": 0.6, "h_land_m": 2.55, "split": "test", "design_regime": "x"}
    ])
    s = select_case_by_ah(df, 0.6, 2.55, "test")
    assert s.case_id == "a"
    with pytest.raises(ValueError):
        select_case_by_ah(df, 0.6, 2.55, "train")

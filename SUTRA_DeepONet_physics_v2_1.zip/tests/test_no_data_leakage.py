import numpy as np

from src.normalization import fit_train_only_normalizer
from src.reference_data import CanonicalReferenceData


def test_normalizer_uses_train_only(mini_source):
    # Deliberately contaminate validation/test targets with huge values before loading.
    psi = np.load(mini_source / "pressure_head_m.npy", mmap_mode="r+")
    con = np.load(mini_source / "concentration.npy", mmap_mode="r+")
    psi[2:] = 1.0e6
    con[2:] = 1.0e3
    psi.flush(); con.flush()
    del psi, con

    data = CanonicalReferenceData(mini_source)
    train_idx = data.get_split_indices("train")
    expected_branch = np.asarray(data.branch[train_idx], dtype=np.float64)
    expected_psi = np.asarray(data.pressure_head[train_idx], dtype=np.float64)
    expected_con = np.asarray(data.concentration[train_idx], dtype=np.float64)

    norm, meta = fit_train_only_normalizer(data, {"x_scale_m": 10, "z_scale_m": 4, "t_scale_s": 259200})

    assert np.allclose(norm.branch_mean, expected_branch.mean(axis=0).astype(np.float32))
    assert np.isclose(norm.target_mean[0], expected_psi.mean(), rtol=1e-6)
    assert np.isclose(norm.target_mean[1], expected_con.mean(), rtol=1e-6)
    assert norm.target_mean[0] < 100.0  # would fail catastrophically if val/test leaked in
    assert norm.target_mean[1] < 1.0
    assert meta["fit_split"] == "train"
    assert meta["fit_case_ids"] == ["case_0", "case_1"]

import numpy as np

from src.metrics import metrics_1d


def test_rl2e_formula_and_zero_denominator():
    true = np.array([1.0, 2.0, 3.0])
    pred = np.array([1.0, 1.0, 5.0])
    m = metrics_1d(true, pred)
    expected = np.sqrt((0.0**2 + (-1.0)**2 + 2.0**2) / (1.0**2 + 2.0**2 + 3.0**2))
    assert np.isclose(m["rl2e"], expected)
    z = metrics_1d(np.zeros(4), np.ones(4))
    assert np.isnan(z["rl2e"])

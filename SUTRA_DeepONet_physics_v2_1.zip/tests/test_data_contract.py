from src.reference_data import CanonicalReferenceData


def test_canonical_reader_shapes(mini_source):
    data = CanonicalReferenceData(mini_source)
    assert data.branch.shape == (4, 2)
    assert data.pressure_head.shape == (4, 4, 6)
    assert data.concentration.shape == (4, 4, 6)
    assert data.get_split_indices("train").tolist() == [0, 1]
    assert data.get_split_indices("validation").tolist() == [2]
    assert data.get_split_indices("test").tolist() == [3]

import numpy as np

from src.adaptive_weighting import ReLoBRaLoGroupBalancer


def test_relobralo_weights_stay_positive_clamped_and_mean_one():
    names = ["a","b","c","d","e","f"]
    b = ReLoBRaLoGroupBalancer(names, alpha_memory=.95, temperature=.2, expected_rho=.99,
                                weight_min=.2, weight_max=5.0, seed=20269692)
    w0 = b.current_weights()
    assert all(v == 1.0 for v in w0.values())
    for k in range(10):
        w = b.update({n: float((i+1)*(k+1)) for i,n in enumerate(names)})
        arr = np.array(list(w.values()))
        assert np.isfinite(arr).all()
        assert (arr >= .2 - 1e-12).all()
        assert (arr <= 5.0 + 1e-12).all()
        assert abs(arr.mean()-1.0) < 1e-10

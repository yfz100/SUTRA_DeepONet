import json

import pandas as pd
import torch

from src.reference_data import CanonicalReferenceData
from src.training import train_model
from tests.physics_test_utils import mini_physics_config


def test_physics_only_training_does_not_use_transient_target_statistics(physics_source, tmp_path):
    data = CanonicalReferenceData(physics_source)
    cfg = mini_physics_config("physics_only")
    run = tmp_path / "po"
    s = train_model(cfg, data, run, torch.device("cpu"))
    assert s["training_mode"] == "physics_only"
    assert s["alpha_phys_target"] is None
    meta = json.loads((run / "normalization" / "normalizer_metadata.json").read_text(encoding="utf-8"))
    assert meta["transient_target_statistics_used"] is False
    assert "n_fit_points_per_target" not in meta
    hist = pd.read_csv(run / "training" / "training_history.csv")
    assert hist["train_data_loss_norm"].isna().all()
    assert "val_physics_loss" in hist.columns
    assert (run / "sampling" / "physics_validation_plan.npz").exists()


def test_hybrid_alpha_and_six_groups_are_logged(physics_source, tmp_path):
    data = CanonicalReferenceData(physics_source)
    cfg = mini_physics_config("hybrid", 0.5)
    run = tmp_path / "hyb"
    s = train_model(cfg, data, run, torch.device("cpu"))
    assert s["alpha_phys_target"] == 0.5
    hist = pd.read_csv(run / "training" / "training_history.csv")
    # Epoch 1 of a 200-epoch ramp.
    assert abs(float(hist.loc[0, "alpha_phys_effective"]) - 0.5/200.0) < 1e-12
    weight_cols = [c for c in hist.columns if c.startswith("group_") and c.endswith("_weight_used")]
    assert len(weight_cols) == 6

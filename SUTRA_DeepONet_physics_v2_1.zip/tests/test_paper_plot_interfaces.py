from pathlib import Path

import numpy as np
import pandas as pd

from src.reference_data import CanonicalReferenceData


def _make_export(data, run):
    out = run / "exports" / "source"
    out.mkdir(parents=True)
    np.save(out / "pred_pressure_head_m.npy", np.asarray(data.pressure_head, dtype=np.float32))
    np.save(out / "pred_concentration.npy", np.asarray(data.concentration, dtype=np.float32))
    data.case_metadata.to_csv(out / "case_metadata.csv", index=False)
    (out / "EXPORT_COMPLETE").write_text('{"completed":true}', encoding="utf-8")
    return out


def test_paper_plot_scripts_read_exports_without_model(mini_source, tmp_path, monkeypatch):
    data = CanonicalReferenceData(mini_source)
    run = tmp_path / "run"
    _make_export(data, run)
    reference_root = tmp_path / "reference_library"
    (reference_root / "source_range").mkdir(parents=True)
    # Symlink-like copy path expected by paper common; use rename-free directory junction via copying small test files.
    import shutil
    shutil.copytree(mini_source, reference_root / "source_range" / "processed")

    from paper_plots import plot_pressure_timeseries as pp
    from paper_plots import plot_concentration_timeseries as cp
    from paper_plots import plot_field_reconstruction as fp

    outdir = tmp_path / "figs"
    for mod in [pp, cp]:
        monkeypatch.setattr(mod, "REFERENCE_LIBRARY_ROOT", reference_root)
        monkeypatch.setattr(mod, "RUN_DIR", run)
        monkeypatch.setattr(mod, "OUTPUT_DIR", outdir)
        monkeypatch.setattr(mod, "AMPLITUDE", 0.4)
        monkeypatch.setattr(mod, "H_LAND", 2.6)
        monkeypatch.setattr(mod, "EXPECTED_SPLIT", "test")
        monkeypatch.setattr(mod, "DPI", 40)
        mod.main()

    monkeypatch.setattr(fp, "REFERENCE_LIBRARY_ROOT", reference_root)
    monkeypatch.setattr(fp, "RUN_DIR", run)
    monkeypatch.setattr(fp, "OUTPUT_DIR", outdir)
    monkeypatch.setattr(fp, "DPI", 40)
    monkeypatch.setattr(fp, "CASES_TO_PLOT", [
        {"amplitude": 0.4, "h_land": 2.6, "time_h": 1.0, "expected_split": "test", "show_points": True}
    ])
    fp.main()

    assert list(outdir.glob("*.png"))
    assert (outdir / "representative_points_resolved.csv").exists()

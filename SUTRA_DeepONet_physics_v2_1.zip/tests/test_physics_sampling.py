import numpy as np

from src.physics_engine import ALL_TERMS
from src.physics_sampling import (
    create_fixed_physics_validation_plan,
    detect_boundaries,
    sample_physics_indices,
    validate_fixed_physics_validation_plan,
)
from src.reference_data import CanonicalReferenceData
from tests.physics_test_utils import mini_physics_config


def test_boundary_detection_and_term_sampling(physics_source, tmp_path):
    data = CanonicalReferenceData(physics_source)
    cfg = mini_physics_config("physics_only")
    b = detect_boundaries(np.asarray(data.coords), cfg["physics_regularization"]["boundary_detection"])
    assert len(b.land_nodes) == 3
    assert len(b.sea_nodes) == 5
    assert len(b.bottom_nodes) == 2
    assert len(b.top_nodes) == 2
    assert len(b.interior_nodes) >= 1

    pcfg = dict(cfg["physics_regularization"]["common_physics"])
    pcfg.update(cfg["physics_regularization"]["sampling"])
    for i, term in enumerate(ALL_TERMS):
        idx = sample_physics_indices(data, b, "train", term, 5, 11, 1, i, pcfg)
        assert idx.size == 5
        assert set(np.unique(idx.case_index)).issubset(set(data.get_split_indices("train")))
        if term in {"ic_psi", "ic_u"}:
            assert np.all(idx.time_index == 0)
        if term in {"sea_p", "sea_inflow_u"}:
            z = np.asarray(data.coords[idx.node_index, 1])
            A = np.asarray(data.branch[idx.case_index, 0])
            eta = 2.5 + A * np.sin(2*np.pi*np.asarray(data.times[idx.time_index])/43200.0)
            assert np.all(z <= eta + 1e-9)
        if term in {"exposed_flow", "exposed_solute"}:
            z = np.asarray(data.coords[idx.node_index, 1])
            A = np.asarray(data.branch[idx.case_index, 0])
            eta = 2.5 + A * np.sin(2*np.pi*np.asarray(data.times[idx.time_index])/43200.0)
            assert np.all(z > eta + 1e-9)

    sizes = cfg["physics_regularization"]["batch_sizes"]["physics_only"]
    plan = create_fixed_physics_validation_plan(
        data, b, sizes, 2, 1.0, 99, pcfg, tmp_path / "phys_val.npz"
    )
    validate_fixed_physics_validation_plan(data, plan, sizes, 2, 1.0)

from pathlib import Path

import torch

from src.export_store import export_library_predictions, validate_prediction_export
from src.metrics import evaluate_prediction_export
from src.reference_data import CanonicalReferenceData
from src.training import train_model
from tests.physics_test_utils import mini_physics_config


def test_hybrid_train_export_metrics_core(physics_source, tmp_path):
    data = CanonicalReferenceData(physics_source)
    cfg = mini_physics_config("hybrid", 0.1)
    run = tmp_path / "run"
    summary = train_model(cfg, data, run, torch.device("cpu"))
    assert summary["training_mode"] == "hybrid"
    assert summary["best_epoch"] >= 1
    out = export_library_predictions(cfg, data, run, "best", torch.device("cpu"), overwrite=False)
    assert validate_prediction_export(data, out)["passed"]
    m = evaluate_prediction_export(data, out, run / "metrics" / "source")
    assert m["n_case_rows"] == data.n_case
    assert m["n_case_time_rows"] == data.n_case * data.n_time

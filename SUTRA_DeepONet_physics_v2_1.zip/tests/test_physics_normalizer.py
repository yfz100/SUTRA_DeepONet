import numpy as np

from src.normalization import fit_physics_only_normalizer
from src.reference_data import CanonicalReferenceData


def test_physics_only_normalizer_ignores_all_target_values(physics_source):
    data0 = CanonicalReferenceData(physics_source)
    n0, m0 = fit_physics_only_normalizer(data0, {"x_scale_m":10,"z_scale_m":4,"t_scale_s":259200})
    psi = np.load(physics_source / "pressure_head_m.npy", mmap_mode="r+")
    con = np.load(physics_source / "concentration.npy", mmap_mode="r+")
    psi[:] = 9.9e5
    con[:] = -8.8e4
    psi.flush(); con.flush(); del psi, con
    data1 = CanonicalReferenceData(physics_source)
    n1, m1 = fit_physics_only_normalizer(data1, {"x_scale_m":10,"z_scale_m":4,"t_scale_s":259200})
    assert np.array_equal(n0.branch_mean, n1.branch_mean)
    assert np.array_equal(n0.branch_std, n1.branch_std)
    assert np.array_equal(n0.target_mean, n1.target_mean)
    assert np.array_equal(n0.target_std, n1.target_std)
    assert m1["transient_target_statistics_used"] is False

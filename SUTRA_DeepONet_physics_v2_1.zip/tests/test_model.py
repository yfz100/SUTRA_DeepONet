import torch
from src.model import MultiOutputDeepONet


def test_model_shapes_and_single_branch_latent_broadcast():
    m = MultiOutputDeepONet(branch_dim=2, trunk_dim=7, latent_dim=8, output_dim=2, branch_hidden=[8], trunk_hidden=[8])
    b = torch.randn(5, 2)
    x = torch.randn(5, 7)
    y = m(b, x)
    assert y.shape == (5, 2)
    one_b = m.encode_branch(b[:1])
    tx = m.encode_trunk(x)
    y2 = m.combine_latents(one_b, tx)
    assert y2.shape == (5, 2)

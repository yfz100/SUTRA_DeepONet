import numpy as np

from src.features import build_trunk_features
from src.normalization import fit_train_only_normalizer
from src.reference_data import CanonicalReferenceData
from src.sampling import UniformTripletBatchSampler, create_fixed_validation_indices


def test_vectorized_sampler_and_fixed_validation(mini_source, tmp_path):
    data = CanonicalReferenceData(mini_source)
    norm, _ = fit_train_only_normalizer(data, {"x_scale_m": 10, "z_scale_m": 4, "t_scale_s": 259200})
    trunk = build_trunk_features(data, norm, tidal_period_s=43200)
    sampler = UniformTripletBatchSampler(data, norm, trunk, "train", seed=7)
    b = sampler.batch(epoch=1, batch_number=0, size=32)
    assert b.branch.shape == (32, 2)
    assert b.trunk.shape == (32, 7)
    assert b.target.shape == (32, 2)
    assert np.isfinite(b.target).all()

    sample = create_fixed_validation_indices(data, points_per_case=5, seed=11, path=tmp_path / "val.npz")
    assert len(sample["case_index"]) == 5
    assert np.unique(sample["case_index"]).tolist() == [2]
    flat = sample["time_index"] * data.n_node + sample["node_index"]
    assert len(np.unique(flat)) == 5

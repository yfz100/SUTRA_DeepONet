import numpy as np
import torch

from src.model import build_model
from src.normalization import fit_physics_only_normalizer, fit_train_only_normalizer
from src.physics_engine import ALL_TERMS
from src.physics_losses import compute_physics_term
from src.physics_sampling import detect_boundaries, sample_physics_indices
from src.reference_data import CanonicalReferenceData
from tests.physics_test_utils import mini_physics_config


def _check_all_terms(mode, physics_source):
    data = CanonicalReferenceData(physics_source)
    cfg = mini_physics_config(mode, 0.1)
    if mode == "hybrid":
        norm, _ = fit_train_only_normalizer(data, cfg["physics"])
    else:
        norm, _ = fit_physics_only_normalizer(data, cfg["physics"])
    b = detect_boundaries(np.asarray(data.coords), cfg["physics_regularization"]["boundary_detection"])
    pcfg = dict(cfg["physics_regularization"]["common_physics"])
    pcfg.update(cfg["physics_regularization"]["sampling"])
    model = build_model(cfg)
    losses = []
    for i, term in enumerate(ALL_TERMS):
        idx = sample_physics_indices(data, b, "train", term, 2, 77, 1, i, pcfg)
        d = compute_physics_term(term, model, data, norm, idx, torch.device("cpu"), pcfg, b)
        assert torch.isfinite(d.loss)
        assert torch.isfinite(d.raw_mse)
        assert d.scale > 0
        losses.append(d.loss)
    total = torch.stack(losses).mean()
    total.backward()
    grads = [p.grad for p in model.parameters() if p.grad is not None]
    assert grads
    assert all(torch.isfinite(g).all() for g in grads)


def test_all_physics_terms_hybrid_are_finite_and_differentiable(physics_source):
    _check_all_terms("hybrid", physics_source)


def test_all_physics_terms_physics_only_are_finite_and_differentiable(physics_source):
    _check_all_terms("physics_only", physics_source)

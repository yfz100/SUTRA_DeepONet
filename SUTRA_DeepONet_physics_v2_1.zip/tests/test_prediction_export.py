from pathlib import Path

import numpy as np
import torch

from src.export_store import export_library_predictions, validate_prediction_export
from src.model import build_model
from src.normalization import fit_train_only_normalizer, save_normalizer
from src.reference_data import CanonicalReferenceData


def test_prediction_export_without_true_duplication(mini_source, tmp_path):
    data = CanonicalReferenceData(mini_source)
    cfg = {
        "physics": {"tidal_period_s": 43200.0, "x_scale_m": 10.0, "z_scale_m": 4.0, "t_scale_s": 259200.0},
        "model": {"branch_dim": 2, "trunk_dim": 7, "latent_dim": 8, "output_dim": 2, "branch_hidden": [8], "trunk_hidden": [8], "activation": "silu", "dropout": 0.0},
        "inference": {"batch_size": 16},
    }
    run = tmp_path / "run"
    (run / "checkpoints").mkdir(parents=True)
    norm, meta = fit_train_only_normalizer(data, cfg["physics"])
    save_normalizer(norm, meta, run / "normalization")
    model = build_model(cfg)
    torch.save({"epoch": 1, "model_state_dict": model.state_dict(), "config": cfg}, run / "checkpoints" / "best.pt")
    out = export_library_predictions(cfg, data, run, "best", torch.device("cpu"), overwrite=False)
    rep = validate_prediction_export(data, out)
    assert rep["passed"]
    assert not (out / "true_pressure_head_m.npy").exists()
    assert not (out / "error_pressure_head_m.npy").exists()
    assert np.load(out / "pred_pressure_head_m.npy", mmap_mode="r").shape == (4, 4, 6)

from __future__ import annotations

import json

import pandas as pd
import torch

from src.export_store import export_library_predictions, validate_prediction_export
from src.reference_data import CanonicalReferenceData
from src.training import train_model
from src.utils import collect_environment
from tests.physics_test_utils import mini_physics_config


def test_environment_metadata_is_best_effort():
    env = collect_environment()
    assert "cpu_model" in env
    assert "cpu_logical_cores" in env
    assert "system_memory_total_gb" in env
    assert "torch_installed" in env
    assert "gpu_devices" in env
    assert "nvidia_driver_version" in env


def test_training_and_inference_timing_files(physics_source, tmp_path):
    data = CanonicalReferenceData(physics_source)
    cfg = mini_physics_config("hybrid", 0.1)
    run = tmp_path / "run"

    summary = train_model(cfg, data, run, torch.device("cpu"))
    assert summary["timing_instrumentation_version"] == "1.0"
    assert summary["training_loop_wall_time_s"] > 0
    assert summary["train_model_total_wall_time_s"] > 0

    history = pd.read_csv(run / "training" / "training_history.csv")
    for col in [
        "train_phase_time_s",
        "train_samples_per_s",
        "validation_time_s",
        "epoch_wall_time_s",
        "elapsed_training_wall_time_s",
    ]:
        assert col in history.columns
    assert (history["train_phase_time_s"] > 0).all()
    assert (history["epoch_wall_time_s"] > 0).all()

    timing_summary = json.loads((run / "training" / "timing_summary.json").read_text(encoding="utf-8"))
    assert timing_summary["timing_instrumentation_version"] == "1.0"
    assert timing_summary["device"] == "cpu"
    assert timing_summary["cuda_synchronized_at_gpu_phase_boundaries"] is False
    assert timing_summary["training_mode"] == "hybrid"

    out = export_library_predictions(cfg, data, run, "best", torch.device("cpu"), overwrite=False)
    assert validate_prediction_export(data, out)["passed"]

    timing = pd.read_csv(out / "inference_timing.csv")
    assert len(timing) == data.n_case
    assert (timing["prediction_time_s"] > 0).all()
    assert (timing["n_query_points"] == data.n_time * data.n_node).all()

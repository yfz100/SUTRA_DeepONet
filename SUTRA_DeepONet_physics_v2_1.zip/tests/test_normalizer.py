import numpy as np

from src.normalization import Normalizer


def test_normalizer_round_trip():
    n = Normalizer(
        branch_mean=np.array([0.3, 2.8], np.float32),
        branch_std=np.array([0.2, 0.4], np.float32),
        target_mean=np.array([1.1, 0.02], np.float32),
        target_std=np.array([0.5, 0.01], np.float32),
        x_scale_m=10,
        z_scale_m=4,
        t_scale_s=259200,
    )
    y = np.array([[1.2, 0.03], [0.9, -0.01]], np.float32)
    assert np.allclose(n.target_from_norm(n.target_to_norm(y)), y, atol=1e-7)

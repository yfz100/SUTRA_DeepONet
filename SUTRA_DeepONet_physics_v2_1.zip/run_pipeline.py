"""Unified pipeline for SUTRA–DeepONet Section 4.2 physics comparison.

Edit only Section A. The package supports:
  TRAINING_MODE = "hybrid"       -> data + ReLoBRaLo physics regularization
  TRAINING_MODE = "physics_only" -> ReLoBRaLo physics only

Formal Hybrid runs use ALPHA_PHYS = 0.1 and 0.5. Physics-only ignores ALPHA_PHYS.
"""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path
from typing import Any

from src.physics_engine import DEFAULT_GROUPS
from src.utils import collect_environment, ensure_dir, save_json, save_yaml, timestamp


# =============================================================================
# A. USER PARAMETER BLOCK
# =============================================================================
PROJECT_ROOT = Path(__file__).resolve().parent

# AutoDL canonical reference library. Change only if your actual path differs.
REFERENCE_LIBRARY_ROOT = Path("/root/reference_library")
SOURCE_PROCESSED_DIR = REFERENCE_LIBRARY_ROOT / "source_range" / "processed"
OOD_PROCESSED_DIR = REFERENCE_LIBRARY_ROOT / "higher_amplitude" / "processed"
MANIFEST_PATH = REFERENCE_LIBRARY_ROOT / "SUTRA_case_manifest_v2.1_2026-09-29.csv"

RUN_ROOT = PROJECT_ROOT / "runs"
USE_TIMESTAMP_IN_RUN_NAME = True
EXISTING_RUN_DIR: str | None = None

# Formal Section 4.2 choices.
TRAINING_MODE = "hybrid"      # "hybrid" or "physics_only"
ALPHA_PHYS = 0.1              # Hybrid formal values: 0.1 and 0.5; ignored by Physics-only.

# Safe first-release defaults: preflight only. Enable training only after preflight review.
DO_PREFLIGHT = True
DO_TRAIN = False
DO_EXPORT_SOURCE = False
DO_EVALUATE_SOURCE = False
DO_EXPORT_OOD = False
DO_EVALUATE_OOD = False
DO_DIAGNOSTIC_PLOTS = False
DO_VERIFY_RUN = False

CHECKPOINT_FOR_EXPORT = "best"
OVERWRITE_EXPORTS = False

SEED = 20260602
DEVICE = "auto"
CUDA_VISIBLE_DEVICES: str | None = None

# Architecture: frozen to the pure-supervised baseline capacity.
LATENT_DIM = 256
BRANCH_HIDDEN = [128, 128, 128]
TRUNK_HIDDEN = [256, 256, 256, 256]
ACTIVATION = "silu"
DROPOUT = 0.0

# Formal optimizer/training settings.
EPOCHS = 800
BATCH_SIZE = 8192
NUM_SAMPLES_PER_EPOCH = 524288
PHYSICS_BATCHES_PER_EPOCH = 64
LEARNING_RATE = 1.0e-3
WEIGHT_DECAY = 1.0e-6
GRAD_CLIP_NORM = 1.0
LOSS_WEIGHTS = [1.0, 1.0]
VAL_EVERY_EPOCHS = 5
VAL_POINTS_PER_CASE = 10602
VALIDATION_SEED = 20260602 + 1000003
EARLY_STOPPING_PATIENCE_EPOCHS = 120
USE_REDUCE_ON_PLATEAU = True
SCHEDULER_FACTOR = 0.5
SCHEDULER_PATIENCE = 6
MIN_LR = 1.0e-5
INFERENCE_BATCH_SIZE = 65536
NORMALIZATION_EPS = 1.0e-12

# ReLoBRaLo: frozen from the old formal physics experiments.
RELO_ALPHA_MEMORY = 0.95
RELO_TEMPERATURE = 0.2
RELO_EXPECTED_RHO = 0.99
RELO_WEIGHT_MIN = 0.2
RELO_WEIGHT_MAX = 5.0
RELO_SEED = 20269692
ALPHA_PHYS_RAMP_EPOCHS = 200

# Fixed Physics-only validation plan: old design = 8 batches at 0.5 batch scale.
PHYSICS_VAL_BATCHES = 8
PHYSICS_VAL_BATCH_SCALE = 0.5
PHYSICS_VALIDATION_SEED = 20260602 + 2000003
# =============================================================================
# B. END USER PARAMETER BLOCK
# =============================================================================


def _mode() -> str:
    mode = str(TRAINING_MODE).lower().strip()
    if mode not in {"hybrid", "physics_only"}:
        raise ValueError(f"TRAINING_MODE must be 'hybrid' or 'physics_only', got {TRAINING_MODE!r}")
    if mode == "hybrid" and float(ALPHA_PHYS) not in {0.1, 0.5}:
        print(
            f"WARNING: formal manuscript design uses ALPHA_PHYS=0.1 or 0.5; current value={ALPHA_PHYS}. "
            "Use non-formal values only for debugging."
        )
    return mode


def make_run_name() -> str:
    mode = _mode()
    tag = f"hybrid_alpha{float(ALPHA_PHYS):.1f}" if mode == "hybrid" else "physics_only"
    base = f"physics_v2_1_{tag}"
    return f"{base}_{timestamp()}" if USE_TIMESTAMP_IN_RUN_NAME else base


def build_config() -> dict[str, Any]:
    mode = _mode()
    # Preserve old per-mode collocation batch sizes.
    hybrid_sizes = {
        "flow_pde": 256,
        "transport_pde": 256,
        "ic_psi": 1024,
        "ic_u": 1024,
        "land_p": 512,
        "sea_p": 512,
        "land_u": 512,
        "sea_inflow_u": 512,
        "bottom_flow": 512,
        "bottom_solute": 512,
        "top_flow": 512,
        "top_solute": 512,
        "exposed_flow": 512,
        "exposed_solute": 512,
    }
    physics_only_sizes = {
        "flow_pde": 64,
        "transport_pde": 64,
        "ic_psi": 256,
        "ic_u": 256,
        "land_p": 128,
        "sea_p": 128,
        "land_u": 128,
        "sea_inflow_u": 128,
        "bottom_flow": 128,
        "bottom_solute": 128,
        "top_flow": 128,
        "top_solute": 128,
        "exposed_flow": 128,
        "exposed_solute": 128,
    }
    return {
        "project": {
            "name": "SUTRA_DeepONet_physics_v2_1",
            "version": "2.1.0-preflight",
            "description": "Controlled Section 4.2 Hybrid/Physics-only DeepONet comparison with six-group ReLoBRaLo",
            "seed": int(SEED),
        },
        "paths": {
            "source_processed_dir": str(SOURCE_PROCESSED_DIR.expanduser().resolve()),
            "ood_processed_dir": str(OOD_PROCESSED_DIR.expanduser().resolve()),
            "manifest_path": str(MANIFEST_PATH.expanduser().resolve()),
            "run_root": str(Path(RUN_ROOT).expanduser().resolve()),
        },
        "physics": {
            "tidal_period_s": 43200.0,
            "x_scale_m": 10.0,
            "z_scale_m": 4.0,
            "t_scale_s": 259200.0,
            "pressure_head_definition": "pressure_pa / 9810.0",
            "branch_order": ["amplitude_m", "h_land_m"],
            "trunk_order": ["x_scaled", "z_scaled", "t_scaled", "sin_wt", "cos_wt", "sin_2wt", "cos_2wt"],
            "target_order": ["pressure_head_m", "concentration"],
        },
        "normalization": {
            "eps": float(NORMALIZATION_EPS),
            "hybrid": {"target_scale_mode": "source_train_data_stats"},
            "physics_only": {
                "target_scale_mode": "physical_prior",
                "target_mean_physical": [0.0, 0.0],
                "target_std_physical": [4.0, 0.0357],
                "transient_target_statistics_used": False,
            },
        },
        "model": {
            "branch_dim": 2,
            "trunk_dim": 7,
            "latent_dim": int(LATENT_DIM),
            "output_dim": 2,
            "branch_hidden": list(BRANCH_HIDDEN),
            "trunk_hidden": list(TRUNK_HIDDEN),
            "activation": ACTIVATION,
            "dropout": float(DROPOUT),
        },
        "training": {
            "mode": mode,
            "device": DEVICE,
            "epochs": int(EPOCHS),
            "batch_size": int(BATCH_SIZE),
            "num_samples_per_epoch": int(NUM_SAMPLES_PER_EPOCH),
            "physics_batches_per_epoch": int(PHYSICS_BATCHES_PER_EPOCH),
            "learning_rate": float(LEARNING_RATE),
            "weight_decay": float(WEIGHT_DECAY),
            "grad_clip_norm": float(GRAD_CLIP_NORM),
            "loss_weights": [float(v) for v in LOSS_WEIGHTS],
            "val_every_epochs": int(VAL_EVERY_EPOCHS),
            "val_points_per_case": int(VAL_POINTS_PER_CASE),
            "validation_seed": int(VALIDATION_SEED),
            "early_stopping_patience_epochs": int(EARLY_STOPPING_PATIENCE_EPOCHS),
            "scheduler": {
                "use_reduce_on_plateau": bool(USE_REDUCE_ON_PLATEAU),
                "factor": float(SCHEDULER_FACTOR),
                "patience": int(SCHEDULER_PATIENCE),
                "min_lr": float(MIN_LR),
            },
        },
        "physics_regularization": {
            "enabled": True,
            "formulation": "continuous strong form; not SUTRA finite-element/upstream algebraic residual",
            "initial_condition_semantics": "canonical H-dependent prescribed COLD t=0 pressure state; C0=0",
            "boundary_detection": {
                "land_x_tolerance_m": 1.0e-6,
                "horizontal_z_tolerance_m": 1.0e-6,
                "sea_line_x0": 10.0,
                "sea_line_slope": -1.75,
                "sea_line_tolerance_m": 2.0e-5,
                "interior_boundary_margin_m": 0.05,
                "top_z_m": 4.0,
            },
            "common_physics": {
                "gamma_ref_pa_per_m": 9810.0,
                "gamma_sea_pa_per_m": 10055.1519,
                "rho0_kg_m3": 1000.0,
                "c_ref": 0.0,
                "drho_dC_kg_m3": 700.0,
                "density_clip_enabled": False,
                "viscosity_pa_s": 1.0e-3,
                "permeability_m2": 1.0e-10,
                "gravity_x_m_s2": 0.0,
                "gravity_z_m_s2": -9.81,
                "porosity": 0.46,
                "matrix_compressibility_per_pa": 1.0e-8,
                "fluid_compressibility_per_pa": 0.0,
                "swres": 0.30,
                "aa_inv_pa": 5.0e-5,
                "vg_n": 2.0,
                "molecular_diffusivity_m2_s": 1.0e-9,
                "alpha_l_m": 2.0e-3,
                "alpha_t_m": 2.0e-4,
                "tidal_period_s": 43200.0,
                "eta0_m": 2.5,
                "phase_rad": 0.0,
                "sea_concentration": 0.0357,
                "land_concentration": 0.0,
                "normalization_eps": 1.0e-12,
                "length_scale_m": 10.0,
                "time_scale_s": 259200.0,
                "flow_flux_scale_m_s": 1.0e-4,
                "solute_flux_scale": 0.0,
                "inflow_weight_mode": "smooth_relu",
                "inflow_flux_tolerance_m_s": 0.0,
            },
            "sampling": {
                "eta0_m": 2.5,
                "tidal_period_s": 43200.0,
                "phase_rad": 0.0,
                "active_tolerance_m": 1.0e-9,
                "exclude_first_last_time": True,
            },
            "batch_sizes": {"hybrid": hybrid_sizes, "physics_only": physics_only_sizes},
            "relobralo": {
                "enabled": True,
                "method": "anchored_group_relobralo" if mode == "hybrid" else "group_relobralo_physics_only",
                "data_anchor_weight": 1.0 if mode == "hybrid" else None,
                "alpha_phys": float(ALPHA_PHYS) if mode == "hybrid" else None,
                "ramp_epochs": int(ALPHA_PHYS_RAMP_EPOCHS),
                "update_level": "epoch_mean",
                "alpha_memory": float(RELO_ALPHA_MEMORY),
                "temperature": float(RELO_TEMPERATURE),
                "expected_rho": float(RELO_EXPECTED_RHO),
                "group_weight_min": float(RELO_WEIGHT_MIN),
                "group_weight_max": float(RELO_WEIGHT_MAX),
                "renormalize_after_clamp": True,
                "eps": 1.0e-12,
                "seed": int(RELO_SEED),
                "use_group_mean": True,
                "groups": DEFAULT_GROUPS,
                "legacy_term_lambda_0p1_active": False,
            },
            "physics_validation": {
                "n_batches": int(PHYSICS_VAL_BATCHES),
                "batch_scale": float(PHYSICS_VAL_BATCH_SCALE),
                "seed": int(PHYSICS_VALIDATION_SEED),
                "fixed_plan": True,
            },
        },
        "inference": {"batch_size": int(INFERENCE_BATCH_SIZE), "checkpoint": CHECKPOINT_FOR_EXPORT},
        "metrics": {
            "physical_space": True,
            "reduction_dtype": "float64",
            "names": ["rmse", "mae", "rl2e", "bias", "max_abs_error", "p95_abs_error", "p99_abs_error"],
        },
    }


def run_module(module: str, args: list[str], env: dict[str, str]) -> None:
    cmd = [sys.executable, "-m", module, *args]
    print("\n>>> " + " ".join(cmd))
    subprocess.run(cmd, cwd=PROJECT_ROOT, env=env, check=True)


def main() -> None:
    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    if CUDA_VISIBLE_DEVICES is not None:
        env["CUDA_VISIBLE_DEVICES"] = str(CUDA_VISIBLE_DEVICES)
        os.environ["CUDA_VISIBLE_DEVICES"] = str(CUDA_VISIBLE_DEVICES)

    if EXISTING_RUN_DIR:
        run_dir = Path(EXISTING_RUN_DIR).expanduser().resolve()
        config_path = run_dir / "config_used.yaml"
        if not config_path.exists():
            raise FileNotFoundError(config_path)
        if DO_TRAIN and (run_dir / "checkpoints" / "best.pt").exists():
            raise FileExistsError("Automatic training resume/overwrite is disabled; use a new run directory.")
        print(f"Using frozen existing-run config: {config_path}")
    else:
        run_dir = ensure_dir(Path(RUN_ROOT) / make_run_name())
        config_path = run_dir / "config_used.yaml"
        if config_path.exists():
            raise FileExistsError(config_path)
        save_yaml(build_config(), config_path)
        env_info = collect_environment()
        env_info["requested_device"] = DEVICE
        env_info["cuda_visible_devices_for_subprocess"] = CUDA_VISIBLE_DEVICES
        env_info["section_4_2_training_mode"] = _mode()
        env_info["alpha_phys_target"] = float(ALPHA_PHYS) if _mode() == "hybrid" else None
        save_json(env_info, run_dir / "environment.json")

    print(f"Run directory: {run_dir}")

    if DO_PREFLIGHT:
        args = ["--config", str(config_path), "--run-dir", str(run_dir)]
        if DO_TRAIN or DO_EXPORT_SOURCE or DO_EXPORT_OOD:
            args.append("--require-torch")
        run_module("scripts.quick_check", args, env)
    if DO_TRAIN:
        run_module("scripts.train", ["--config", str(config_path), "--run-dir", str(run_dir)], env)

    extra = ["--overwrite"] if OVERWRITE_EXPORTS else []
    if DO_EXPORT_SOURCE:
        run_module("scripts.export_predictions", ["--config", str(config_path), "--run-dir", str(run_dir), "--library", "source", "--checkpoint", CHECKPOINT_FOR_EXPORT, *extra], env)
    if DO_EVALUATE_SOURCE:
        run_module("scripts.evaluate_exports", ["--config", str(config_path), "--run-dir", str(run_dir), "--library", "source"], env)
    if DO_EXPORT_OOD:
        run_module("scripts.export_predictions", ["--config", str(config_path), "--run-dir", str(run_dir), "--library", "higher_amplitude", "--checkpoint", CHECKPOINT_FOR_EXPORT, *extra], env)
    if DO_EVALUATE_OOD:
        run_module("scripts.evaluate_exports", ["--config", str(config_path), "--run-dir", str(run_dir), "--library", "higher_amplitude"], env)
    if DO_DIAGNOSTIC_PLOTS:
        run_module("diagnostics.plot_training_history", ["--run-dir", str(run_dir)], env)
    if DO_VERIFY_RUN:
        run_module("scripts.verify_run", ["--config", str(config_path), "--run-dir", str(run_dir)], env)

    print("\nPipeline completed successfully.")
    print(f"Run directory: {run_dir}")


if __name__ == "__main__":
    main()

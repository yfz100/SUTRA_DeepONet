# Version verification — SUTRA_DeepONet_physics_v2_1 v2.1.0-preflight

Release date: 2026-10-02

## Purpose

Controlled Section 4.2 package for:

- Hybrid physics-regularized DeepONet with `alpha_phys=0.1`;
- Hybrid physics-regularized DeepONet with `alpha_phys=0.5`;
- Physics-only DeepONet;
- group-level ReLoBRaLo with the frozen old-experiment hyperparameters.

## Provenance

Engineering backbone:
- Pure-supervised v2.1.2 archive SHA256: `53d4a8c17426a6e2a078b7e1e3ff5043a66a34bb31022c6f6d1bd710400eeeda`

Audited old physics packages:
- HybridFullLite ReLoBRaLoGroup SHA256: `1eabf47c258b459e0bbd61605ff5afd5efffca4f9de2bcd7c2442ffc0d7403e2`
- PhysicsOnly ReLoBRaLoGroup SHA256: `236c8adf5f9dd23d804d11039c97fce8b9eb4ff906eb7c2fe424c3e963e8b838`

## Frozen methodological choices

- output-specific two-output DeepONet capacity identical to pure baseline;
- branch `[A,H_land]`, trunk 7-D;
- six ReLoBRaLo groups;
- `alpha_memory=.95`;
- `temperature=.2`;
- `expected_rho=.99`;
- clamp `[.2,5]`;
- epoch-mean updates;
- Hybrid data anchor 1;
- formal Hybrid `alpha_phys=.1/.5`;
- 200-epoch alpha ramp;
- Physics-only no `alpha_phys`;
- old per-mode physics batch sizes retained;
- continuous strong-form, not SUTRA-discrete residual.

## Required canonical corrections implemented

- case-specific land head;
- canonical `psi=p/9810`;
- sea-density pressure-head conversion;
- H-dependent COLD `t=0` pressure IC;
- top no-flow added;
- pressure-node concentration source applied only on predicted inflow;
- fixed Hybrid data validation;
- fixed Physics-only physics validation;
- pure v2.1.2 export/metrics/timing contracts inherited.

## Source-level verification

Executed in the build environment:

```text
python -m compileall -q .     PASS
pytest -q                     19 passed
```

The tests include:
- canonical reader/sampler/model/metrics inheritance;
- no-leakage train-only Hybrid normalizer;
- Physics-only normalizer independence from target values;
- canonical mini-trapezoid boundary detection;
- active/exposed marine sampling;
- fixed physics-validation plan;
- all 14 physics terms finite + differentiable in Hybrid and Physics-only modes;
- 1-epoch CPU Hybrid training/export/metrics integration;
- 1-epoch CPU Physics-only training;
- ReLoBRaLo clamp/renormalization;
- timing artifacts.

## Release gate

This is intentionally a **preflight release**, not a formally trained model release.

Distributed default:

```python
DO_PREFLIGHT = True
DO_TRAIN = False
```

The first AutoDL run must only generate and review `physics_preflight_report.json` and `data_contract_report.json`. Formal training remains gated behind an A800 1-epoch smoke test.

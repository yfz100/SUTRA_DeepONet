# Hardware & Timing Instrumentation — v2.1.2

## Scope

This patch is observational only. No scientific/ML computation is intentionally changed.

## Environment metadata

New runs extend `environment.json` with best-effort fields:

- CPU model;
- physical/logical CPU core counts where available;
- total system RAM;
- NVIDIA driver and `nvidia-smi` GPU records when available;
- PyTorch-visible GPU name, memory, compute capability and multiprocessor count;
- cuDNN version/enabled status;
- PyTorch intra/inter-op thread counts.

The probes are optional and never make data-only preflight fail.

## Training timing

`time.perf_counter()` is used. CUDA is explicitly synchronized at timing boundaries.

Per epoch:

- `train_phase_time_s`: sampler + host/device transfer + forward/backward + optimizer phase;
- `train_samples_per_s`;
- `validation_time_s` (only on validation epochs);
- `validation_points_per_s`;
- `epoch_wall_time_s`: epoch start through scheduler/best+last checkpoint handling; the final CSV rewrite itself is outside this interval;
- `elapsed_training_wall_time_s`.

Aggregate file `training/timing_summary.json` separates:

- setup wall time (normalizer/trunk/sample/model/optimizer setup before the epoch loop);
- training-loop wall time;
- total `train_model` wall time;
- cumulative train phase and validation times.

## Inference timing

Each case is timed separately with CUDA synchronization before and after `predict_case`.
The measured scope is the prediction itself for all `73×3534` points of one parameter case:

- branch encoding;
- trunk batches;
- latent combination;
- device-to-host transfer;
- inverse target normalization.

It excludes:

- writing prediction arrays to memmap;
- file hashes;
- metric evaluation;
- paper plotting.

Outputs:

- `inference_timing.csv` — one row per case;
- `inference_timing_summary.json` — total/mean/median/min/max case time and overall query throughput;
- timing summary is also embedded in `export_metadata.json`.

The first case is retained in all primary statistics. `mean_prediction_time_excluding_first_case_s` is additionally reported as a diagnostic for possible first-call CUDA warm-up overhead.

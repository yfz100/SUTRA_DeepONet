# Physics formulation and limitations — v2.1

## Model variables

DeepONet predicts physical pressure head and solute mass fraction after inverse normalization:

\[
\psi = p/\gamma_{ref},\qquad \gamma_{ref}=9810\ {\rm Pa\,m^{-1}},
\]
\[
C=\text{SUTRA transport variable / solute mass fraction}.
\]

Density is linear:

\[
\rho(C)=\rho_0+\rho_C(C-C_0),
\]

with \(\rho_0=1000\) kg m\(^{-3}\), \(\rho_C=700\) kg m\(^{-3}\), and no model-side density clipping.

## Darcy flux

\[
\mathbf q=-\frac{k k_r}{\mu}(\nabla p-\rho\mathbf g).
\]

VGEN saturation and relative permeability use the SUTRA2.2 user-subroutine formulas with `SWRES=0.30`, `AA=5e-5 1/Pa`, and `VN=2.0`. No `RKMIN` floor is imposed.

## Flow strong-form residual

The implementation follows the old audited density-aware residual:

\[
R_p=(S S_{op}+\varepsilon \partial S/\partial p)p_t
+\varepsilon S\frac{\rho_C}{\rho}C_t
+\nabla\cdot\mathbf q
+\frac{\rho_C}{\rho}\mathbf q\cdot\nabla C.
\]

Here

\[
S_{op}=(1-\varepsilon)\,COMPMA+\varepsilon\,COMPFL.
\]

## Transport strong-form residual

\[
R_C=\frac{\partial}{\partial t}(\varepsilon S\rho C)
+\nabla\cdot\left(\rho\mathbf qC-\varepsilon S\rho\mathbf D\nabla C\right).
\]

The hydrodynamic dispersion tensor uses pore-fluid velocity

\[
\mathbf v=\frac{\mathbf q}{\varepsilon S}
\]

with longitudinal and transverse dispersivities inherited from the formal SUTRA setup.

## Boundary and initial residuals

### Initial state

- `ic_psi`: H-dependent canonical COLD `t=0` pressure field.
- `ic_u`: \(C=0\).

Physics-only does not use transient interior SUTRA targets, but it does use this prescribed initial field because it is part of the transient problem specification.

### Land pressure

\[
\psi=H_{land}-z.
\]

### Active marine pressure

\[
\eta(t)=2.5+A\sin(2\pi t/T),\quad T=12\ \mathrm h,
\]
\[
\psi_{sea}=\frac{\gamma_{sea}}{\gamma_{ref}}(\eta-z),
\qquad \gamma_{sea}=10055.1519\ {\rm Pa\,m^{-1}}.
\]

Marine pressure nodes above \(\eta(t)\) are inactive and instead receive exposed-boundary no-flux residuals.

### Specified-pressure source concentration

SUTRA2.2 source code adds the pressure-node UBC term to transport only when fluid flows inward. The differentiable regularizer therefore uses predicted inward Darcy flux as a detached gate and penalizes deviation from:

- land inflow source concentration: 0;
- sea inflow source concentration: 0.0357.

This is a continuous source-concentration surrogate for SUTRA's nodal inflow treatment, not a claim that SUTRA enforces a strict all-time Dirichlet concentration boundary.

### Impermeable boundaries

Top and bottom enforce normal Darcy flux and normal total solute flux equal to zero. The two horizontal boundaries are combined into a single ReLoBRaLo group so the historical six-group design is retained.

## Residual normalization

Every raw residual is divided by a characteristic physical scale before squaring. ReLoBRaLo operates on these dimensionless group MSEs. This avoids allowing numerical unit magnitude alone to determine adaptive loss weights.

## ReLoBRaLo

Hybrid:

\[
L=L_{data}+\alpha_{phys}(e)\frac{1}{6}\sum_g w_gL_g,
\]

Physics-only:

\[
L=\frac{1}{6}\sum_gw_gL_g.
\]

The group weights are held fixed within an epoch and updated from epoch-mean group losses for use in the next epoch, matching the old experiment semantics.

## Limitation

The residuals are continuous strong-form counterparts. They do not reproduce:

- SUTRA finite-element spatial assembly;
- SUTRA transient algebraic discretization;
- `UP=0.5` asymmetric/upstream weighting;
- solver iteration/discretization error.

They should therefore be described as physics constraints based on the SUTRA governing equations and constitutive relations, not as the exact SUTRA discrete residual.

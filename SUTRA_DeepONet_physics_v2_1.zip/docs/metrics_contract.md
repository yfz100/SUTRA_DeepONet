# Metrics Contract — shared v2.1 physical-space evaluation

All formal evaluation metrics are computed in **physical output space** after inverse normalization.
Reductions use `float64`.

For a vector of reference values `y` and predictions `ŷ`:

\[
RMSE=\sqrt{\frac{1}{N}\sum_i(\hat y_i-y_i)^2}
\]

\[
MAE=\frac{1}{N}\sum_i|\hat y_i-y_i|
\]

\[
RL2E=\sqrt{\frac{\sum_i(\hat y_i-y_i)^2}{\sum_i y_i^2}}
\]

If the RL2E denominator is zero, the stored value is `NaN`; it is never replaced by zero.

Additional diagnostics:

- bias = mean(prediction − reference)
- maximum absolute error
- 95th percentile absolute error
- 99th percentile absolute error

Source outputs:

- `metrics_by_case.csv`: 168 case-level rows
- `metrics_by_case_time.csv`: 168 × 73 rows
- `metrics_pooled_by_split.csv`: pooled train / validation / test metrics
- `metrics_case_summary_by_split.csv`: mean/std/min/max of case-level metrics

OOD outputs:

- `metrics_by_case.csv`: 18 rows
- `metrics_by_case_time.csv`: 18 × 73 rows
- `metrics_pooled_all.csv`
- `metrics_case_summary_all.csv`

Exact P95/P99 are computed at case and case-time level. They are intentionally not pooled over an entire split because exact pooled percentiles are not reducible and would require another large temporary error archive. The pooled table therefore reports RMSE, MAE, RL2E, bias, and maximum absolute error; percentile information remains available through the case-level tables.

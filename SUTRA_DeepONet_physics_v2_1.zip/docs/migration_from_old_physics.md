# Migration from the old HybridFullLite / PhysicsOnly packages

## Preserved exactly at the experimental-design level

- group-level ReLoBRaLo;
- six adaptive groups;
- Hybrid data anchor = 1;
- Hybrid `alpha_phys = 0.1` and `0.5` formal runs;
- 200-epoch linear alpha ramp;
- `alpha_memory=.95`, `temperature=.2`, `expected_rho=.99`;
- group clamp `[.2,5]`, renormalization, epoch-mean updates;
- old per-mode physics collocation batch sizes;
- continuous strong-form interpretation.

## Required migration corrections

- old `[H,A,phase,const]` branch -> `[A,H]`;
- hard-coded land H -> sampled case H;
- old pressure conversion -> canonical `p=9810 psi`;
- sea density-correct pressure-head target;
- H-dependent COLD initial pressure field;
- top no-flow added;
- land UBC changed from unconditional C=0 to inflow-only source-concentration semantics;
- fixed Hybrid data validation;
- fixed Physics-only physics validation;
- canonical manifest/split/leakage/export/metric/timing contracts.

## Important alpha clarification

The old source files contained `lambda=0.1` fallback values for individual physics terms. Under enabled ReLoBRaLo those fixed lambdas were not used by the actual training total. The manuscript's `alpha=0.1/0.5` corresponds to the overall `alpha_phys` multiplying the ReLoBRaLo-weighted physics contribution.

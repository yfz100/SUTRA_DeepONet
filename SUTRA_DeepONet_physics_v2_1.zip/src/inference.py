from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import torch

from .features import build_trunk_features
from .model import build_model
from .normalization import Normalizer
from .reference_data import CanonicalReferenceData


def load_model_from_checkpoint(
    config: dict[str, Any],
    checkpoint_path: str | Path,
    device: torch.device,
) -> tuple[torch.nn.Module, dict[str, Any]]:
    model = build_model(config).to(device)
    checkpoint = torch.load(Path(checkpoint_path), map_location=device)
    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()
    return model, checkpoint


@torch.no_grad()
def predict_case(
    model: torch.nn.Module,
    data: CanonicalReferenceData,
    case_index: int,
    normalizer: Normalizer,
    trunk_all_norm: np.ndarray,
    batch_size: int,
    device: torch.device,
) -> tuple[np.ndarray, np.ndarray]:
    """Predict one complete case; returns physical-space (psi, C) arrays (time,node)."""
    model.eval()
    branch_raw = np.asarray(data.branch[int(case_index)], dtype=np.float32)[None, :]
    branch_norm = normalizer.branch_to_norm(branch_raw)
    branch_tensor = torch.from_numpy(branch_norm).to(device)
    branch_latent = model.encode_branch(branch_tensor)

    flat_trunk = trunk_all_norm.reshape(-1, trunk_all_norm.shape[-1])
    n = flat_trunk.shape[0]
    pred_psi = np.empty(n, dtype=np.float32)
    pred_con = np.empty(n, dtype=np.float32)
    for start in range(0, n, int(batch_size)):
        end = min(start + int(batch_size), n)
        x = torch.from_numpy(np.asarray(flat_trunk[start:end], dtype=np.float32)).to(device, non_blocking=True)
        t_latent = model.encode_trunk(x)
        y_norm = model.combine_latents(branch_latent, t_latent).detach().cpu().numpy().astype(np.float32)
        y = normalizer.target_from_norm(y_norm)
        pred_psi[start:end] = y[:, 0]
        pred_con[start:end] = y[:, 1]
    return pred_psi.reshape(data.n_time, data.n_node), pred_con.reshape(data.n_time, data.n_node)


def prepare_trunk(data: CanonicalReferenceData, normalizer: Normalizer, config: dict[str, Any]) -> np.ndarray:
    return build_trunk_features(data, normalizer, float(config["physics"]["tidal_period_s"]))

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd

from .utils import load_json


REQUIRED_FILES = {
    "branch": "branch_inputs.npy",
    "coords": "coords_xz_m.npy",
    "times": "times_s.npy",
    "pressure_head": "pressure_head_m.npy",
    "concentration": "concentration.npy",
    "case_metadata": "case_metadata.csv",
    "dataset_metadata": "dataset_metadata.json",
    "processed_validation": "processed_validation.json",
}


@dataclass(frozen=True)
class CaseSelection:
    case_index: int
    case_id: str
    amplitude_m: float
    h_land_m: float
    split: str
    design_regime: str


class CanonicalReferenceData:
    """Memory-mapped reader for Canonical Reference Data Schema v2.1.

    Large fields remain separate memory maps. No 4-D target copy is created.
    """

    def __init__(self, processed_dir: str | Path) -> None:
        self.processed_dir = Path(processed_dir).expanduser().resolve()
        if not self.processed_dir.is_dir():
            raise FileNotFoundError(f"Canonical processed directory not found: {self.processed_dir}")

        self.paths = {key: self.processed_dir / name for key, name in REQUIRED_FILES.items()}
        missing = [str(p) for p in self.paths.values() if not p.exists()]
        if missing:
            raise FileNotFoundError("Canonical processed directory is incomplete:\n" + "\n".join(missing))

        self.branch = np.load(self.paths["branch"], mmap_mode="r")
        self.coords = np.load(self.paths["coords"], mmap_mode="r")
        self.times = np.load(self.paths["times"], mmap_mode="r")
        self.pressure_head = np.load(self.paths["pressure_head"], mmap_mode="r")
        self.concentration = np.load(self.paths["concentration"], mmap_mode="r")
        self.case_metadata = pd.read_csv(self.paths["case_metadata"])
        self.dataset_metadata = load_json(self.paths["dataset_metadata"])
        self.processed_validation = load_json(self.paths["processed_validation"])

        self.n_case = int(self.branch.shape[0])
        self.n_time = int(self.times.shape[0])
        self.n_node = int(self.coords.shape[0])
        self.output_dim = 2
        self.target_names = ["pressure_head", "concentration"]

        self.split_indices = self._build_split_indices()

    def _build_split_indices(self) -> dict[str, np.ndarray]:
        if "split" not in self.case_metadata.columns:
            raise ValueError(f"Missing split column in {self.paths['case_metadata']}")
        out: dict[str, np.ndarray] = {}
        values = self.case_metadata["split"].astype(str).to_numpy()
        for split in sorted(set(values.tolist())):
            out[split] = np.where(values == split)[0].astype(np.int64)
        return out

    @property
    def library_group(self) -> str:
        return str(self.dataset_metadata.get("canonical_library_group", ""))

    def get_split_indices(self, split: str) -> np.ndarray:
        if split not in self.split_indices:
            raise KeyError(f"Split {split!r} is not present in {self.library_group}; available={list(self.split_indices)}")
        return self.split_indices[split]

    def get_target_batch(
        self,
        case_idx: np.ndarray | Iterable[int] | int,
        time_idx: np.ndarray | Iterable[int] | int,
        node_idx: np.ndarray | Iterable[int] | int,
    ) -> np.ndarray:
        psi = np.asarray(self.pressure_head[case_idx, time_idx, node_idx], dtype=np.float32)
        con = np.asarray(self.concentration[case_idx, time_idx, node_idx], dtype=np.float32)
        return np.stack([psi, con], axis=-1)

    def get_case_pressure_head(self, case_index: int) -> np.ndarray:
        return np.asarray(self.pressure_head[int(case_index)], dtype=np.float32)

    def get_case_concentration(self, case_index: int) -> np.ndarray:
        return np.asarray(self.concentration[int(case_index)], dtype=np.float32)

    def get_case_targets(self, case_index: int) -> np.ndarray:
        return np.stack(
            [self.get_case_pressure_head(case_index), self.get_case_concentration(case_index)],
            axis=-1,
        ).astype(np.float32, copy=False)

    def case_row(self, case_index: int) -> pd.Series:
        return self.case_metadata.iloc[int(case_index)]

    def describe(self) -> dict:
        return {
            "processed_dir": str(self.processed_dir),
            "library_group": self.library_group,
            "branch_shape": list(self.branch.shape),
            "coords_shape": list(self.coords.shape),
            "times_shape": list(self.times.shape),
            "pressure_head_shape": list(self.pressure_head.shape),
            "concentration_shape": list(self.concentration.shape),
            "branch_dtype": str(self.branch.dtype),
            "coords_dtype": str(self.coords.dtype),
            "times_dtype": str(self.times.dtype),
            "pressure_head_dtype": str(self.pressure_head.dtype),
            "concentration_dtype": str(self.concentration.dtype),
            "splits": {k: int(len(v)) for k, v in self.split_indices.items()},
        }

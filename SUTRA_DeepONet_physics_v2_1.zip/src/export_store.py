from __future__ import annotations

import os
import shutil
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch
from numpy.lib.format import open_memmap

from .inference import load_model_from_checkpoint, predict_case, prepare_trunk
from .normalization import load_normalizer
from .reference_data import CanonicalReferenceData
from .utils import (
    load_json,
    safe_rmtree,
    save_json,
    sha256_file,
    synchronize_device,
    write_complete_marker,
)


LIBRARY_EXPORT_NAMES = {
    "source_range": "source",
    "higher_amplitude": "higher_amplitude",
}


def _metadata_digest_frame(df: pd.DataFrame) -> str:
    import hashlib
    payload = df.to_csv(index=False, lineterminator="\n").encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def export_library_predictions(
    config: dict[str, Any],
    data: CanonicalReferenceData,
    run_dir: str | Path,
    checkpoint_name: str,
    device: torch.device,
    overwrite: bool = False,
) -> Path:
    """Export one frozen prediction archive plus synchronized inference timings.

    The timer around each case measures DeepONet prediction only (branch/trunk
    evaluation, inverse normalization and device-to-host transfer inside
    ``predict_case``). It deliberately excludes memmap writes, file hashing and
    metric evaluation. CUDA is synchronized immediately before and after each
    measured case to avoid under-reporting asynchronous GPU work.
    """
    run_dir = Path(run_dir)
    export_name = LIBRARY_EXPORT_NAMES.get(data.library_group, data.library_group)
    final_dir = run_dir / "exports" / export_name
    tmp_dir = final_dir.parent / f"{final_dir.name}.__building__"

    normalizer_path = run_dir / "normalization" / "normalizer.json"
    checkpoint_path = run_dir / "checkpoints" / f"{checkpoint_name}.pt"
    if not normalizer_path.exists():
        raise FileNotFoundError(normalizer_path)
    if not checkpoint_path.exists():
        raise FileNotFoundError(checkpoint_path)

    if final_dir.exists():
        if not overwrite:
            marker = final_dir / "EXPORT_COMPLETE"
            meta_path = final_dir / "export_metadata.json"
            if marker.exists() and meta_path.exists():
                existing = load_json(meta_path)
                expected_ckpt_hash = sha256_file(checkpoint_path)
                expected_norm_hash = sha256_file(normalizer_path)
                same = (
                    existing.get("checkpoint_name") == checkpoint_name
                    and existing.get("checkpoint_sha256") == expected_ckpt_hash
                    and existing.get("normalizer_sha256") == expected_norm_hash
                    and existing.get("manifest_sha256") == data.dataset_metadata.get("manifest_sha256")
                )
                timing_present = (
                    existing.get("timing_instrumentation_version") == "1.0"
                    and (final_dir / "inference_timing.csv").exists()
                )
                if same and timing_present:
                    print(f"Prediction export already complete and provenance/timing match, reusing: {final_dir}")
                    return final_dir
                if same and not timing_present:
                    raise FileExistsError(
                        f"Existing export provenance matches but v2.1.2 inference timing is missing: {final_dir}. "
                        "Use --overwrite if you intentionally want to rebuild this export with timing instrumentation."
                    )
                raise FileExistsError(
                    f"Existing export provenance differs from requested checkpoint/normalizer: {final_dir}. "
                    "Use overwrite only if replacement is intentional."
                )
            raise FileExistsError(f"Incomplete export directory exists and overwrite=False: {final_dir}")
        safe_rmtree(final_dir)
    safe_rmtree(tmp_dir)
    tmp_dir.mkdir(parents=True, exist_ok=True)

    export_build_wall_start = time.perf_counter()
    normalizer = load_normalizer(normalizer_path)
    model, ckpt = load_model_from_checkpoint(config, checkpoint_path, device)
    trunk = prepare_trunk(data, normalizer, config)
    batch_size = int(config["inference"].get("batch_size", 65536))

    psi_path = tmp_dir / "pred_pressure_head_m.npy"
    con_path = tmp_dir / "pred_concentration.npy"
    psi_mm = open_memmap(psi_path, mode="w+", dtype=np.float32, shape=(data.n_case, data.n_time, data.n_node))
    con_mm = open_memmap(con_path, mode="w+", dtype=np.float32, shape=(data.n_case, data.n_time, data.n_node))

    n_query_points = int(data.n_time * data.n_node)
    timing_rows: list[dict[str, Any]] = []

    for ci in range(data.n_case):
        synchronize_device(device)
        case_prediction_start = time.perf_counter()
        psi, con = predict_case(model, data, ci, normalizer, trunk, batch_size, device)
        synchronize_device(device)
        prediction_time_s = float(time.perf_counter() - case_prediction_start)

        if not np.isfinite(psi).all() or not np.isfinite(con).all():
            case_id = str(data.case_metadata.iloc[ci]["case_id"])
            raise ValueError(f"Non-finite prediction in {case_id}")
        psi_mm[ci] = psi
        con_mm[ci] = con
        psi_mm.flush()
        con_mm.flush()

        row_meta = data.case_metadata.iloc[ci]
        timing_rows.append(
            {
                "case_index": int(ci),
                "case_id": str(row_meta["case_id"]),
                "amplitude_m": float(row_meta["amplitude_m"]),
                "h_land_m": float(row_meta["h_land_m"]),
                "split": str(row_meta["split"]),
                "design_regime": str(row_meta["design_regime"]),
                "n_query_points": n_query_points,
                "prediction_time_s": prediction_time_s,
                "query_points_per_s": (
                    float(n_query_points / prediction_time_s) if prediction_time_s > 0 else float("nan")
                ),
            }
        )

        if ci == 0 or (ci + 1) % 10 == 0 or ci + 1 == data.n_case:
            print(
                f"Export {data.library_group}: {ci+1}/{data.n_case} "
                f"(prediction_time={prediction_time_s:.4f}s)"
            )

    del psi_mm, con_mm
    data.case_metadata.to_csv(tmp_dir / "case_metadata.csv", index=False, encoding="utf-8-sig")

    timing_df = pd.DataFrame(timing_rows)
    timing_path = tmp_dir / "inference_timing.csv"
    timing_df.to_csv(timing_path, index=False, encoding="utf-8-sig")

    case_times = timing_df["prediction_time_s"].to_numpy(dtype=np.float64)
    total_prediction_time_s = float(case_times.sum())
    total_query_points = int(n_query_points * data.n_case)
    timing_summary = {
        "timing_instrumentation_version": "1.0",
        "timing_clock": "time.perf_counter",
        "cuda_synchronized_at_case_boundaries": bool(device.type == "cuda"),
        "device": str(device),
        "n_cases": int(data.n_case),
        "query_points_per_case": n_query_points,
        "total_query_points": total_query_points,
        "total_prediction_time_s": total_prediction_time_s,
        "mean_prediction_time_per_case_s": float(case_times.mean()),
        "median_prediction_time_per_case_s": float(np.median(case_times)),
        "min_prediction_time_per_case_s": float(case_times.min()),
        "max_prediction_time_per_case_s": float(case_times.max()),
        "mean_prediction_time_excluding_first_case_s": (
            float(case_times[1:].mean()) if len(case_times) > 1 else None
        ),
        "overall_query_points_per_s": (
            float(total_query_points / total_prediction_time_s) if total_prediction_time_s > 0 else None
        ),
        "timing_scope": (
            "DeepONet prediction only: branch/trunk evaluation, inverse normalization, "
            "and device-to-host transfer inside predict_case; excludes memmap writes, "
            "hashing, and metrics."
        ),
    }

    # Build-wall timer is intentionally broader than pure inference; it includes
    # model/normalizer loading, trunk preparation and array writes up to this point,
    # but excludes the expensive SHA256 calculations below.
    timing_summary["export_build_wall_time_s_before_hashing"] = float(
        time.perf_counter() - export_build_wall_start
    )
    save_json(timing_summary, tmp_dir / "inference_timing_summary.json")

    meta = {
        "export_contract_version": "1.0",
        "timing_instrumentation_version": "1.0",
        "library_group": data.library_group,
        "export_name": export_name,
        "prediction_axis_order": ["case", "time", "node"],
        "branch_order": ["amplitude_m", "h_land_m"],
        "target_order": ["pressure_head_m", "concentration"],
        "pred_pressure_head_shape": [data.n_case, data.n_time, data.n_node],
        "pred_concentration_shape": [data.n_case, data.n_time, data.n_node],
        "prediction_dtype": "float32",
        "true_fields_reexported": False,
        "error_arrays_exported": False,
        "checkpoint_name": checkpoint_name,
        "checkpoint_epoch": int(ckpt.get("epoch", -1)),
        "checkpoint_sha256": sha256_file(checkpoint_path),
        "normalizer_sha256": sha256_file(normalizer_path),
        "canonical_case_metadata_sha256": _metadata_digest_frame(data.case_metadata),
        "export_case_metadata_sha256": sha256_file(tmp_dir / "case_metadata.csv"),
        "reference_dataset_metadata_sha256": sha256_file(data.paths["dataset_metadata"]),
        "manifest_sha256": data.dataset_metadata.get("manifest_sha256"),
        "prediction_files": {
            "pred_pressure_head_m.npy": sha256_file(psi_path),
            "pred_concentration.npy": sha256_file(con_path),
        },
        "inference_batch_size": batch_size,
        "inference_timing_file": "inference_timing.csv",
        "inference_timing_file_sha256": sha256_file(timing_path),
        "inference_timing_summary_file": "inference_timing_summary.json",
        "inference_timing_summary_sha256": sha256_file(tmp_dir / "inference_timing_summary.json"),
        "inference_timing_summary": timing_summary,
    }
    save_json(meta, tmp_dir / "export_metadata.json")
    write_complete_marker(tmp_dir / "EXPORT_COMPLETE", {"completed": True, "library_group": data.library_group})

    # Publish only after every file is complete.
    os.replace(tmp_dir, final_dir)
    return final_dir


def validate_prediction_export(data: CanonicalReferenceData, export_dir: str | Path) -> dict[str, Any]:
    export_dir = Path(export_dir)
    failures: list[str] = []
    required = [
        export_dir / "pred_pressure_head_m.npy",
        export_dir / "pred_concentration.npy",
        export_dir / "case_metadata.csv",
        export_dir / "export_metadata.json",
        export_dir / "EXPORT_COMPLETE",
    ]
    for p in required:
        if not p.exists():
            failures.append(f"missing {p.name}")
    if failures:
        return {"passed": False, "failures": failures}

    psi = np.load(required[0], mmap_mode="r")
    con = np.load(required[1], mmap_mode="r")
    expected = (data.n_case, data.n_time, data.n_node)
    if psi.shape != expected:
        failures.append(f"pressure prediction shape {psi.shape} != {expected}")
    if con.shape != expected:
        failures.append(f"concentration prediction shape {con.shape} != {expected}")
    if str(psi.dtype) != "float32" or str(con.dtype) != "float32":
        failures.append(f"prediction dtype invalid: {psi.dtype}, {con.dtype}")

    for arr, name in [(psi, "pressure"), (con, "concentration")]:
        for start in range(0, data.n_case, 8):
            if not np.isfinite(np.asarray(arr[start:start+8])).all():
                failures.append(f"{name} prediction contains NaN/Inf")
                break

    meta = pd.read_csv(export_dir / "case_metadata.csv")
    cols = ["case_index", "case_id", "amplitude_m", "h_land_m", "split", "design_regime"]
    for col in cols:
        if col not in meta.columns or col not in data.case_metadata.columns:
            failures.append(f"case metadata missing {col}")
            continue
        a = meta[col]
        b = data.case_metadata[col]
        if col in {"amplitude_m", "h_land_m"}:
            ok = np.allclose(a.to_numpy(float), b.to_numpy(float), rtol=0, atol=1e-12)
        else:
            ok = np.array_equal(a.astype(str).to_numpy(), b.astype(str).to_numpy())
        if not ok:
            failures.append(f"export/canonical case metadata mismatch: {col}")

    export_meta = load_json(export_dir / "export_metadata.json")
    if export_meta.get("timing_instrumentation_version") == "1.0":
        timing_path = export_dir / "inference_timing.csv"
        timing_summary_path = export_dir / "inference_timing_summary.json"
        if not timing_path.exists():
            failures.append("missing inference_timing.csv")
        if not timing_summary_path.exists():
            failures.append("missing inference_timing_summary.json")
        if timing_path.exists():
            timing = pd.read_csv(timing_path)
            if len(timing) != data.n_case:
                failures.append(f"inference timing rows={len(timing)} != {data.n_case}")
            required_timing_cols = {
                "case_index",
                "case_id",
                "n_query_points",
                "prediction_time_s",
                "query_points_per_s",
            }
            if not required_timing_cols.issubset(timing.columns):
                failures.append("inference timing columns incomplete")
            elif len(timing):
                if not np.isfinite(timing["prediction_time_s"].to_numpy(float)).all():
                    failures.append("inference timing contains NaN/Inf prediction_time_s")
                if (timing["prediction_time_s"].to_numpy(float) <= 0).any():
                    failures.append("inference timing contains non-positive prediction_time_s")
                if not np.array_equal(
                    timing["case_id"].astype(str).to_numpy(),
                    data.case_metadata["case_id"].astype(str).to_numpy(),
                ):
                    failures.append("inference timing case order mismatch")

    return {"passed": not failures, "failures": failures, "expected_shape": list(expected)}

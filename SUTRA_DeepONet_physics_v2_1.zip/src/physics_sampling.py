from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Mapping

import numpy as np

from .reference_data import CanonicalReferenceData
from .utils import sha256_file


TERM_OFFSETS = {
    "flow_pde": 101,
    "transport_pde": 102,
    "ic_psi": 201,
    "ic_u": 202,
    "land_p": 301,
    "sea_p": 302,
    "land_u": 401,
    "sea_inflow_u": 402,
    "bottom_flow": 501,
    "bottom_solute": 502,
    "top_flow": 503,
    "top_solute": 504,
    "exposed_flow": 601,
    "exposed_solute": 602,
}


@dataclass(frozen=True)
class BoundaryInfo:
    land_nodes: np.ndarray
    sea_nodes: np.ndarray
    bottom_nodes: np.ndarray
    top_nodes: np.ndarray
    interior_nodes: np.ndarray

    def describe(self, coords: np.ndarray) -> dict:
        coords = np.asarray(coords, dtype=np.float64)
        def rng(nodes: np.ndarray) -> dict | None:
            if len(nodes) == 0:
                return None
            xy = coords[nodes]
            return {
                "x_min": float(xy[:, 0].min()),
                "x_max": float(xy[:, 0].max()),
                "z_min": float(xy[:, 1].min()),
                "z_max": float(xy[:, 1].max()),
            }
        return {
            "n_land_nodes": int(len(self.land_nodes)),
            "n_sea_nodes": int(len(self.sea_nodes)),
            "n_bottom_impermeable_nodes": int(len(self.bottom_nodes)),
            "n_top_impermeable_nodes": int(len(self.top_nodes)),
            "n_interior_nodes": int(len(self.interior_nodes)),
            "land_range": rng(self.land_nodes),
            "sea_range": rng(self.sea_nodes),
            "bottom_range": rng(self.bottom_nodes),
            "top_range": rng(self.top_nodes),
            "corner_policy": "pressure-boundary corner nodes are excluded from top/bottom no-flux node sets",
        }


def detect_boundaries(coords: np.ndarray, cfg: Mapping[str, float]) -> BoundaryInfo:
    """Detect the four geometric boundaries of the canonical trapezoid.

    Domain vertices: (0,0), (10,0), (3,4), (0,4).
    Marine line: x + 1.75 z - 10 = 0.

    Pressure-boundary corner nodes are removed from top/bottom no-flux sets so
    mutually incompatible strong constraints are not imposed at the same point.
    """
    coords = np.asarray(coords, dtype=np.float64)
    x, z = coords[:, 0], coords[:, 1]
    land_tol = float(cfg.get("land_x_tolerance_m", 1.0e-6))
    z_tol = float(cfg.get("horizontal_z_tolerance_m", 1.0e-6))
    sea_tol = float(cfg.get("sea_line_tolerance_m", 2.0e-5))
    margin = float(cfg.get("interior_boundary_margin_m", 0.05))
    sea_x0 = float(cfg.get("sea_line_x0", 10.0))
    sea_slope = float(cfg.get("sea_line_slope", -1.75))
    top_z = float(cfg.get("top_z_m", 4.0))

    x_sea = sea_x0 + sea_slope * z
    land = np.where(np.abs(x) <= land_tol)[0]
    sea = np.where(np.abs(x - x_sea) <= sea_tol)[0]
    bottom_all = np.where(np.abs(z) <= z_tol)[0]
    top_all = np.where(np.abs(z - top_z) <= z_tol)[0]

    pressure_nodes = np.union1d(land, sea)
    bottom = np.setdiff1d(bottom_all, pressure_nodes, assume_unique=False)
    top = np.setdiff1d(top_all, pressure_nodes, assume_unique=False)

    interior_mask = (
        (x > margin)
        & (z > margin)
        & (z < top_z - margin)
        & (x < x_sea - margin)
    )
    interior = np.where(interior_mask)[0]

    if len(land) == 0 or len(sea) == 0 or len(bottom) == 0 or len(top) == 0 or len(interior) == 0:
        raise ValueError(
            "Boundary detection failed: "
            f"land={len(land)}, sea={len(sea)}, bottom={len(bottom)}, "
            f"top={len(top)}, interior={len(interior)}"
        )

    return BoundaryInfo(
        land_nodes=land.astype(np.int64),
        sea_nodes=sea.astype(np.int64),
        bottom_nodes=bottom.astype(np.int64),
        top_nodes=top.astype(np.int64),
        interior_nodes=interior.astype(np.int64),
    )


@dataclass(frozen=True)
class PhysicsIndices:
    case_index: np.ndarray
    time_index: np.ndarray
    node_index: np.ndarray

    @property
    def size(self) -> int:
        return int(len(self.case_index))


def _term_rng(seed: int, term: str, epoch: int, batch_number: int) -> np.random.Generator:
    if term not in TERM_OFFSETS:
        raise KeyError(term)
    ss = np.random.SeedSequence([int(seed), int(TERM_OFFSETS[term]), int(epoch), int(batch_number)])
    return np.random.default_rng(ss)


def _sample_active_or_exposed_sea(
    data: CanonicalReferenceData,
    binfo: BoundaryInfo,
    split: str,
    size: int,
    rng: np.random.Generator,
    cfg: Mapping[str, float],
    active: bool,
) -> PhysicsIndices:
    case_pool = data.get_split_indices(split).astype(np.int64)
    eta0 = float(cfg.get("eta0_m", 2.5))
    period = float(cfg.get("tidal_period_s", 43200.0))
    phase = float(cfg.get("phase_rad", 0.0))
    tol = float(cfg.get("active_tolerance_m", 1.0e-9))
    need = int(size)
    chunks: list[tuple[np.ndarray, np.ndarray, np.ndarray]] = []
    count = 0
    for _ in range(200):
        draw = max(need * 4, 512)
        ci = rng.choice(case_pool, size=draw, replace=True)
        ti = rng.integers(0, data.n_time, size=draw, endpoint=False)
        ni = rng.choice(binfo.sea_nodes, size=draw, replace=True)
        t = np.asarray(data.times[ti], dtype=np.float64)
        A = np.asarray(data.branch[ci, 0], dtype=np.float64)
        z = np.asarray(data.coords[ni, 1], dtype=np.float64)
        eta = eta0 + A * np.sin(2.0 * np.pi * t / period + phase)
        mask = z <= eta + tol if active else z > eta + tol
        if np.any(mask):
            chunks.append((ci[mask], ti[mask], ni[mask]))
            count += int(mask.sum())
        if count >= need:
            break
    if count < need:
        state = "active" if active else "exposed"
        raise RuntimeError(f"Could not sample {need} {state} marine-boundary points; got {count}")
    return PhysicsIndices(
        np.concatenate([x[0] for x in chunks])[:need].astype(np.int64),
        np.concatenate([x[1] for x in chunks])[:need].astype(np.int64),
        np.concatenate([x[2] for x in chunks])[:need].astype(np.int64),
    )


def sample_physics_indices(
    data: CanonicalReferenceData,
    binfo: BoundaryInfo,
    split: str,
    term: str,
    size: int,
    seed: int,
    epoch: int,
    batch_number: int,
    cfg: Mapping[str, float],
) -> PhysicsIndices:
    rng = _term_rng(seed, term, epoch, batch_number)
    case_pool = data.get_split_indices(split).astype(np.int64)
    n = int(size)
    if n <= 0:
        raise ValueError(f"Physics batch size for {term} must be positive")

    if term in {"sea_p", "sea_inflow_u"}:
        return _sample_active_or_exposed_sea(data, binfo, split, n, rng, cfg, active=True)
    if term in {"exposed_flow", "exposed_solute"}:
        return _sample_active_or_exposed_sea(data, binfo, split, n, rng, cfg, active=False)

    ci = rng.choice(case_pool, size=n, replace=True).astype(np.int64)
    if term in {"flow_pde", "transport_pde"}:
        ni = rng.choice(binfo.interior_nodes, size=n, replace=True).astype(np.int64)
        if bool(cfg.get("exclude_first_last_time", True)) and data.n_time > 2:
            ti = rng.integers(1, data.n_time - 1, size=n, endpoint=False).astype(np.int64)
        else:
            ti = rng.integers(0, data.n_time, size=n, endpoint=False).astype(np.int64)
    elif term in {"ic_psi", "ic_u"}:
        ni = rng.integers(0, data.n_node, size=n, endpoint=False).astype(np.int64)
        ti = np.zeros(n, dtype=np.int64)
    elif term in {"land_p", "land_u"}:
        ni = rng.choice(binfo.land_nodes, size=n, replace=True).astype(np.int64)
        ti = rng.integers(0, data.n_time, size=n, endpoint=False).astype(np.int64)
    elif term in {"bottom_flow", "bottom_solute"}:
        ni = rng.choice(binfo.bottom_nodes, size=n, replace=True).astype(np.int64)
        ti = rng.integers(1, max(data.n_time - 1, 2), size=n, endpoint=False).astype(np.int64)
    elif term in {"top_flow", "top_solute"}:
        ni = rng.choice(binfo.top_nodes, size=n, replace=True).astype(np.int64)
        ti = rng.integers(1, max(data.n_time - 1, 2), size=n, endpoint=False).astype(np.int64)
    else:
        raise KeyError(f"Unknown physics term: {term}")
    return PhysicsIndices(ci, ti, ni)


def create_fixed_physics_validation_plan(
    data: CanonicalReferenceData,
    binfo: BoundaryInfo,
    batch_sizes: Mapping[str, int],
    n_batches: int,
    batch_scale: float,
    seed: int,
    cfg: Mapping[str, float],
    path: str | Path,
    overwrite: bool = False,
) -> dict[str, np.ndarray]:
    path = Path(path)
    if path.exists() and not overwrite:
        loaded = dict(np.load(path))
        validate_fixed_physics_validation_plan(data, loaded, batch_sizes, n_batches, batch_scale)
        return loaded

    result: dict[str, np.ndarray] = {}
    for term, base_size in batch_sizes.items():
        size = max(1, int(round(int(base_size) * float(batch_scale))))
        ci_rows, ti_rows, ni_rows = [], [], []
        for b in range(int(n_batches)):
            idx = sample_physics_indices(
                data, binfo, "validation", term, size, int(seed), epoch=0, batch_number=b, cfg=cfg
            )
            ci_rows.append(idx.case_index)
            ti_rows.append(idx.time_index)
            ni_rows.append(idx.node_index)
        result[f"{term}__case_index"] = np.stack(ci_rows, axis=0)
        result[f"{term}__time_index"] = np.stack(ti_rows, axis=0)
        result[f"{term}__node_index"] = np.stack(ni_rows, axis=0)

    path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(path, **result)
    validate_fixed_physics_validation_plan(data, result, batch_sizes, n_batches, batch_scale)
    return result


def validate_fixed_physics_validation_plan(
    data: CanonicalReferenceData,
    plan: Mapping[str, np.ndarray],
    batch_sizes: Mapping[str, int],
    n_batches: int,
    batch_scale: float,
) -> None:
    val_cases = set(data.get_split_indices("validation").astype(int).tolist())
    for term, base_size in batch_sizes.items():
        expected = (int(n_batches), max(1, int(round(int(base_size) * float(batch_scale)))))
        for field in ["case_index", "time_index", "node_index"]:
            key = f"{term}__{field}"
            if key not in plan:
                raise ValueError(f"Physics validation plan missing {key}")
            arr = np.asarray(plan[key])
            if arr.shape != expected:
                raise ValueError(f"{key} shape {arr.shape} != {expected}")
        ci = np.asarray(plan[f"{term}__case_index"], dtype=np.int64)
        ti = np.asarray(plan[f"{term}__time_index"], dtype=np.int64)
        ni = np.asarray(plan[f"{term}__node_index"], dtype=np.int64)
        if not set(np.unique(ci).astype(int).tolist()).issubset(val_cases):
            raise ValueError(f"{term} plan contains non-validation cases")
        if ti.min() < 0 or ti.max() >= data.n_time or ni.min() < 0 or ni.max() >= data.n_node:
            raise ValueError(f"{term} plan index out of bounds")


def physics_validation_plan_batch(plan: Mapping[str, np.ndarray], term: str, batch_number: int) -> PhysicsIndices:
    b = int(batch_number)
    return PhysicsIndices(
        np.asarray(plan[f"{term}__case_index"][b], dtype=np.int64),
        np.asarray(plan[f"{term}__time_index"][b], dtype=np.int64),
        np.asarray(plan[f"{term}__node_index"][b], dtype=np.int64),
    )


def physics_plan_sha256(path: str | Path) -> str:
    return sha256_file(path)

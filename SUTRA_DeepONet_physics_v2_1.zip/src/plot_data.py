from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd

from .case_selection import select_case_by_ah, select_case_by_id
from .reference_data import CanonicalReferenceData, CaseSelection


@dataclass
class PaperDataContext:
    reference: CanonicalReferenceData
    export_dir: Path
    pred_pressure_head: np.ndarray
    pred_concentration: np.ndarray
    export_metadata: pd.DataFrame

    @classmethod
    def load(cls, reference_dir: str | Path, run_dir: str | Path, library: str) -> "PaperDataContext":
        reference = CanonicalReferenceData(reference_dir)
        export_name = "source" if library == "source" else "higher_amplitude"
        expected_group = "source_range" if library == "source" else "higher_amplitude"
        if reference.library_group != expected_group:
            raise ValueError(f"Reference group {reference.library_group} != expected {expected_group}")
        export_dir = Path(run_dir) / "exports" / export_name
        if not (export_dir / "EXPORT_COMPLETE").exists():
            raise FileNotFoundError(f"Prediction export is not complete: {export_dir}")
        pred_psi = np.load(export_dir / "pred_pressure_head_m.npy", mmap_mode="r")
        pred_con = np.load(export_dir / "pred_concentration.npy", mmap_mode="r")
        export_meta = pd.read_csv(export_dir / "case_metadata.csv")
        expected = (reference.n_case, reference.n_time, reference.n_node)
        if pred_psi.shape != expected or pred_con.shape != expected:
            raise ValueError(f"Prediction export shape mismatch: {pred_psi.shape}, {pred_con.shape}, expected={expected}")
        for col in ["case_index", "case_id", "amplitude_m", "h_land_m", "split"]:
            a = export_meta[col]
            b = reference.case_metadata[col]
            if col in {"amplitude_m", "h_land_m"}:
                ok = np.allclose(a.to_numpy(float), b.to_numpy(float), rtol=0, atol=1e-12)
            else:
                ok = np.array_equal(a.astype(str).to_numpy(), b.astype(str).to_numpy())
            if not ok:
                raise ValueError(f"Export/reference metadata mismatch in {col}")
        return cls(reference, export_dir, pred_psi, pred_con, export_meta)

    def select_ah(self, amplitude: float, h_land: float, expected_split: str | None = None) -> CaseSelection:
        return select_case_by_ah(self.reference.case_metadata, amplitude, h_land, expected_split)

    def select_id(self, case_id: str, expected_split: str | None = None) -> CaseSelection:
        return select_case_by_id(self.reference.case_metadata, case_id, expected_split)

    def time_index(self, time_h: float, require_exact: bool = True, atol_s: float = 1e-9) -> int:
        target_s = float(time_h) * 3600.0
        times = np.asarray(self.reference.times, dtype=float)
        idx = int(np.argmin(np.abs(times - target_s)))
        if require_exact and abs(float(times[idx]) - target_s) > atol_s:
            raise ValueError(f"Requested time {time_h} h is not a canonical output time")
        return idx

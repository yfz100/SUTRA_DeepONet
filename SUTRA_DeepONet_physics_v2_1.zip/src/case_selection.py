from __future__ import annotations

import numpy as np
import pandas as pd

from .reference_data import CaseSelection


def _row_to_selection(row: pd.Series) -> CaseSelection:
    return CaseSelection(
        case_index=int(row["case_index"]),
        case_id=str(row["case_id"]),
        amplitude_m=float(row["amplitude_m"]),
        h_land_m=float(row["h_land_m"]),
        split=str(row["split"]),
        design_regime=str(row.get("design_regime", "")),
    )


def select_case_by_ah(
    metadata: pd.DataFrame,
    amplitude: float,
    h_land: float,
    expected_split: str | None = None,
    atol: float = 1e-9,
) -> CaseSelection:
    mask = (
        np.isclose(metadata["amplitude_m"].to_numpy(float), float(amplitude), rtol=0.0, atol=atol)
        & np.isclose(metadata["h_land_m"].to_numpy(float), float(h_land), rtol=0.0, atol=atol)
    )
    hits = metadata.loc[mask]
    if len(hits) == 0:
        raise KeyError(f"No case matches A={amplitude}, H_land={h_land}")
    if len(hits) > 1:
        raise ValueError(f"Multiple cases match A={amplitude}, H_land={h_land}: {hits['case_id'].tolist()}")
    selected = _row_to_selection(hits.iloc[0])
    if expected_split is not None and selected.split != expected_split:
        raise ValueError(
            f"Selected {selected.case_id} has split={selected.split!r}, expected {expected_split!r}"
        )
    return selected


def select_case_by_id(
    metadata: pd.DataFrame,
    case_id: str,
    expected_split: str | None = None,
) -> CaseSelection:
    hits = metadata.loc[metadata["case_id"].astype(str) == str(case_id)]
    if len(hits) == 0:
        raise KeyError(f"No case_id={case_id!r}")
    if len(hits) > 1:
        raise ValueError(f"Duplicate case_id={case_id!r}")
    selected = _row_to_selection(hits.iloc[0])
    if expected_split is not None and selected.split != expected_split:
        raise ValueError(f"Selected {case_id} has split={selected.split!r}, expected {expected_split!r}")
    return selected

from __future__ import annotations

import torch


def weighted_component_mse(
    prediction: torch.Tensor,
    target: torch.Tensor,
    weights: torch.Tensor,
) -> tuple[torch.Tensor, torch.Tensor]:
    if prediction.shape != target.shape:
        raise ValueError(f"prediction/target shape mismatch: {prediction.shape} vs {target.shape}")
    component = torch.mean((prediction - target) ** 2, dim=0)
    if component.numel() != weights.numel():
        raise ValueError(f"weights length {weights.numel()} != output components {component.numel()}")
    denom = torch.sum(weights)
    if float(denom.detach().cpu()) <= 0:
        raise ValueError("Loss weights must have positive sum")
    return torch.sum(weights * component) / denom, component

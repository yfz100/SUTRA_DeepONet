from __future__ import annotations

import math
import time
from pathlib import Path
from typing import Any, Mapping

import numpy as np
import pandas as pd
import torch

from .adaptive_weighting import ReLoBRaLoGroupBalancer
from .features import build_trunk_features
from .losses import weighted_component_mse
from .model import build_model
from .normalization import (
    fit_physics_only_normalizer,
    fit_train_only_normalizer,
    save_normalizer,
)
from .physics_engine import (
    ALL_TERMS,
    PhysicsEngine,
    batch_sizes_for_mode,
    groups_from_config,
    weighted_group_loss,
)
from .physics_losses import ramp_weight
from .physics_sampling import (
    create_fixed_physics_validation_plan,
    detect_boundaries,
)
from .reference_data import CanonicalReferenceData
from .sampling import UniformTripletBatchSampler, create_fixed_validation_indices
from .utils import ensure_dir, save_json, set_seed, sha256_file, synchronize_device


@torch.no_grad()
def evaluate_fixed_data_validation(
    model: torch.nn.Module,
    data: CanonicalReferenceData,
    normalizer,
    trunk_all: np.ndarray,
    sample: dict[str, np.ndarray],
    batch_size: int,
    device: torch.device,
    loss_weights: torch.Tensor,
) -> dict[str, float]:
    model.eval()
    ci = np.asarray(sample["case_index"], dtype=np.int64)
    ti = np.asarray(sample["time_index"], dtype=np.int64)
    ni = np.asarray(sample["node_index"], dtype=np.int64)
    branch_norm_all = normalizer.branch_to_norm(np.asarray(data.branch))
    sum_sq = np.zeros(2, dtype=np.float64)
    n = 0
    for start in range(0, len(ci), int(batch_size)):
        end = min(start + int(batch_size), len(ci))
        b = torch.from_numpy(np.asarray(branch_norm_all[ci[start:end]], dtype=np.float32)).to(device)
        x = torch.from_numpy(np.asarray(trunk_all[ti[start:end], ni[start:end]], dtype=np.float32)).to(device)
        y_raw = data.get_target_batch(ci[start:end], ti[start:end], ni[start:end])
        y = torch.from_numpy(normalizer.target_to_norm(y_raw)).to(device)
        diff = model(b, x) - y
        sum_sq += torch.sum(diff * diff, dim=0).detach().cpu().numpy().astype(np.float64)
        n += end - start
    comp = sum_sq / max(n, 1)
    w = loss_weights.detach().cpu().numpy().astype(np.float64)
    return {
        "combined_mse_norm": float(np.sum(w * comp) / np.sum(w)),
        "pressure_head_mse_norm": float(comp[0]),
        "concentration_mse_norm": float(comp[1]),
        "num_points": int(n),
    }


def _make_balancer(config: dict, group_names: list[str]) -> ReLoBRaLoGroupBalancer:
    c = config["physics_regularization"]["relobralo"]
    if not bool(c.get("enabled", True)):
        raise ValueError("Formal Section 4.2 package requires ReLoBRaLo enabled")
    return ReLoBRaLoGroupBalancer(
        group_names=group_names,
        alpha_memory=float(c.get("alpha_memory", 0.95)),
        temperature=float(c.get("temperature", 0.2)),
        expected_rho=float(c.get("expected_rho", 0.99)),
        weight_min=float(c.get("group_weight_min", 0.2)),
        weight_max=float(c.get("group_weight_max", 5.0)),
        eps=float(c.get("eps", 1.0e-12)),
        renormalize_after_clamp=bool(c.get("renormalize_after_clamp", True)),
        seed=int(c.get("seed", 20269692)),
    )


def _checkpoint_payload(
    epoch: int,
    model: torch.nn.Module,
    optimizer: torch.optim.Optimizer,
    config: dict,
    balancer: ReLoBRaLoGroupBalancer,
    best_metric_name: str,
    best_metric: float,
) -> dict[str, Any]:
    return {
        "epoch": int(epoch),
        "model_state_dict": model.state_dict(),
        "optimizer_state_dict": optimizer.state_dict(),
        best_metric_name: float(best_metric),
        "config": config,
        "relobralo_state": balancer.state_dict(),
        "training_mode": str(config["training"]["mode"]),
        "alpha_phys_target": (
            float(config["physics_regularization"]["relobralo"]["alpha_phys"])
            if str(config["training"]["mode"]) == "hybrid"
            else None
        ),
    }


def _accumulate_physics(
    result,
    term_sum: dict[str, float],
    term_raw_sum: dict[str, float],
    term_scale: dict[str, float],
    group_sum: dict[str, float],
) -> None:
    for k, diag in result.terms.items():
        term_sum[k] += float(diag.loss.detach().cpu())
        term_raw_sum[k] += float(diag.raw_mse.detach().cpu())
        term_scale[k] = float(diag.scale)
    for g, val in result.groups.items():
        group_sum[g] += float(val.detach().cpu())


def _evaluate_fixed_physics_validation(
    model: torch.nn.Module,
    engine: PhysicsEngine,
    plan: Mapping[str, np.ndarray],
    n_batches: int,
    device: torch.device,
    group_weights: Mapping[str, float],
    use_group_mean: bool,
) -> tuple[float, dict[str, float]]:
    # Input derivatives require autograd; no optimizer step is performed.
    model.train()
    sums = {g: 0.0 for g in engine.groups}
    total = 0.0
    for b in range(int(n_batches)):
        result = engine.validation_batch_from_plan(model, plan, b, device)
        loss = weighted_group_loss(result.groups, group_weights, use_group_mean)
        total += float(loss.detach().cpu())
        for g, gl in result.groups.items():
            sums[g] += float(gl.detach().cpu())
    return total / max(int(n_batches), 1), {g: v / max(int(n_batches), 1) for g, v in sums.items()}


def train_model(
    config: dict[str, Any],
    source: CanonicalReferenceData,
    run_dir: str | Path,
    device: torch.device,
) -> dict[str, Any]:
    """Train Hybrid or Physics-only model using the frozen Section 4.2 design."""
    function_wall_start = time.perf_counter()
    run_dir = Path(run_dir)
    ckpt_dir = ensure_dir(run_dir / "checkpoints")
    norm_dir = ensure_dir(run_dir / "normalization")
    sampling_dir = ensure_dir(run_dir / "sampling")
    training_dir = ensure_dir(run_dir / "training")
    physics_dir = ensure_dir(run_dir / "physics")

    seed = int(config["project"]["seed"])
    set_seed(seed)
    tr_cfg = config["training"]
    mode = str(tr_cfg.get("mode", "hybrid")).lower()
    if mode not in {"hybrid", "physics_only"}:
        raise ValueError(f"training.mode must be hybrid or physics_only, got {mode}")

    # Normalization follows the old experiment semantics.
    if mode == "hybrid":
        norm, norm_meta = fit_train_only_normalizer(
            source, config["physics"], eps=float(config["normalization"].get("eps", 1.0e-12))
        )
    else:
        po = config["normalization"]["physics_only"]
        norm, norm_meta = fit_physics_only_normalizer(
            source,
            config["physics"],
            eps=float(config["normalization"].get("eps", 1.0e-12)),
            target_mean_physical=tuple(po.get("target_mean_physical", [0.0, 0.0])),
            target_std_physical=tuple(po.get("target_std_physical", [4.0, 0.0357])),
        )
    save_normalizer(norm, norm_meta, norm_dir)

    binfo = detect_boundaries(
        np.asarray(source.coords), config["physics_regularization"]["boundary_detection"]
    )
    save_json(binfo.describe(np.asarray(source.coords)), physics_dir / "boundary_description.json")

    engine = PhysicsEngine(source, norm, binfo, config, mode)
    groups = groups_from_config(config)
    group_names = list(groups)
    balancer = _make_balancer(config, group_names)
    rel_cfg = config["physics_regularization"]["relobralo"]
    use_group_mean = bool(rel_cfg.get("use_group_mean", True))

    model = build_model(config).to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=float(tr_cfg["learning_rate"]),
        weight_decay=float(tr_cfg.get("weight_decay", 0.0)),
    )
    scheduler = None
    sch = tr_cfg.get("scheduler", {})
    if bool(sch.get("use_reduce_on_plateau", True)):
        scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
            optimizer,
            mode="min",
            factor=float(sch.get("factor", 0.5)),
            patience=int(sch.get("patience", 6)),
            min_lr=float(sch.get("min_lr", 1.0e-5)),
        )

    loss_weights = torch.tensor(tr_cfg.get("loss_weights", [1.0, 1.0]), dtype=torch.float32, device=device)
    trunk_all = build_trunk_features(source, norm, float(config["physics"]["tidal_period_s"]))
    data_sampler = None
    val_sample = None
    val_sample_path = sampling_dir / "validation_sample_indices.npz"
    physics_val_plan = None
    physics_val_path = sampling_dir / "physics_validation_plan.npz"

    if mode == "hybrid":
        data_sampler = UniformTripletBatchSampler(source, norm, trunk_all, "train", seed=seed)
        val_sample = create_fixed_validation_indices(
            source,
            points_per_case=int(tr_cfg["val_points_per_case"]),
            seed=int(tr_cfg.get("validation_seed", seed + 1000003)),
            path=val_sample_path,
            overwrite=False,
        )
    else:
        vp = config["physics_regularization"]["physics_validation"]
        physics_val_plan = create_fixed_physics_validation_plan(
            source,
            binfo,
            batch_sizes_for_mode(config, mode),
            n_batches=int(vp.get("n_batches", 8)),
            batch_scale=float(vp.get("batch_scale", 0.5)),
            seed=int(vp.get("seed", seed + 2000003)),
            cfg=engine.physics_cfg,
            path=physics_val_path,
            overwrite=False,
        )

    epochs = int(tr_cfg["epochs"])
    val_every = int(tr_cfg.get("val_every_epochs", 5))
    patience_epochs = int(tr_cfg.get("early_stopping_patience_epochs", 120))
    grad_clip = float(tr_cfg.get("grad_clip_norm", 1.0))
    data_batch_size = int(tr_cfg.get("batch_size", 8192))
    samples_per_epoch = int(tr_cfg.get("num_samples_per_epoch", 524288))
    data_batches = int(math.ceil(samples_per_epoch / data_batch_size))
    physics_steps = int(tr_cfg.get("physics_batches_per_epoch", 64))
    steps_per_epoch = data_batches if mode == "hybrid" else physics_steps
    if mode == "hybrid" and physics_steps != data_batches:
        raise ValueError(
            f"Controlled Hybrid design expects physics_batches_per_epoch == data batches per epoch; "
            f"got {physics_steps} vs {data_batches}"
        )

    best_val = float("inf")
    best_epoch = -1
    best_metric_name = "best_val_combined_mse_norm" if mode == "hybrid" else "best_val_physics_loss"
    history: list[dict[str, Any]] = []

    synchronize_device(device)
    training_loop_start = time.perf_counter()
    setup_wall_time_s = float(training_loop_start - function_wall_start)

    for epoch in range(1, epochs + 1):
        epoch_wall_start = time.perf_counter()
        model.train()
        group_weights_used = balancer.current_weights()
        alpha_eff = (
            ramp_weight(epoch, float(rel_cfg.get("alpha_phys", 0.0)), int(rel_cfg.get("ramp_epochs", 200)))
            if mode == "hybrid"
            else 1.0
        )

        total_sum = 0.0
        data_sum = 0.0
        data_comp_sum = np.zeros(2, dtype=np.float64)
        data_seen = 0
        term_sum = {k: 0.0 for k in ALL_TERMS}
        term_raw_sum = {k: 0.0 for k in ALL_TERMS}
        term_scale = {k: float("nan") for k in ALL_TERMS}
        group_sum = {g: 0.0 for g in group_names}

        synchronize_device(device)
        train_phase_start = time.perf_counter()
        for step in range(steps_per_epoch):
            optimizer.zero_grad(set_to_none=True)
            result = engine.training_batch(model, epoch, step, device, split="train")
            _accumulate_physics(result, term_sum, term_raw_sum, term_scale, group_sum)
            physics_loss = weighted_group_loss(result.groups, group_weights_used, use_group_mean)

            if mode == "hybrid":
                assert data_sampler is not None
                remaining = samples_per_epoch - step * data_batch_size
                current_bs = min(data_batch_size, remaining)
                sample = data_sampler.batch(epoch=epoch, batch_number=step, size=current_bs)
                branch = torch.from_numpy(sample.branch).to(device, non_blocking=True)
                trunk = torch.from_numpy(sample.trunk).to(device, non_blocking=True)
                target = torch.from_numpy(sample.target).to(device, non_blocking=True)
                pred = model(branch, trunk)
                data_loss, comp = weighted_component_mse(pred, target, loss_weights)
                loss = data_loss + alpha_eff * physics_loss
                bs = int(branch.shape[0])
                data_sum += float(data_loss.detach().cpu()) * bs
                data_comp_sum += comp.detach().cpu().numpy().astype(np.float64) * bs
                data_seen += bs
                total_sum += float(loss.detach().cpu()) * bs
            else:
                loss = physics_loss
                total_sum += float(loss.detach().cpu())

            loss.backward()
            if grad_clip > 0:
                torch.nn.utils.clip_grad_norm_(model.parameters(), grad_clip)
            optimizer.step()

        synchronize_device(device)
        train_phase_time_s = float(time.perf_counter() - train_phase_start)
        denom_steps = max(steps_per_epoch, 1)
        epoch_group_means = {g: group_sum[g] / denom_steps for g in group_names}
        next_weights = balancer.update(epoch_group_means)
        save_json(balancer.state_dict(), physics_dir / "relobralo_group_state.json")

        if mode == "hybrid":
            train_total = total_sum / max(data_seen, 1)
            train_data = data_sum / max(data_seen, 1)
            train_comp = data_comp_sum / max(data_seen, 1)
            samples_rate = float(data_seen / train_phase_time_s) if train_phase_time_s > 0 else float("nan")
        else:
            train_total = total_sum / denom_steps
            train_data = float("nan")
            train_comp = np.array([np.nan, np.nan], dtype=np.float64)
            samples_rate = float("nan")

        row: dict[str, Any] = {
            "epoch": epoch,
            "training_mode": mode,
            "train_total_loss": float(train_total),
            "train_data_loss_norm": float(train_data),
            "train_pressure_head_mse_norm": float(train_comp[0]),
            "train_concentration_mse_norm": float(train_comp[1]),
            "alpha_phys_effective": float(alpha_eff) if mode == "hybrid" else float("nan"),
            "learning_rate": float(optimizer.param_groups[0]["lr"]),
            "train_num_samples": int(data_seen) if mode == "hybrid" else 0,
            "physics_steps": int(steps_per_epoch),
            "train_phase_time_s": train_phase_time_s,
            "train_samples_per_s": samples_rate,
            "validation_time_s": float("nan"),
        }
        for term in ALL_TERMS:
            row[f"train_{term}_mse_nd"] = term_sum[term] / denom_steps
            row[f"train_{term}_mse_raw"] = term_raw_sum[term] / denom_steps
            row[f"scale_{term}"] = term_scale[term]
        for g in group_names:
            row[f"group_{g}_mse_nd"] = epoch_group_means[g]
            row[f"group_{g}_weight_used"] = float(group_weights_used[g])
            row[f"group_{g}_weight_next"] = float(next_weights[g])
            row[f"group_{g}_weighted_contribution"] = (
                (float(alpha_eff) if mode == "hybrid" else 1.0)
                * float(group_weights_used[g])
                * float(epoch_group_means[g])
                / (len(group_names) if use_group_mean else 1)
            )

        do_val = epoch == 1 or epoch % val_every == 0 or epoch == epochs
        if do_val:
            synchronize_device(device)
            val_start = time.perf_counter()
            if mode == "hybrid":
                assert val_sample is not None
                val = evaluate_fixed_data_validation(
                    model,
                    source,
                    norm,
                    trunk_all,
                    val_sample,
                    int(config["inference"].get("batch_size", 65536)),
                    device,
                    loss_weights,
                )
                val_score = float(val["combined_mse_norm"])
                row.update({f"val_{k}": v for k, v in val.items()})
            else:
                assert physics_val_plan is not None
                vp = config["physics_regularization"]["physics_validation"]
                val_score, val_groups = _evaluate_fixed_physics_validation(
                    model,
                    engine,
                    physics_val_plan,
                    int(vp.get("n_batches", 8)),
                    device,
                    group_weights_used,
                    use_group_mean,
                )
                row["val_physics_loss"] = float(val_score)
                for g, v in val_groups.items():
                    row[f"val_group_{g}_mse_nd"] = float(v)

            synchronize_device(device)
            val_time_s = float(time.perf_counter() - val_start)
            row["validation_time_s"] = val_time_s
            if scheduler is not None:
                scheduler.step(val_score)
            is_best = val_score < best_val
            if is_best:
                best_val = val_score
                best_epoch = epoch
                torch.save(
                    _checkpoint_payload(epoch, model, optimizer, config, balancer, best_metric_name, best_val),
                    ckpt_dir / "best.pt",
                )
            tag = " [best]" if is_best else ""
            if mode == "hybrid":
                print(
                    f"Epoch {epoch:04d}: total={train_total:.6e}, data={train_data:.6e}, "
                    f"alpha={alpha_eff:.3e}, val={val_score:.6e}, lr={row['learning_rate']:.3e}, "
                    f"train_time={train_phase_time_s:.2f}s, val_time={val_time_s:.2f}s{tag}"
                )
            else:
                print(
                    f"Epoch {epoch:04d}: phys={train_total:.6e}, val_phys={val_score:.6e}, "
                    f"lr={row['learning_rate']:.3e}, train_time={train_phase_time_s:.2f}s, "
                    f"val_time={val_time_s:.2f}s{tag}"
                )
        else:
            if mode == "hybrid":
                print(
                    f"Epoch {epoch:04d}: total={train_total:.6e}, data={train_data:.6e}, "
                    f"alpha={alpha_eff:.3e}, lr={row['learning_rate']:.3e}, train_time={train_phase_time_s:.2f}s"
                )
            else:
                print(
                    f"Epoch {epoch:04d}: phys={train_total:.6e}, lr={row['learning_rate']:.3e}, "
                    f"train_time={train_phase_time_s:.2f}s"
                )

        torch.save(
            _checkpoint_payload(epoch, model, optimizer, config, balancer, best_metric_name, best_val),
            ckpt_dir / "last.pt",
        )
        synchronize_device(device)
        row["epoch_wall_time_s"] = float(time.perf_counter() - epoch_wall_start)
        row["elapsed_training_wall_time_s"] = float(time.perf_counter() - training_loop_start)
        history.append(row)
        pd.DataFrame(history).to_csv(training_dir / "training_history.csv", index=False, encoding="utf-8-sig")

        if best_epoch > 0 and (epoch - best_epoch) >= patience_epochs:
            print(f"Early stopping at epoch {epoch}; best_epoch={best_epoch}, {best_metric_name}={best_val:.6e}")
            break

    synchronize_device(device)
    training_loop_wall_time_s = float(time.perf_counter() - training_loop_start)
    if best_epoch < 0 or not (ckpt_dir / "best.pt").exists():
        raise RuntimeError("Training ended without a best checkpoint")

    train_times = np.asarray([float(r["train_phase_time_s"]) for r in history], dtype=np.float64)
    val_times = np.asarray(
        [float(r["validation_time_s"]) for r in history if np.isfinite(float(r["validation_time_s"]))],
        dtype=np.float64,
    )
    epoch_times = np.asarray([float(r["epoch_wall_time_s"]) for r in history], dtype=np.float64)
    total_wall = float(time.perf_counter() - function_wall_start)
    timing_summary = {
        "timing_instrumentation_version": "1.0",
        "timing_clock": "time.perf_counter",
        "cuda_synchronized_at_gpu_phase_boundaries": bool(device.type == "cuda"),
        "device": str(device),
        "training_mode": mode,
        "setup_wall_time_s": setup_wall_time_s,
        "training_loop_wall_time_s": training_loop_wall_time_s,
        "training_loop_wall_time_h": training_loop_wall_time_s / 3600.0,
        "train_model_total_wall_time_s": total_wall,
        "train_model_total_wall_time_h": total_wall / 3600.0,
        "train_phase_total_time_s": float(train_times.sum()),
        "validation_total_time_s": float(val_times.sum()) if val_times.size else 0.0,
        "mean_train_phase_time_per_epoch_s": float(train_times.mean()),
        "median_train_phase_time_per_epoch_s": float(np.median(train_times)),
        "mean_epoch_wall_time_s": float(epoch_times.mean()),
        "median_epoch_wall_time_s": float(np.median(epoch_times)),
        "validation_events": int(val_times.size),
        "epochs_completed": int(history[-1]["epoch"]),
    }
    save_json(timing_summary, training_dir / "timing_summary.json")

    summary: dict[str, Any] = {
        "training_mode": mode,
        "best_epoch": int(best_epoch),
        best_metric_name: float(best_val),
        "epochs_completed": int(history[-1]["epoch"]),
        "train_cases": int(len(source.get_split_indices("train"))),
        "validation_cases": int(len(source.get_split_indices("validation"))),
        "normalizer_sha256": sha256_file(norm_dir / "normalizer.json"),
        "relobralo_state_sha256": sha256_file(physics_dir / "relobralo_group_state.json"),
        "timing_instrumentation_version": "1.0",
        "training_loop_wall_time_s": training_loop_wall_time_s,
        "train_model_total_wall_time_s": total_wall,
        "timing_summary_sha256": sha256_file(training_dir / "timing_summary.json"),
    }
    if mode == "hybrid":
        summary.update(
            {
                "alpha_phys_target": float(rel_cfg["alpha_phys"]),
                "alpha_phys_ramp_epochs": int(rel_cfg.get("ramp_epochs", 200)),
                "validation_points_per_case": int(tr_cfg["val_points_per_case"]),
                "validation_total_points": int(len(val_sample["case_index"])),
                "validation_sample_sha256": sha256_file(val_sample_path),
            }
        )
    else:
        summary.update(
            {
                "alpha_phys_target": None,
                "physics_validation_plan_sha256": sha256_file(physics_val_path),
                "physics_validation_batches": int(config["physics_regularization"]["physics_validation"].get("n_batches", 8)),
            }
        )
    save_json(summary, training_dir / "training_summary.json")
    return summary

from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping

import numpy as np
import torch

from .normalization import Normalizer
from .physics_losses import LossDiagnostics, compute_physics_term
from .physics_sampling import (
    BoundaryInfo,
    physics_validation_plan_batch,
    sample_physics_indices,
)
from .reference_data import CanonicalReferenceData


DEFAULT_GROUPS: dict[str, list[str]] = {
    "flow_pde": ["flow_pde"],
    "transport_pde": ["transport_pde"],
    "pressure_value": ["ic_psi", "land_p", "sea_p"],
    "concentration_value_source": ["ic_u", "land_u", "sea_inflow_u"],
    "impermeable_no_flux": ["bottom_flow", "bottom_solute", "top_flow", "top_solute"],
    "exposed_sea_no_flux": ["exposed_flow", "exposed_solute"],
}

ALL_TERMS = [k for vals in DEFAULT_GROUPS.values() for k in vals]


@dataclass
class PhysicsBatchResult:
    terms: dict[str, LossDiagnostics]
    groups: dict[str, torch.Tensor]


def batch_sizes_for_mode(config: dict, mode: str) -> dict[str, int]:
    raw = config["physics_regularization"]["batch_sizes"][str(mode)]
    sizes = {str(k): int(v) for k, v in raw.items()}
    missing = [t for t in ALL_TERMS if t not in sizes]
    if missing:
        raise ValueError(f"Physics batch-size config missing terms: {missing}")
    return sizes


def groups_from_config(config: dict) -> dict[str, list[str]]:
    raw = config["physics_regularization"]["relobralo"].get("groups", DEFAULT_GROUPS)
    groups = {str(g): [str(t) for t in terms] for g, terms in raw.items()}
    if len(groups) != 6:
        raise ValueError(f"Formal Section 4.2 design requires exactly six ReLoBRaLo groups; got {len(groups)}")
    flat = [t for terms in groups.values() for t in terms]
    if len(flat) != len(set(flat)):
        raise ValueError("A physics term appears in more than one ReLoBRaLo group")
    missing = sorted(set(ALL_TERMS) - set(flat))
    extra = sorted(set(flat) - set(ALL_TERMS))
    if missing or extra:
        raise ValueError(f"Physics group membership mismatch; missing={missing}, extra={extra}")
    return groups


def group_losses_from_terms(
    term_losses: Mapping[str, LossDiagnostics], groups: Mapping[str, list[str]]
) -> dict[str, torch.Tensor]:
    out: dict[str, torch.Tensor] = {}
    for group, terms in groups.items():
        vals = [term_losses[t].loss for t in terms if t in term_losses]
        if vals:
            out[group] = torch.stack(vals).mean()
    return out


def weighted_group_loss(
    group_losses: Mapping[str, torch.Tensor],
    group_weights: Mapping[str, float],
    use_group_mean: bool = True,
) -> torch.Tensor:
    vals = [gl * float(group_weights.get(g, 1.0)) for g, gl in group_losses.items()]
    if not vals:
        raise ValueError("No active physics group losses")
    stack = torch.stack(vals)
    return stack.mean() if use_group_mean else stack.sum()


class PhysicsEngine:
    def __init__(
        self,
        data: CanonicalReferenceData,
        normalizer: Normalizer,
        boundary_info: BoundaryInfo,
        config: dict,
        mode: str,
    ) -> None:
        self.data = data
        self.normalizer = normalizer
        self.binfo = boundary_info
        self.config = config
        self.mode = str(mode)
        self.seed = int(config["project"]["seed"])
        self.physics_cfg = dict(config["physics_regularization"]["common_physics"])
        # Sampling flags/tolerances live alongside common physical constants.
        self.physics_cfg.update(config["physics_regularization"].get("sampling", {}))
        self.batch_sizes = batch_sizes_for_mode(config, self.mode)
        self.groups = groups_from_config(config)

    def training_batch(
        self,
        model: torch.nn.Module,
        epoch: int,
        batch_number: int,
        device: torch.device,
        split: str = "train",
    ) -> PhysicsBatchResult:
        terms: dict[str, LossDiagnostics] = {}
        for term in ALL_TERMS:
            idx = sample_physics_indices(
                self.data,
                self.binfo,
                split,
                term,
                self.batch_sizes[term],
                self.seed,
                epoch,
                batch_number,
                self.physics_cfg,
            )
            terms[term] = compute_physics_term(
                term,
                model,
                self.data,
                self.normalizer,
                idx,
                device,
                self.physics_cfg,
                self.binfo,
            )
        return PhysicsBatchResult(terms=terms, groups=group_losses_from_terms(terms, self.groups))

    def validation_batch_from_plan(
        self,
        model: torch.nn.Module,
        plan: Mapping[str, np.ndarray],
        batch_number: int,
        device: torch.device,
    ) -> PhysicsBatchResult:
        terms: dict[str, LossDiagnostics] = {}
        for term in ALL_TERMS:
            idx = physics_validation_plan_batch(plan, term, batch_number)
            terms[term] = compute_physics_term(
                term,
                model,
                self.data,
                self.normalizer,
                idx,
                device,
                self.physics_cfg,
                self.binfo,
            )
        return PhysicsBatchResult(terms=terms, groups=group_losses_from_terms(terms, self.groups))


def summarize_term_batch(
    result: PhysicsBatchResult,
) -> tuple[dict[str, float], dict[str, float], dict[str, float], dict[str, float]]:
    term_nd = {k: float(v.loss.detach().cpu()) for k, v in result.terms.items()}
    term_raw = {k: float(v.raw_mse.detach().cpu()) for k, v in result.terms.items()}
    term_scale = {k: float(v.scale) for k, v in result.terms.items()}
    group_nd = {k: float(v.detach().cpu()) for k, v in result.groups.items()}
    return term_nd, term_raw, term_scale, group_nd

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np

from .reference_data import CanonicalReferenceData
from .utils import load_json, save_json, sha256_jsonable


@dataclass
class Normalizer:
    branch_mean: np.ndarray
    branch_std: np.ndarray
    target_mean: np.ndarray
    target_std: np.ndarray
    x_scale_m: float
    z_scale_m: float
    t_scale_s: float
    eps: float = 1e-12

    def branch_to_norm(self, values: np.ndarray) -> np.ndarray:
        return ((np.asarray(values, dtype=np.float32) - self.branch_mean) / self.branch_std).astype(np.float32)

    def target_to_norm(self, values: np.ndarray) -> np.ndarray:
        return ((np.asarray(values, dtype=np.float32) - self.target_mean) / self.target_std).astype(np.float32)

    def target_from_norm(self, values: np.ndarray) -> np.ndarray:
        return (np.asarray(values, dtype=np.float32) * self.target_std + self.target_mean).astype(np.float32)

    def to_dict(self) -> dict[str, Any]:
        return {
            "branch_order": ["amplitude_m", "h_land_m"],
            "target_order": ["pressure_head_m", "concentration"],
            "branch_mean": self.branch_mean.astype(float).tolist(),
            "branch_std": self.branch_std.astype(float).tolist(),
            "target_mean": self.target_mean.astype(float).tolist(),
            "target_std": self.target_std.astype(float).tolist(),
            "x_scale_m": float(self.x_scale_m),
            "z_scale_m": float(self.z_scale_m),
            "t_scale_s": float(self.t_scale_s),
            "eps": float(self.eps),
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "Normalizer":
        return cls(
            branch_mean=np.asarray(d["branch_mean"], dtype=np.float32),
            branch_std=np.asarray(d["branch_std"], dtype=np.float32),
            target_mean=np.asarray(d["target_mean"], dtype=np.float32),
            target_std=np.asarray(d["target_std"], dtype=np.float32),
            x_scale_m=float(d["x_scale_m"]),
            z_scale_m=float(d["z_scale_m"]),
            t_scale_s=float(d["t_scale_s"]),
            eps=float(d.get("eps", 1e-12)),
        )


class RunningMoments:
    """Numerically stable population moments merged chunk-by-chunk in float64."""

    def __init__(self) -> None:
        self.count = 0
        self.mean = 0.0
        self.m2 = 0.0

    def update(self, values: np.ndarray) -> None:
        x = np.asarray(values, dtype=np.float64).reshape(-1)
        if x.size == 0:
            return
        n2 = int(x.size)
        mean2 = float(np.mean(x, dtype=np.float64))
        diff = x - mean2
        m22 = float(np.sum(diff * diff, dtype=np.float64))
        if self.count == 0:
            self.count, self.mean, self.m2 = n2, mean2, m22
            return
        delta = mean2 - self.mean
        n = self.count + n2
        self.m2 = self.m2 + m22 + delta * delta * self.count * n2 / n
        self.mean = self.mean + delta * n2 / n
        self.count = n

    @property
    def std(self) -> float:
        if self.count == 0:
            return float("nan")
        return float(np.sqrt(self.m2 / self.count))


def fit_train_only_normalizer(
    source: CanonicalReferenceData,
    physics_cfg: dict[str, Any],
    eps: float = 1e-12,
) -> tuple[Normalizer, dict[str, Any]]:
    train_idx = source.get_split_indices("train")
    if len(train_idx) == 0:
        raise ValueError("Source training split is empty; cannot fit normalizer")

    branch_train = np.asarray(source.branch[train_idx], dtype=np.float64)
    branch_mean64 = np.mean(branch_train, axis=0, dtype=np.float64)
    branch_std64 = np.std(branch_train, axis=0, ddof=0, dtype=np.float64)
    branch_std64 = np.where(branch_std64 < eps, 1.0, branch_std64)

    psi_stats = RunningMoments()
    con_stats = RunningMoments()
    for ci in train_idx:
        psi_stats.update(source.pressure_head[int(ci)])
        con_stats.update(source.concentration[int(ci)])

    target_mean64 = np.array([psi_stats.mean, con_stats.mean], dtype=np.float64)
    target_std64 = np.array([psi_stats.std, con_stats.std], dtype=np.float64)
    target_std64 = np.where(target_std64 < eps, 1.0, target_std64)

    norm = Normalizer(
        branch_mean=branch_mean64.astype(np.float32),
        branch_std=branch_std64.astype(np.float32),
        target_mean=target_mean64.astype(np.float32),
        target_std=target_std64.astype(np.float32),
        x_scale_m=float(physics_cfg["x_scale_m"]),
        z_scale_m=float(physics_cfg["z_scale_m"]),
        t_scale_s=float(physics_cfg["t_scale_s"]),
        eps=float(eps),
    )

    train_case_ids = source.case_metadata.iloc[train_idx]["case_id"].astype(str).tolist()
    metadata = {
        "fit_library": "source_range",
        "fit_split": "train",
        "n_fit_cases": int(len(train_idx)),
        "n_fit_points_per_target": int(len(train_idx) * source.n_time * source.n_node),
        "fit_case_ids": train_case_ids,
        "fit_case_ids_sha256": sha256_jsonable(train_case_ids),
        "branch_order": ["amplitude_m", "h_land_m"],
        "target_order": ["pressure_head_m", "concentration"],
        "population_std_ddof": 0,
        "accumulation_dtype": "float64",
    }
    return norm, metadata


def save_normalizer(normalizer: Normalizer, metadata: dict[str, Any], out_dir: str | Path) -> None:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    save_json(normalizer.to_dict(), out / "normalizer.json")
    save_json(metadata, out / "normalizer_metadata.json")


def load_normalizer(path: str | Path) -> Normalizer:
    return Normalizer.from_dict(load_json(path))



def fit_physics_only_normalizer(
    source: CanonicalReferenceData,
    physics_cfg: dict[str, Any],
    eps: float = 1e-12,
    target_mean_physical: tuple[float, float] = (0.0, 0.0),
    target_std_physical: tuple[float, float] = (4.0, 0.0357),
) -> tuple[Normalizer, dict[str, Any]]:
    """Fit only branch statistics from train cases; use fixed physical output scales.

    This deliberately avoids using transient SUTRA target statistics, preserving
    the Physics-only training protocol. The prescribed t=0 pressure field may
    still be used later as an initial-condition target.
    """
    train_idx = source.get_split_indices("train")
    if len(train_idx) == 0:
        raise ValueError("Source training split is empty; cannot fit branch normalizer")
    branch_train = np.asarray(source.branch[train_idx], dtype=np.float64)
    branch_mean64 = np.mean(branch_train, axis=0, dtype=np.float64)
    branch_std64 = np.std(branch_train, axis=0, ddof=0, dtype=np.float64)
    branch_std64 = np.where(branch_std64 < eps, 1.0, branch_std64)

    target_mean64 = np.asarray(target_mean_physical, dtype=np.float64)
    target_std64 = np.asarray(target_std_physical, dtype=np.float64)
    if target_mean64.shape != (2,) or target_std64.shape != (2,):
        raise ValueError("Physics-only target prior mean/std must have length 2")
    if np.any(np.abs(target_std64) < eps):
        raise ValueError("Physics-only target prior std must be non-zero")

    norm = Normalizer(
        branch_mean=branch_mean64.astype(np.float32),
        branch_std=branch_std64.astype(np.float32),
        target_mean=target_mean64.astype(np.float32),
        target_std=target_std64.astype(np.float32),
        x_scale_m=float(physics_cfg["x_scale_m"]),
        z_scale_m=float(physics_cfg["z_scale_m"]),
        t_scale_s=float(physics_cfg["t_scale_s"]),
        eps=float(eps),
    )
    train_case_ids = source.case_metadata.iloc[train_idx]["case_id"].astype(str).tolist()
    metadata = {
        "fit_library": "source_range",
        "fit_split": "train",
        "n_fit_cases": int(len(train_idx)),
        "fit_case_ids": train_case_ids,
        "fit_case_ids_sha256": sha256_jsonable(train_case_ids),
        "branch_order": ["amplitude_m", "h_land_m"],
        "target_order": ["pressure_head_m", "concentration"],
        "branch_statistics_source": "source train branches only",
        "target_scale_mode": "physical_prior",
        "target_mean_physical": target_mean64.tolist(),
        "target_std_physical": target_std64.tolist(),
        "transient_target_statistics_used": False,
        "note": "Physics-only normalization does not use t>0 SUTRA target statistics.",
        "population_std_ddof": 0,
        "accumulation_dtype": "float64",
    }
    return norm, metadata

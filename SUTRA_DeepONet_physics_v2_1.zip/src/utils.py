from __future__ import annotations

import ctypes
import hashlib
import json
import os
import platform
import random
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

import numpy as np
import yaml


def ensure_dir(path: str | Path) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def save_json(obj: Any, path: str | Path) -> None:
    p = Path(path)
    ensure_dir(p.parent)
    with p.open("w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)


def load_json(path: str | Path) -> Any:
    with Path(path).open("r", encoding="utf-8") as f:
        return json.load(f)


def save_yaml(obj: Any, path: str | Path) -> None:
    p = Path(path)
    ensure_dir(p.parent)
    with p.open("w", encoding="utf-8") as f:
        yaml.safe_dump(obj, f, allow_unicode=True, sort_keys=False)


def load_yaml(path: str | Path) -> Any:
    with Path(path).open("r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def timestamp() -> str:
    return time.strftime("%Y%m%d_%H%M%S")


def _import_torch():
    """Import PyTorch only when a model-dependent operation actually needs it.

    Data-only preflight must remain usable on machines that do not have PyTorch
    installed. Training/export stages call this helper and therefore still fail
    clearly if PyTorch is unavailable.
    """
    try:
        import torch
    except ModuleNotFoundError as exc:
        raise RuntimeError(
            "PyTorch is required for model training/inference but is not installed "
            "in the current Python environment. Data-only preflight does not need "
            "PyTorch; install a PyTorch build compatible with the target CPU/GPU "
            "environment before enabling training or prediction export."
        ) from exc
    return torch


def set_seed(seed: int) -> None:
    torch = _import_torch()
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True


def get_device(name: str = "auto") -> Any:
    torch = _import_torch()
    if name == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    dev = torch.device(name)
    if dev.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError(f"CUDA device requested ({name}) but CUDA is unavailable")
    return dev


def synchronize_device(device: Any) -> None:
    """Synchronize CUDA at timing boundaries; no-op for CPU/non-torch devices.

    CUDA kernels execute asynchronously with respect to the host. Wall-clock
    timings around GPU work therefore require an explicit synchronization at
    the beginning and end of the measured interval.
    """
    if getattr(device, "type", None) != "cuda":
        return
    torch = _import_torch()
    torch.cuda.synchronize(device)


def sha256_file(path: str | Path, chunk_size: int = 8 * 1024 * 1024) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        while True:
            block = f.read(chunk_size)
            if not block:
                break
            h.update(block)
    return h.hexdigest()


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def sha256_jsonable(obj: Any) -> str:
    payload = json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return sha256_text(payload)


def safe_rmtree(path: str | Path) -> None:
    p = Path(path)
    if p.exists():
        shutil.rmtree(p)


def write_complete_marker(path: str | Path, payload: dict[str, Any] | None = None) -> None:
    p = Path(path)
    ensure_dir(p.parent)
    data = payload or {"completed": True}
    data = dict(data)
    data.setdefault("completed", True)
    data.setdefault("created_at", time.strftime("%Y-%m-%d %H:%M:%S"))
    p.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _run_optional_command(command: list[str], timeout_s: float = 5.0) -> str | None:
    try:
        completed = subprocess.run(
            command,
            check=False,
            capture_output=True,
            text=True,
            timeout=timeout_s,
        )
    except Exception:
        return None
    if completed.returncode != 0:
        return None
    text = completed.stdout.strip()
    return text or None


def _collect_cpu_info() -> dict[str, Any]:
    info: dict[str, Any] = {
        "cpu_model": None,
        "cpu_physical_cores": None,
        "cpu_logical_cores": os.cpu_count(),
    }

    # Windows: CIM provides the most useful processor name/core counts without
    # introducing a new Python dependency such as psutil.
    if os.name == "nt":
        payload = _run_optional_command(
            [
                "powershell",
                "-NoProfile",
                "-Command",
                "Get-CimInstance Win32_Processor | "
                "Select-Object Name,NumberOfCores,NumberOfLogicalProcessors | "
                "ConvertTo-Json -Compress",
            ]
        )
        if payload:
            try:
                parsed = json.loads(payload)
                rows = parsed if isinstance(parsed, list) else [parsed]
                names = [str(r.get("Name", "")).strip() for r in rows if str(r.get("Name", "")).strip()]
                physical = [int(r["NumberOfCores"]) for r in rows if r.get("NumberOfCores") is not None]
                logical = [int(r["NumberOfLogicalProcessors"]) for r in rows if r.get("NumberOfLogicalProcessors") is not None]
                if names:
                    info["cpu_model"] = " | ".join(dict.fromkeys(names))
                if physical:
                    info["cpu_physical_cores"] = int(sum(physical))
                if logical:
                    info["cpu_logical_cores"] = int(sum(logical))
            except Exception:
                pass

    # Portable fallbacks for the model string.
    if not info["cpu_model"]:
        processor = platform.processor().strip()
        if processor:
            info["cpu_model"] = processor
        elif os.environ.get("PROCESSOR_IDENTIFIER"):
            info["cpu_model"] = os.environ.get("PROCESSOR_IDENTIFIER")
        elif Path("/proc/cpuinfo").is_file():
            try:
                for line in Path("/proc/cpuinfo").read_text(encoding="utf-8", errors="ignore").splitlines():
                    if line.lower().startswith("model name") and ":" in line:
                        info["cpu_model"] = line.split(":", 1)[1].strip()
                        break
            except Exception:
                pass

    return info


def _system_memory_total_bytes() -> int | None:
    if os.name == "nt":
        class MEMORYSTATUSEX(ctypes.Structure):
            _fields_ = [
                ("dwLength", ctypes.c_ulong),
                ("dwMemoryLoad", ctypes.c_ulong),
                ("ullTotalPhys", ctypes.c_ulonglong),
                ("ullAvailPhys", ctypes.c_ulonglong),
                ("ullTotalPageFile", ctypes.c_ulonglong),
                ("ullAvailPageFile", ctypes.c_ulonglong),
                ("ullTotalVirtual", ctypes.c_ulonglong),
                ("ullAvailVirtual", ctypes.c_ulonglong),
                ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
            ]

        status = MEMORYSTATUSEX()
        status.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
        try:
            ok = ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status))
            if ok:
                return int(status.ullTotalPhys)
        except Exception:
            return None

    # POSIX fallback.
    try:
        page_size = int(os.sysconf("SC_PAGE_SIZE"))
        pages = int(os.sysconf("SC_PHYS_PAGES"))
        return page_size * pages
    except Exception:
        return None


def _collect_nvidia_smi_info() -> dict[str, Any]:
    output = _run_optional_command(
        [
            "nvidia-smi",
            "--query-gpu=index,name,driver_version,memory.total",
            "--format=csv,noheader,nounits",
        ]
    )
    if not output:
        return {
            "nvidia_smi_available": False,
            "nvidia_driver_version": None,
            "nvidia_smi_gpus": [],
        }

    rows: list[dict[str, Any]] = []
    drivers: list[str] = []
    for line in output.splitlines():
        parts = [x.strip() for x in line.split(",")]
        if len(parts) < 4:
            continue
        try:
            idx = int(parts[0])
        except ValueError:
            idx = None
        try:
            mem_mib = float(parts[3])
        except ValueError:
            mem_mib = None
        rows.append(
            {
                "index": idx,
                "name": parts[1],
                "driver_version": parts[2],
                "memory_total_mib": mem_mib,
            }
        )
        if parts[2]:
            drivers.append(parts[2])

    unique_drivers = list(dict.fromkeys(drivers))
    return {
        "nvidia_smi_available": True,
        "nvidia_driver_version": unique_drivers[0] if len(unique_drivers) == 1 else unique_drivers,
        "nvidia_smi_gpus": rows,
    }


def collect_environment() -> dict[str, Any]:
    """Collect reproducibility/hardware metadata without making torch mandatory.

    The function is intentionally best-effort: optional hardware probes must
    never break data-only preflight. When PyTorch/CUDA are available it records
    GPU names, total memory and cuDNN information; otherwise those fields remain
    null/empty and the import error is recorded.
    """
    memory_bytes = _system_memory_total_bytes()
    info: dict[str, Any] = {
        "python": sys.version,
        "platform": platform.platform(),
        "numpy": np.__version__,
        "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
        "cwd": str(Path.cwd()),
        **_collect_cpu_info(),
        "system_memory_total_bytes": memory_bytes,
        "system_memory_total_gb": None if memory_bytes is None else float(memory_bytes / (1024 ** 3)),
    }
    info.update(_collect_nvidia_smi_info())

    try:
        import torch
    except Exception as exc:  # Import can fail for missing/incompatible binary builds.
        info.update(
            {
                "torch_installed": False,
                "torch": None,
                "cuda_available": None,
                "cuda_version": None,
                "cudnn_version": None,
                "cudnn_enabled": None,
                "torch_num_threads": None,
                "torch_num_interop_threads": None,
                "gpu_count": None,
                "active_cuda_device_index": None,
                "active_gpu_name": None,
                "active_gpu_total_memory_gb": None,
                "gpu_devices": [],
                "torch_import_error": f"{type(exc).__name__}: {exc}",
            }
        )
    else:
        cuda_available = bool(torch.cuda.is_available())
        gpu_devices: list[dict[str, Any]] = []
        active_idx: int | None = None
        if cuda_available:
            try:
                active_idx = int(torch.cuda.current_device())
            except Exception:
                active_idx = None
            for idx in range(int(torch.cuda.device_count())):
                props = torch.cuda.get_device_properties(idx)
                gpu_devices.append(
                    {
                        "index": int(idx),
                        "name": str(props.name),
                        "total_memory_bytes": int(props.total_memory),
                        "total_memory_gb": float(props.total_memory / (1024 ** 3)),
                        "compute_capability": f"{int(props.major)}.{int(props.minor)}",
                        "multi_processor_count": int(props.multi_processor_count),
                    }
                )
        active_gpu = None
        if active_idx is not None:
            active_gpu = next((row for row in gpu_devices if row["index"] == active_idx), None)

        info.update(
            {
                "torch_installed": True,
                "torch": torch.__version__,
                "cuda_available": cuda_available,
                "cuda_version": torch.version.cuda,
                "cudnn_version": torch.backends.cudnn.version(),
                "cudnn_enabled": bool(torch.backends.cudnn.enabled),
                "torch_num_threads": int(torch.get_num_threads()),
                "torch_num_interop_threads": int(torch.get_num_interop_threads()),
                "gpu_count": int(torch.cuda.device_count()) if cuda_available else 0,
                "active_cuda_device_index": active_idx,
                "active_gpu_name": None if active_gpu is None else active_gpu["name"],
                "active_gpu_total_memory_gb": None if active_gpu is None else active_gpu["total_memory_gb"],
                "gpu_devices": gpu_devices,
                "torch_import_error": None,
            }
        )
    return info


def resolve_path(base: Path, value: str | Path | None) -> Path | None:
    if value is None:
        return None
    p = Path(value).expanduser()
    return p if p.is_absolute() else (base / p).resolve()

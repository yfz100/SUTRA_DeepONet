from __future__ import annotations

from pathlib import Path
from typing import Any


def validate_config(cfg: dict[str, Any]) -> None:
    required_top = [
        "project", "paths", "physics", "normalization", "model", "training",
        "physics_regularization", "inference", "metrics",
    ]
    missing = [k for k in required_top if k not in cfg]
    if missing:
        raise ValueError(f"Config missing top-level keys: {missing}")

    paths = cfg["paths"]
    for key in ["source_processed_dir", "ood_processed_dir", "manifest_path", "run_root"]:
        if key not in paths or not str(paths[key]).strip():
            raise ValueError(f"Config paths.{key} is required")

    physics = cfg["physics"]
    for key in ["tidal_period_s", "x_scale_m", "z_scale_m", "t_scale_s"]:
        if float(physics[key]) <= 0:
            raise ValueError(f"physics.{key} must be > 0")
    if list(physics.get("branch_order", [])) != ["amplitude_m", "h_land_m"]:
        raise ValueError("physics.branch_order must be ['amplitude_m','h_land_m']")
    if list(physics.get("target_order", [])) != ["pressure_head_m", "concentration"]:
        raise ValueError("physics.target_order must be ['pressure_head_m','concentration']")

    model = cfg["model"]
    if int(model.get("branch_dim", -1)) != 2:
        raise ValueError("Physics v2.1 requires model.branch_dim = 2 for [A, H_land]")
    if int(model.get("trunk_dim", -1)) != 7:
        raise ValueError("Physics v2.1 requires model.trunk_dim = 7")
    if int(model.get("output_dim", -1)) != 2:
        raise ValueError("Physics v2.1 requires model.output_dim = 2")

    tr = cfg["training"]
    mode = str(tr.get("mode", "")).lower().strip()
    if mode not in {"hybrid", "physics_only"}:
        raise ValueError("training.mode must be 'hybrid' or 'physics_only'")
    for key in ["epochs", "batch_size", "num_samples_per_epoch", "physics_batches_per_epoch", "val_points_per_case"]:
        if int(tr[key]) <= 0:
            raise ValueError(f"training.{key} must be positive")
    if int(tr["num_samples_per_epoch"]) < int(tr["batch_size"]):
        raise ValueError("num_samples_per_epoch must be >= batch_size")
    if float(tr["learning_rate"]) <= 0:
        raise ValueError("training.learning_rate must be > 0")
    if int(tr.get("val_every_epochs", 0)) <= 0:
        raise ValueError("training.val_every_epochs must be positive")
    if int(tr.get("early_stopping_patience_epochs", 0)) <= 0:
        raise ValueError("training.early_stopping_patience_epochs must be positive")

    loss_weights = tr.get("loss_weights", [1.0, 1.0])
    if len(loss_weights) != 2 or any(float(x) < 0 for x in loss_weights) or sum(float(x) for x in loss_weights) <= 0:
        raise ValueError("training.loss_weights must contain two nonnegative values with positive sum")

    norm = cfg["normalization"]
    if float(norm.get("eps", 0.0)) <= 0:
        raise ValueError("normalization.eps must be > 0")
    if mode == "physics_only":
        po = norm.get("physics_only", {})
        mean = po.get("target_mean_physical")
        std = po.get("target_std_physical")
        if not isinstance(mean, list) or len(mean) != 2 or not isinstance(std, list) or len(std) != 2:
            raise ValueError("normalization.physics_only target mean/std must each have length 2")
        if any(float(v) <= 0 for v in std):
            raise ValueError("normalization.physics_only target std values must be > 0")
        if bool(po.get("transient_target_statistics_used", True)):
            raise ValueError("Physics-only must not use transient SUTRA target statistics for normalization")

    pr = cfg["physics_regularization"]
    if not bool(pr.get("enabled", False)):
        raise ValueError("physics_regularization.enabled must be true in the Section 4.2 package")
    if "common_physics" not in pr or "batch_sizes" not in pr or "relobralo" not in pr:
        raise ValueError("physics_regularization is incomplete")


def normalized_config_for_hash(cfg: dict[str, Any]) -> dict[str, Any]:
    return cfg


def ensure_input_paths_exist(cfg: dict[str, Any]) -> None:
    paths = cfg["paths"]
    for key in ["source_processed_dir", "ood_processed_dir", "manifest_path"]:
        p = Path(paths[key])
        if not p.exists():
            raise FileNotFoundError(f"Configured input path does not exist: paths.{key}={p}")

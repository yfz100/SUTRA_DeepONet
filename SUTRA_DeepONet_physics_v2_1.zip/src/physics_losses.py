from __future__ import annotations

"""Continuous strong-form physics losses for the SUTRA2.2 coupled problem.

The residuals use the governing-process terms and constitutive relationships
adopted in the formal SUTRA reference problem, but they are NOT SUTRA's finite-
element/upstream-weighted algebraic residuals.

Canonical model outputs:
    y[:,0] = pressure head psi = pressure_pa / 9810
    y[:,1] = solute mass fraction C

Branch order:
    [tidal amplitude A, inland head H_land]
"""

from dataclasses import dataclass
from typing import Mapping

import numpy as np
import torch

from .normalization import Normalizer
from .physics_sampling import BoundaryInfo, PhysicsIndices
from .reference_data import CanonicalReferenceData


@dataclass
class LossDiagnostics:
    loss: torch.Tensor
    raw_mse: torch.Tensor
    scale: float


def _positive_float(value: float, default: float, eps: float = 1.0e-30) -> float:
    try:
        v = float(value)
    except Exception:
        v = float(default)
    if not np.isfinite(v) or v <= eps:
        return float(default)
    return v


def _diag_loss(raw: torch.Tensor, scale: float) -> LossDiagnostics:
    s = _positive_float(scale, 1.0)
    nd = raw / s
    return LossDiagnostics(torch.mean(nd * nd), torch.mean(raw * raw), float(s))


def ramp_weight(epoch: int, target: float, ramp_epochs: int) -> float:
    target = float(target)
    ramp_epochs = int(ramp_epochs)
    if target <= 0:
        return 0.0
    if ramp_epochs <= 0:
        return target
    return target * min(1.0, max(0.0, float(epoch) / float(ramp_epochs)))


def characteristic_scales(normalizer: Normalizer, cfg: Mapping[str, float]) -> dict[str, float]:
    eps = _positive_float(cfg.get("normalization_eps", 1.0e-12), 1.0e-12)
    gamma_ref = _positive_float(cfg.get("gamma_ref_pa_per_m", 9810.0), 9810.0)
    psi_scale = _positive_float(cfg.get("psi_scale_m", 0.0), float(normalizer.target_std[0]))
    c_scale = _positive_float(cfg.get("concentration_scale", 0.0), float(normalizer.target_std[1]))
    pressure_scale = _positive_float(cfg.get("pressure_scale_pa", 0.0), gamma_ref * psi_scale)
    t_scale = _positive_float(cfg.get("time_scale_s", 0.0), float(normalizer.t_scale_s))
    L_scale = _positive_float(cfg.get("length_scale_m", 0.0), max(float(normalizer.x_scale_m), 1.0))
    rho0 = _positive_float(cfg.get("rho0_kg_m3", 1000.0), 1000.0)
    por = _positive_float(cfg.get("porosity", 0.46), 0.46)
    compma = float(cfg.get("matrix_compressibility_per_pa", 1.0e-8))
    compfl = float(cfg.get("fluid_compressibility_per_pa", 0.0))
    sop = abs((1.0 - por) * compma + por * compfl)
    drho = abs(float(cfg.get("drho_dC_kg_m3", 700.0)))
    dmol = abs(float(cfg.get("molecular_diffusivity_m2_s", 1.0e-9)))
    q_scale = _positive_float(cfg.get("flow_flux_scale_m_s", 1.0e-4), 1.0e-4)
    solute_flux_scale = _positive_float(
        cfg.get("solute_flux_scale", 0.0), rho0 * q_scale * c_scale
    )
    storage_scale = max(
        sop * pressure_scale / t_scale,
        por * drho / rho0 * c_scale / t_scale,
        eps,
    )
    divq_scale = q_scale / L_scale
    flow_pde_scale = _positive_float(
        cfg.get("flow_pde_scale", 0.0), max(storage_scale, divq_scale, eps)
    )
    trans_storage = por * rho0 * c_scale / t_scale
    trans_adv = rho0 * q_scale * c_scale / L_scale
    trans_disp = por * rho0 * dmol * c_scale / (L_scale * L_scale)
    transport_pde_scale = _positive_float(
        cfg.get("transport_pde_scale", 0.0), max(trans_storage, trans_adv, trans_disp, eps)
    )
    return {
        "eps": eps,
        "psi_scale_m": psi_scale,
        "concentration_scale": c_scale,
        "pressure_scale_pa": pressure_scale,
        "time_scale_s": t_scale,
        "length_scale_m": L_scale,
        "flow_flux_scale_m_s": q_scale,
        "solute_flux_scale": solute_flux_scale,
        "flow_pde_scale": flow_pde_scale,
        "transport_pde_scale": transport_pde_scale,
    }


def build_trunk_from_raw_tensors(
    normalizer: Normalizer,
    x_raw: torch.Tensor,
    z_raw: torch.Tensor,
    t_raw: torch.Tensor,
    tidal_period_s: float,
) -> torch.Tensor:
    omega_t = 2.0 * torch.pi * t_raw / float(tidal_period_s)
    return torch.cat(
        [
            x_raw / float(normalizer.x_scale_m),
            z_raw / float(normalizer.z_scale_m),
            t_raw / float(normalizer.t_scale_s),
            torch.sin(omega_t),
            torch.cos(omega_t),
            torch.sin(2.0 * omega_t),
            torch.cos(2.0 * omega_t),
        ],
        dim=1,
    )


def _grad_sum(y: torch.Tensor, x: torch.Tensor, create_graph: bool = True) -> torch.Tensor:
    return torch.autograd.grad(
        y.sum(), x, create_graph=create_graph, retain_graph=True, only_inputs=True
    )[0]


def _denormalize_outputs(normalizer: Normalizer, y_norm: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    mean = torch.as_tensor(normalizer.target_mean, dtype=y_norm.dtype, device=y_norm.device)
    std = torch.as_tensor(normalizer.target_std, dtype=y_norm.dtype, device=y_norm.device)
    y = y_norm * std + mean
    return y[:, 0:1], y[:, 1:2]


def _normalize_target_tensor(normalizer: Normalizer, value: torch.Tensor, channel: int) -> torch.Tensor:
    mean = torch.as_tensor(float(normalizer.target_mean[channel]), dtype=value.dtype, device=value.device)
    std = torch.as_tensor(float(normalizer.target_std[channel]), dtype=value.dtype, device=value.device)
    return (value - mean) / std


def sutra_vgen_saturation_dsdP_kr(
    pressure: torch.Tensor, cfg: Mapping[str, float]
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """SUTRA 2.2 user-subroutine VGEN/RELPERM formulas.

    Formal source values are SWRES=0.30, AA=5e-5 1/Pa, VN=2.0.
    No RKMIN floor is applied.
    """
    swres = float(cfg.get("swres", 0.30))
    aa = float(cfg.get("aa_inv_pa", 5.0e-5))
    vn = float(cfg.get("vg_n", 2.0))
    eps = torch.as_tensor(1.0e-12, dtype=pressure.dtype, device=pressure.device)
    swres_t = torch.as_tensor(swres, dtype=pressure.dtype, device=pressure.device)
    aa_t = torch.as_tensor(aa, dtype=pressure.dtype, device=pressure.device)
    vn_t = torch.as_tensor(vn, dtype=pressure.dtype, device=pressure.device)
    vnf = (vn_t - 1.0) / vn_t
    swrm1 = 1.0 - swres_t
    pneg = pressure < 0.0
    x = torch.clamp(aa_t * (-pressure), min=0.0)
    aapvn = 1.0 + torch.pow(x + eps, vn_t)
    aapvnn = torch.pow(aapvn, vnf)
    s_unsat = swres_t + swrm1 / aapvnn
    dsdP_unsat = (
        aa_t * (vn_t - 1.0) * swrm1 * torch.pow(x + eps, vn_t - 1.0) / (aapvn * aapvnn)
    )
    s = torch.where(pneg, s_unsat, torch.ones_like(pressure))
    dsdP = torch.where(pneg, dsdP_unsat, torch.zeros_like(pressure))
    s = torch.clamp(s, min=swres + 1.0e-8, max=1.0)

    eps_kr = torch.as_tensor(1.0e-7, dtype=pressure.dtype, device=pressure.device)
    s_for_kr = torch.where(pneg, s, swres_t + swrm1 * (1.0 - eps_kr))
    swstar = torch.clamp((s_for_kr - swres_t) / swrm1, min=eps_kr, max=1.0 - eps_kr)
    one_minus = torch.clamp(1.0 - torch.pow(swstar, 1.0 / vnf), min=eps_kr, max=1.0)
    kr_unsat = torch.sqrt(swstar) * torch.square(1.0 - torch.pow(one_minus, vnf))
    kr_unsat = torch.clamp(kr_unsat, min=0.0, max=1.0)
    kr = torch.where(pneg, kr_unsat, torch.ones_like(pressure))
    return s, dsdP, kr


def physical_fields(
    model: torch.nn.Module,
    normalizer: Normalizer,
    branch_norm: torch.Tensor,
    x_raw: torch.Tensor,
    z_raw: torch.Tensor,
    t_raw: torch.Tensor,
    cfg: Mapping[str, float],
    create_graph: bool = True,
) -> dict[str, torch.Tensor]:
    x = x_raw.detach().clone().requires_grad_(True)
    z = z_raw.detach().clone().requires_grad_(True)
    t = t_raw.detach().clone().requires_grad_(True)
    trunk = build_trunk_from_raw_tensors(
        normalizer, x, z, t, float(cfg.get("tidal_period_s", 43200.0))
    )
    y_norm = model(branch_norm, trunk)
    psi, C = _denormalize_outputs(normalizer, y_norm)

    gamma_ref = float(cfg.get("gamma_ref_pa_per_m", 9810.0))
    pressure = psi * gamma_ref
    rho0 = float(cfg.get("rho0_kg_m3", 1000.0))
    c_ref = float(cfg.get("c_ref", 0.0))
    drho = float(cfg.get("drho_dC_kg_m3", 700.0))
    rho = rho0 + drho * (C - c_ref)
    if bool(cfg.get("density_clip_enabled", False)):
        rho = torch.clamp(
            rho,
            min=float(cfg.get("rho_min_kg_m3", 950.0)),
            max=float(cfg.get("rho_max_kg_m3", 1100.0)),
        )

    S, dSdP, kr = sutra_vgen_saturation_dsdP_kr(pressure, cfg)
    P_x = _grad_sum(pressure, x, create_graph=create_graph)
    P_z = _grad_sum(pressure, z, create_graph=create_graph)
    P_t = _grad_sum(pressure, t, create_graph=create_graph)
    C_x = _grad_sum(C, x, create_graph=create_graph)
    C_z = _grad_sum(C, z, create_graph=create_graph)
    C_t = _grad_sum(C, t, create_graph=create_graph)

    k = float(cfg.get("permeability_m2", 1.0e-10))
    mu = float(cfg.get("viscosity_pa_s", 1.0e-3))
    gx = float(cfg.get("gravity_x_m_s2", 0.0))
    gz = float(cfg.get("gravity_z_m_s2", -9.81))
    mobility = k * kr / mu
    qx = -mobility * (P_x - rho * gx)
    qz = -mobility * (P_z - rho * gz)

    por = float(cfg.get("porosity", 0.46))
    tiny = torch.as_tensor(1.0e-12, dtype=pressure.dtype, device=pressure.device)
    vp_denom = torch.clamp(por * S, min=1.0e-8)
    vx = qx / vp_denom
    vz = qz / vp_denom
    vmag = torch.sqrt(vx * vx + vz * vz + tiny)
    alpha_l = float(cfg.get("alpha_l_m", 2.0e-3))
    alpha_t = float(cfg.get("alpha_t_m", 2.0e-4))
    dmol = float(cfg.get("molecular_diffusivity_m2_s", 1.0e-9))
    Dxx = dmol + alpha_t * vmag + (alpha_l - alpha_t) * vx * vx / vmag
    Dzz = dmol + alpha_t * vmag + (alpha_l - alpha_t) * vz * vz / vmag
    Dxz = (alpha_l - alpha_t) * vx * vz / vmag

    return {
        "x": x,
        "z": z,
        "t": t,
        "y_norm": y_norm,
        "psi": psi,
        "C": C,
        "pressure": pressure,
        "rho": rho,
        "S": S,
        "dSdP": dSdP,
        "kr": kr,
        "P_x": P_x,
        "P_z": P_z,
        "P_t": P_t,
        "C_x": C_x,
        "C_z": C_z,
        "C_t": C_t,
        "qx": qx,
        "qz": qz,
        "Dxx": Dxx,
        "Dzz": Dzz,
        "Dxz": Dxz,
    }


def flow_residual(
    model: torch.nn.Module,
    normalizer: Normalizer,
    branch_norm: torch.Tensor,
    x: torch.Tensor,
    z: torch.Tensor,
    t: torch.Tensor,
    cfg: Mapping[str, float],
) -> torch.Tensor:
    f = physical_fields(model, normalizer, branch_norm, x, z, t, cfg, create_graph=True)
    por = float(cfg.get("porosity", 0.46))
    compma = float(cfg.get("matrix_compressibility_per_pa", 1.0e-8))
    compfl = float(cfg.get("fluid_compressibility_per_pa", 0.0))
    sop = (1.0 - por) * compma + por * compfl
    drho = float(cfg.get("drho_dC_kg_m3", 700.0))
    rho = f["rho"]
    storage = f["S"] * sop + por * f["dSdP"]
    div_q = _grad_sum(f["qx"], f["x"], True) + _grad_sum(f["qz"], f["z"], True)
    inv_rho = 1.0 / torch.clamp(rho, min=1.0e-6)
    density_grad = drho * inv_rho * (f["qx"] * f["C_x"] + f["qz"] * f["C_z"])
    density_time = por * f["S"] * drho * inv_rho * f["C_t"]
    return storage * f["P_t"] + density_time + div_q + density_grad


def transport_residual(
    model: torch.nn.Module,
    normalizer: Normalizer,
    branch_norm: torch.Tensor,
    x: torch.Tensor,
    z: torch.Tensor,
    t: torch.Tensor,
    cfg: Mapping[str, float],
) -> torch.Tensor:
    f = physical_fields(model, normalizer, branch_norm, x, z, t, cfg, create_graph=True)
    por = float(cfg.get("porosity", 0.46))
    mass = por * f["S"] * f["rho"] * f["C"]
    mass_t = _grad_sum(mass, f["t"], True)
    dispersive_x = por * f["S"] * f["rho"] * (f["Dxx"] * f["C_x"] + f["Dxz"] * f["C_z"])
    dispersive_z = por * f["S"] * f["rho"] * (f["Dxz"] * f["C_x"] + f["Dzz"] * f["C_z"])
    flux_x = f["rho"] * f["qx"] * f["C"] - dispersive_x
    flux_z = f["rho"] * f["qz"] * f["C"] - dispersive_z
    return mass_t + _grad_sum(flux_x, f["x"], True) + _grad_sum(flux_z, f["z"], True)


def _index_tensors(
    data: CanonicalReferenceData,
    normalizer: Normalizer,
    idx: PhysicsIndices,
    device: torch.device,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    raw_branch = np.asarray(data.branch[idx.case_index], dtype=np.float32)
    branch = torch.from_numpy(normalizer.branch_to_norm(raw_branch)).to(device, non_blocking=True)
    x = torch.from_numpy(np.asarray(data.coords[idx.node_index, 0:1], dtype=np.float32)).to(device, non_blocking=True)
    z = torch.from_numpy(np.asarray(data.coords[idx.node_index, 1:2], dtype=np.float32)).to(device, non_blocking=True)
    t = torch.from_numpy(np.asarray(data.times[idx.time_index, None], dtype=np.float32)).to(device, non_blocking=True)
    return branch, x, z, t


def _value_loss_channel(
    model: torch.nn.Module,
    normalizer: Normalizer,
    branch: torch.Tensor,
    x: torch.Tensor,
    z: torch.Tensor,
    t: torch.Tensor,
    target_physical: torch.Tensor,
    cfg: Mapping[str, float],
    channel: int,
) -> LossDiagnostics:
    trunk = build_trunk_from_raw_tensors(normalizer, x, z, t, float(cfg.get("tidal_period_s", 43200.0)))
    pred = model(branch, trunk)[:, channel : channel + 1]
    target_norm = _normalize_target_tensor(normalizer, target_physical, channel)
    diff_norm = pred - target_norm
    nd_mse = torch.mean(diff_norm * diff_norm)
    scale = float(normalizer.target_std[channel])
    return LossDiagnostics(nd_mse, nd_mse * (scale * scale), scale)


def _normal_flux_loss(
    model: torch.nn.Module,
    normalizer: Normalizer,
    branch: torch.Tensor,
    x: torch.Tensor,
    z: torch.Tensor,
    t: torch.Tensor,
    cfg: Mapping[str, float],
    normal: tuple[float, float],
    component: str,
) -> LossDiagnostics:
    f = physical_fields(model, normalizer, branch, x, z, t, cfg, create_graph=True)
    nx, nz = normal
    qn = f["qx"] * nx + f["qz"] * nz
    scales = characteristic_scales(normalizer, cfg)
    if component == "flow":
        return _diag_loss(qn, scales["flow_flux_scale_m_s"])
    if component == "solute":
        por = float(cfg.get("porosity", 0.46))
        disp_x = por * f["S"] * f["rho"] * (f["Dxx"] * f["C_x"] + f["Dxz"] * f["C_z"])
        disp_z = por * f["S"] * f["rho"] * (f["Dxz"] * f["C_x"] + f["Dzz"] * f["C_z"])
        flux_n = f["rho"] * qn * f["C"] - (disp_x * nx + disp_z * nz)
        return _diag_loss(flux_n, scales["solute_flux_scale"])
    raise ValueError(component)


def _inflow_source_concentration_loss(
    model: torch.nn.Module,
    normalizer: Normalizer,
    branch: torch.Tensor,
    x: torch.Tensor,
    z: torch.Tensor,
    t: torch.Tensor,
    cfg: Mapping[str, float],
    outward_normal: tuple[float, float],
    target_c: float,
) -> LossDiagnostics:
    # q_n only decides whether specified-pressure fluid is entering. The gating
    # weight is detached so this term is not a disguised flow-flux residual.
    f = physical_fields(model, normalizer, branch, x, z, t, cfg, create_graph=False)
    nx, nz = outward_normal
    qn = f["qx"] * nx + f["qz"] * nz
    scales = characteristic_scales(normalizer, cfg)
    qscale = max(float(cfg.get("inflow_flux_scale_m_s", scales["flow_flux_scale_m_s"])), 1.0e-30)
    tol = float(cfg.get("inflow_flux_tolerance_m_s", 0.0))
    mode = str(cfg.get("inflow_weight_mode", "smooth_relu")).lower()
    if mode == "hard":
        weight = (qn < -tol).to(f["C"].dtype)
    else:
        weight = torch.clamp((-qn - tol) / qscale, min=0.0, max=1.0)
    weight = weight.detach()
    residual = weight * (f["C"] - float(target_c))
    return _diag_loss(residual, scales["concentration_scale"])


def compute_physics_term(
    term: str,
    model: torch.nn.Module,
    data: CanonicalReferenceData,
    normalizer: Normalizer,
    idx: PhysicsIndices,
    device: torch.device,
    cfg: Mapping[str, float],
    binfo: BoundaryInfo,
) -> LossDiagnostics:
    branch, x, z, t = _index_tensors(data, normalizer, idx, device)
    scales = characteristic_scales(normalizer, cfg)

    if term == "flow_pde":
        return _diag_loss(flow_residual(model, normalizer, branch, x, z, t, cfg), scales["flow_pde_scale"])
    if term == "transport_pde":
        return _diag_loss(transport_residual(model, normalizer, branch, x, z, t, cfg), scales["transport_pde_scale"])

    if term == "ic_psi":
        target = np.asarray(data.pressure_head[idx.case_index, 0, idx.node_index], dtype=np.float32)[:, None]
        target_t = torch.from_numpy(target).to(device)
        return _value_loss_channel(model, normalizer, branch, x, z, t, target_t, cfg, 0)
    if term == "ic_u":
        target_t = torch.zeros((idx.size, 1), dtype=torch.float32, device=device)
        return _value_loss_channel(model, normalizer, branch, x, z, t, target_t, cfg, 1)

    if term == "land_p":
        H = torch.from_numpy(np.asarray(data.branch[idx.case_index, 1:2], dtype=np.float32)).to(device)
        return _value_loss_channel(model, normalizer, branch, x, z, t, H - z, cfg, 0)

    if term == "sea_p":
        A = torch.from_numpy(np.asarray(data.branch[idx.case_index, 0:1], dtype=np.float32)).to(device)
        eta0 = float(cfg.get("eta0_m", 2.5))
        period = float(cfg.get("tidal_period_s", 43200.0))
        phase = float(cfg.get("phase_rad", 0.0))
        eta = eta0 + A * torch.sin(2.0 * torch.pi * t / period + phase)
        gamma_ref = float(cfg.get("gamma_ref_pa_per_m", 9810.0))
        gamma_sea = float(cfg.get("gamma_sea_pa_per_m", 10055.1519))
        psi_target = (gamma_sea / gamma_ref) * (eta - z)
        return _value_loss_channel(model, normalizer, branch, x, z, t, psi_target, cfg, 0)

    if term == "land_u":
        return _inflow_source_concentration_loss(
            model, normalizer, branch, x, z, t, cfg, (-1.0, 0.0), float(cfg.get("land_concentration", 0.0))
        )
    if term == "sea_inflow_u":
        nn = float(np.hypot(1.0, 1.75))
        return _inflow_source_concentration_loss(
            model,
            normalizer,
            branch,
            x,
            z,
            t,
            cfg,
            (1.0 / nn, 1.75 / nn),
            float(cfg.get("sea_concentration", 0.0357)),
        )

    if term in {"bottom_flow", "bottom_solute"}:
        return _normal_flux_loss(
            model, normalizer, branch, x, z, t, cfg, (0.0, -1.0), "flow" if term.endswith("flow") else "solute"
        )
    if term in {"top_flow", "top_solute"}:
        return _normal_flux_loss(
            model, normalizer, branch, x, z, t, cfg, (0.0, 1.0), "flow" if term.endswith("flow") else "solute"
        )
    if term in {"exposed_flow", "exposed_solute"}:
        nn = float(np.hypot(1.0, 1.75))
        return _normal_flux_loss(
            model,
            normalizer,
            branch,
            x,
            z,
            t,
            cfg,
            (1.0 / nn, 1.75 / nn),
            "flow" if term.endswith("flow") else "solute",
        )
    raise KeyError(term)

from __future__ import annotations

"""Group-level ReLoBRaLo adaptive weighting for physics regularization.

This implementation follows the loss-statistics idea of ReLoBRaLo
(Relative Loss Balancing with Random Lookback) but adapts it for a
SUTRA surrogate-model setting:

* data loss is kept as the fixed anchor and is not balanced by ReLoBRaLo;
* only normalized physics-residual groups are balanced;
* a separate alpha_phys controls the total physics contribution;
* group weights are clamped and re-normalized for numerical safety.
"""

from dataclasses import dataclass, field
from typing import Dict, Iterable, Mapping

import numpy as np


@dataclass
class ReLoBRaLoGroupBalancer:
    group_names: list[str]
    alpha_memory: float = 0.95
    temperature: float = 0.2
    expected_rho: float = 0.99
    weight_min: float = 0.2
    weight_max: float = 5.0
    eps: float = 1.0e-12
    renormalize_after_clamp: bool = True
    seed: int = 20269692
    weights: Dict[str, float] = field(default_factory=dict)
    initial_losses: Dict[str, float] = field(default_factory=dict)
    previous_losses: Dict[str, float] = field(default_factory=dict)
    n_updates: int = 0

    def __post_init__(self) -> None:
        if not self.group_names:
            raise ValueError("ReLoBRaLoGroupBalancer requires at least one group.")
        self.group_names = list(self.group_names)
        self.rng = np.random.default_rng(int(self.seed))
        if not self.weights:
            self.weights = {g: 1.0 for g in self.group_names}
        self.alpha_memory = float(self.alpha_memory)
        self.temperature = float(self.temperature)
        self.expected_rho = float(self.expected_rho)
        self.weight_min = float(self.weight_min)
        self.weight_max = float(self.weight_max)
        self.eps = float(self.eps)
        if self.temperature <= 0.0:
            raise ValueError("temperature must be positive.")
        if not (0.0 <= self.alpha_memory <= 1.0):
            raise ValueError("alpha_memory must be in [0, 1].")
        if not (0.0 <= self.expected_rho <= 1.0):
            raise ValueError("expected_rho must be in [0, 1].")
        if self.weight_min <= 0.0 or self.weight_max < self.weight_min:
            raise ValueError("Invalid group weight clamp range.")

    def current_weights(self) -> Dict[str, float]:
        return {g: float(self.weights.get(g, 1.0)) for g in self.group_names}

    @staticmethod
    def _clean_loss(value: float, eps: float) -> float:
        try:
            v = float(value)
        except Exception:
            v = float("nan")
        if not np.isfinite(v):
            return float("nan")
        return max(v, eps)

    def _softmax_balancing(self, current: Mapping[str, float], reference: Mapping[str, float]) -> Dict[str, float]:
        ratios = []
        valid_groups = []
        for g in self.group_names:
            cur = self._clean_loss(current.get(g, np.nan), self.eps)
            ref = self._clean_loss(reference.get(g, np.nan), self.eps)
            if np.isfinite(cur) and np.isfinite(ref):
                ratios.append(cur / (self.temperature * ref + self.eps))
                valid_groups.append(g)
        if not valid_groups:
            return self.current_weights()
        arr = np.asarray(ratios, dtype=np.float64)
        # Numerical stability. Larger ratio means slower progress/worsening -> higher weight.
        arr = arr - np.max(arr)
        probs = np.exp(arr)
        probs = probs / max(float(np.sum(probs)), self.eps)
        # ReLoBRaLo convention: weights sum to number of active objectives, hence mean 1.
        w = probs * len(valid_groups)
        out = {g: 1.0 for g in self.group_names}
        for g, wi in zip(valid_groups, w):
            out[g] = float(wi)
        return out

    def _clamp_and_renormalize(self, weights: Mapping[str, float]) -> Dict[str, float]:
        arr = np.asarray([float(weights.get(g, 1.0)) for g in self.group_names], dtype=np.float64)
        arr = np.clip(arr, self.weight_min, self.weight_max)
        if self.renormalize_after_clamp:
            mean = float(np.mean(arr))
            if np.isfinite(mean) and mean > self.eps:
                arr = arr / mean
            arr = np.clip(arr, self.weight_min, self.weight_max)
            # One more light renormalization unless clipping prevents exact mean 1.
            mean = float(np.mean(arr))
            if np.isfinite(mean) and mean > self.eps:
                arr = arr / mean
        return {g: float(v) for g, v in zip(self.group_names, arr)}

    def update(self, current_losses: Mapping[str, float]) -> Dict[str, float]:
        """Update weights using epoch-mean group losses.

        The returned weights are intended for the next epoch. The first call
        only initializes reference losses and keeps uniform weights.
        """
        current = {g: self._clean_loss(current_losses.get(g, np.nan), self.eps) for g in self.group_names}
        # Fill missing/NaN values with previous or initial values so one temporarily missing group does not crash training.
        for g in self.group_names:
            if not np.isfinite(current[g]):
                if g in self.previous_losses:
                    current[g] = self.previous_losses[g]
                elif g in self.initial_losses:
                    current[g] = self.initial_losses[g]
                else:
                    current[g] = 1.0

        if not self.initial_losses:
            self.initial_losses = dict(current)
            self.previous_losses = dict(current)
            self.weights = {g: 1.0 for g in self.group_names}
            self.n_updates = 1
            return self.current_weights()

        lamb_hist0 = self._softmax_balancing(current, self.initial_losses)
        lamb_prev = self._softmax_balancing(current, self.previous_losses)
        # rho=1 means carry previous weights; rho=0 means random lookback to initial losses.
        rho = 1.0 if self.rng.random() < self.expected_rho else 0.0
        new_weights = {}
        for g in self.group_names:
            hist = rho * float(self.weights.get(g, 1.0)) + (1.0 - rho) * float(lamb_hist0.get(g, 1.0))
            wi = self.alpha_memory * hist + (1.0 - self.alpha_memory) * float(lamb_prev.get(g, 1.0))
            new_weights[g] = float(wi)
        self.weights = self._clamp_and_renormalize(new_weights)
        self.previous_losses = dict(current)
        self.n_updates += 1
        return self.current_weights()

    def state_dict(self) -> dict:
        return {
            "group_names": list(self.group_names),
            "alpha_memory": self.alpha_memory,
            "temperature": self.temperature,
            "expected_rho": self.expected_rho,
            "weight_min": self.weight_min,
            "weight_max": self.weight_max,
            "eps": self.eps,
            "renormalize_after_clamp": self.renormalize_after_clamp,
            "seed": self.seed,
            "weights": self.current_weights(),
            "initial_losses": dict(self.initial_losses),
            "previous_losses": dict(self.previous_losses),
            "n_updates": int(self.n_updates),
        }

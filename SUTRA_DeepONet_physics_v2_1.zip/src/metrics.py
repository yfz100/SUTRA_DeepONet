from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from .reference_data import CanonicalReferenceData
from .utils import ensure_dir, save_json


TARGET_SPECS = {
    "pressure_head": {
        "true_attr": "pressure_head",
        "pred_file": "pred_pressure_head_m.npy",
        "unit_suffix": "_m",
    },
    "concentration": {
        "true_attr": "concentration",
        "pred_file": "pred_concentration.npy",
        "unit_suffix": "",
    },
}


def metrics_1d(y_true: np.ndarray, y_pred: np.ndarray) -> dict[str, float]:
    y_true = np.asarray(y_true, dtype=np.float64).reshape(-1)
    y_pred = np.asarray(y_pred, dtype=np.float64).reshape(-1)
    if y_true.shape != y_pred.shape:
        raise ValueError(f"Metric arrays differ: {y_true.shape} vs {y_pred.shape}")
    if y_true.size == 0:
        raise ValueError("Cannot compute metrics on empty arrays")
    if not np.isfinite(y_true).all() or not np.isfinite(y_pred).all():
        raise ValueError("Metric arrays contain NaN/Inf")
    err = y_pred - y_true
    abs_err = np.abs(err)
    numerator = float(np.sum(err * err, dtype=np.float64))
    denominator = float(np.sum(y_true * y_true, dtype=np.float64))
    return {
        "rmse": float(np.sqrt(numerator / y_true.size)),
        "mae": float(np.mean(abs_err, dtype=np.float64)),
        "rl2e": float(np.sqrt(numerator / denominator)) if denominator > 0.0 else float("nan"),
        "bias": float(np.mean(err, dtype=np.float64)),
        "max_abs_error": float(np.max(abs_err)),
        "p95_abs_error": float(np.percentile(abs_err, 95.0)),
        "p99_abs_error": float(np.percentile(abs_err, 99.0)),
    }


def _metric_columns(prefix: str, values: dict[str, float]) -> dict[str, float]:
    unit = "_m" if prefix == "pressure_head" else ""
    out: dict[str, float] = {}
    for key, value in values.items():
        if key == "rl2e":
            out[f"{prefix}_rl2e"] = value
        else:
            out[f"{prefix}_{key}{unit}"] = value
    return out


@dataclass
class ReducibleMetricAccumulator:
    n: int = 0
    sum_sq_error: float = 0.0
    sum_abs_error: float = 0.0
    sum_error: float = 0.0
    sum_sq_true: float = 0.0
    max_abs_error: float = 0.0

    def update(self, y_true: np.ndarray, y_pred: np.ndarray) -> None:
        yt = np.asarray(y_true, dtype=np.float64).reshape(-1)
        yp = np.asarray(y_pred, dtype=np.float64).reshape(-1)
        err = yp - yt
        abs_err = np.abs(err)
        self.n += int(yt.size)
        self.sum_sq_error += float(np.sum(err * err, dtype=np.float64))
        self.sum_abs_error += float(np.sum(abs_err, dtype=np.float64))
        self.sum_error += float(np.sum(err, dtype=np.float64))
        self.sum_sq_true += float(np.sum(yt * yt, dtype=np.float64))
        self.max_abs_error = max(self.max_abs_error, float(np.max(abs_err)))

    def finalize(self) -> dict[str, float]:
        if self.n == 0:
            return {k: float("nan") for k in ["rmse", "mae", "rl2e", "bias", "max_abs_error"]}
        return {
            "rmse": float(np.sqrt(self.sum_sq_error / self.n)),
            "mae": float(self.sum_abs_error / self.n),
            "rl2e": float(np.sqrt(self.sum_sq_error / self.sum_sq_true)) if self.sum_sq_true > 0 else float("nan"),
            "bias": float(self.sum_error / self.n),
            "max_abs_error": float(self.max_abs_error),
        }


def _load_prediction_arrays(export_dir: Path, data: CanonicalReferenceData) -> tuple[np.ndarray, np.ndarray]:
    psi = np.load(export_dir / "pred_pressure_head_m.npy", mmap_mode="r")
    con = np.load(export_dir / "pred_concentration.npy", mmap_mode="r")
    expected = (data.n_case, data.n_time, data.n_node)
    if psi.shape != expected or con.shape != expected:
        raise ValueError(f"Prediction shape mismatch: psi={psi.shape}, C={con.shape}, expected={expected}")
    return psi, con


def evaluate_prediction_export(
    data: CanonicalReferenceData,
    export_dir: str | Path,
    metrics_dir: str | Path,
) -> dict[str, Any]:
    export_dir = Path(export_dir)
    metrics_dir = ensure_dir(metrics_dir)
    pred_psi, pred_con = _load_prediction_arrays(export_dir, data)

    case_rows: list[dict[str, Any]] = []
    time_rows: list[dict[str, Any]] = []

    for ci in range(data.n_case):
        meta = data.case_metadata.iloc[ci]
        base = {
            "case_index": int(ci),
            "manifest_row_index": int(meta["manifest_row_index"]),
            "case_id": str(meta["case_id"]),
            "amplitude_m": float(meta["amplitude_m"]),
            "h_land_m": float(meta["h_land_m"]),
            "split": str(meta["split"]),
            "design_regime": str(meta["design_regime"]),
            "n_points": int(data.n_time * data.n_node),
        }
        row = dict(base)
        row.update(_metric_columns("pressure_head", metrics_1d(data.pressure_head[ci], pred_psi[ci])))
        row.update(_metric_columns("concentration", metrics_1d(data.concentration[ci], pred_con[ci])))
        case_rows.append(row)

        for ti in range(data.n_time):
            tr = {
                "case_index": int(ci),
                "case_id": str(meta["case_id"]),
                "amplitude_m": float(meta["amplitude_m"]),
                "h_land_m": float(meta["h_land_m"]),
                "split": str(meta["split"]),
                "design_regime": str(meta["design_regime"]),
                "time_index": int(ti),
                "time_s": float(data.times[ti]),
                "time_h": float(data.times[ti] / 3600.0),
                "n_nodes": int(data.n_node),
            }
            tr.update(_metric_columns("pressure_head", metrics_1d(data.pressure_head[ci, ti], pred_psi[ci, ti])))
            tr.update(_metric_columns("concentration", metrics_1d(data.concentration[ci, ti], pred_con[ci, ti])))
            time_rows.append(tr)

    case_df = pd.DataFrame(case_rows)
    time_df = pd.DataFrame(time_rows)
    case_df.to_csv(metrics_dir / "metrics_by_case.csv", index=False, encoding="utf-8-sig")
    time_df.to_csv(metrics_dir / "metrics_by_case_time.csv", index=False, encoding="utf-8-sig")

    group_names = ["train", "validation", "test"] if data.library_group == "source_range" else ["ood"]
    pooled_rows: list[dict[str, Any]] = []
    for split in group_names:
        indices = data.get_split_indices(split)
        psi_acc = ReducibleMetricAccumulator()
        con_acc = ReducibleMetricAccumulator()
        for ci in indices:
            psi_acc.update(data.pressure_head[int(ci)], pred_psi[int(ci)])
            con_acc.update(data.concentration[int(ci)], pred_con[int(ci)])
        prow: dict[str, Any] = {
            "split": split,
            "n_cases": int(len(indices)),
            "n_points": int(len(indices) * data.n_time * data.n_node),
            "percentiles_note": "P95/P99 are intentionally not pooled; exact percentiles are reported per case and summarized across cases.",
        }
        prow.update(_metric_columns("pressure_head", psi_acc.finalize()))
        prow.update(_metric_columns("concentration", con_acc.finalize()))
        pooled_rows.append(prow)
    pooled_df = pd.DataFrame(pooled_rows)
    pooled_name = "metrics_pooled_by_split.csv" if data.library_group == "source_range" else "metrics_pooled_all.csv"
    pooled_df.to_csv(metrics_dir / pooled_name, index=False, encoding="utf-8-sig")

    metric_cols = [c for c in case_df.columns if c.startswith("pressure_head_") or c.startswith("concentration_")]
    summary_rows: list[dict[str, Any]] = []
    for split in group_names:
        group = case_df.loc[case_df["split"] == split]
        for metric in metric_cols:
            vals = group[metric].to_numpy(dtype=float)
            finite = vals[np.isfinite(vals)]
            summary_rows.append({
                "split": split,
                "metric": metric,
                "n_cases": int(len(group)),
                "n_finite": int(len(finite)),
                "mean": float(np.mean(finite)) if len(finite) else float("nan"),
                "std": float(np.std(finite, ddof=0)) if len(finite) else float("nan"),
                "min": float(np.min(finite)) if len(finite) else float("nan"),
                "max": float(np.max(finite)) if len(finite) else float("nan"),
            })
    summary_df = pd.DataFrame(summary_rows)
    summary_name = "metrics_case_summary_by_split.csv" if data.library_group == "source_range" else "metrics_case_summary_all.csv"
    summary_df.to_csv(metrics_dir / summary_name, index=False, encoding="utf-8-sig")

    summary = {
        "library_group": data.library_group,
        "n_case_rows": int(len(case_df)),
        "n_case_time_rows": int(len(time_df)),
        "pooled_groups": group_names,
        "metric_reduction_dtype": "float64",
        "rl2e_formula": "sqrt(sum((pred-true)^2) / sum(true^2)); NaN when denominator is zero",
        "passed": True,
    }
    save_json(summary, metrics_dir / "metrics_metadata.json")
    return summary

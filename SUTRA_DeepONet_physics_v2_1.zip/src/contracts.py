from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from .reference_data import CanonicalReferenceData
from .utils import save_json, sha256_file


EXPECTED_SCHEMA_VERSION = "2.1"
EXPECTED_BRANCH_COLUMNS = ["amplitude_m", "h_land_m"]
EXPECTED_AXIS_ORDER = ["case", "time", "node"]
EXPECTED_SOURCE_SPLITS = {"train": 120, "validation": 24, "test": 24}


def _require(condition: bool, message: str, failures: list[str]) -> None:
    if not condition:
        failures.append(message)


def _is_finite_memmap(arr: np.ndarray, case_chunk: int = 8) -> bool:
    if arr.ndim < 1:
        return bool(np.isfinite(np.asarray(arr)).all())
    for start in range(0, arr.shape[0], case_chunk):
        block = np.asarray(arr[start : start + case_chunk])
        if not np.isfinite(block).all():
            return False
    return True


def _validate_metadata_alignment(data: CanonicalReferenceData, failures: list[str]) -> None:
    meta = data.case_metadata
    required = [
        "case_index", "manifest_row_index", "case_id", "amplitude_m", "h_land_m",
        "canonical_library_group", "split", "design_regime",
    ]
    missing = [c for c in required if c not in meta.columns]
    _require(not missing, f"case_metadata missing columns: {missing}", failures)
    if missing:
        return

    _require(len(meta) == data.n_case, f"case_metadata rows {len(meta)} != n_case {data.n_case}", failures)
    _require(np.array_equal(meta["case_index"].to_numpy(), np.arange(data.n_case)), "case_index must be exactly 0..N-1", failures)
    _require(meta["case_id"].nunique(dropna=False) == data.n_case, "case_id values are not unique", failures)
    _require(meta["manifest_row_index"].nunique(dropna=False) == data.n_case, "manifest_row_index values are not unique", failures)
    pairs = meta[["amplitude_m", "h_land_m"]].round(12)
    _require(len(pairs.drop_duplicates()) == data.n_case, "(A,H_land) pairs are not unique", failures)
    if "nod_sha256" in meta.columns:
        hashes = meta["nod_sha256"]
        _require(not hashes.isna().any(), "nod_sha256 contains missing values", failures)
        _require(hashes.astype(str).nunique(dropna=False) == data.n_case, "nod_sha256 values are not unique", failures)

    if data.branch.shape == (data.n_case, 2):
        a = meta["amplitude_m"].to_numpy(dtype=float)
        h = meta["h_land_m"].to_numpy(dtype=float)
        _require(np.allclose(np.asarray(data.branch[:, 0], dtype=float), a, rtol=0.0, atol=1e-7), "branch[:,0] does not match amplitude_m", failures)
        _require(np.allclose(np.asarray(data.branch[:, 1], dtype=float), h, rtol=0.0, atol=1e-7), "branch[:,1] does not match h_land_m", failures)

    groups = set(meta["canonical_library_group"].astype(str))
    _require(groups == {data.library_group}, f"metadata library groups {groups} != dataset group {data.library_group}", failures)


def _validate_manifest_alignment(data: CanonicalReferenceData, manifest_path: Path, failures: list[str]) -> dict[str, Any]:
    if not manifest_path.exists():
        failures.append(f"Manifest not found: {manifest_path}")
        return {}
    manifest = pd.read_csv(manifest_path)
    group_col = "library_group" if "library_group" in manifest.columns else "canonical_library_group"
    if group_col not in manifest.columns:
        failures.append("Manifest has no library_group/canonical_library_group column")
        return {}
    selected = manifest.loc[manifest[group_col].astype(str) == data.library_group].copy()
    selected = selected.reset_index(drop=False).rename(columns={"index": "_manifest_file_row"})
    if len(selected) != data.n_case:
        failures.append(f"Manifest group {data.library_group} has {len(selected)} rows, expected {data.n_case}")
        return {"manifest_group_rows": int(len(selected))}

    meta = data.case_metadata.reset_index(drop=True)
    compare_cols = ["case_id", "amplitude_m", "h_land_m", "split", "design_regime"]
    for col in compare_cols:
        if col not in selected.columns or col not in meta.columns:
            failures.append(f"Cannot compare manifest column {col}")
            continue
        if col in {"amplitude_m", "h_land_m"}:
            ok = np.allclose(selected[col].to_numpy(float), meta[col].to_numpy(float), rtol=0.0, atol=1e-12)
        else:
            ok = np.array_equal(selected[col].astype(str).to_numpy(), meta[col].astype(str).to_numpy())
        if not ok:
            failures.append(f"Manifest/case_metadata mismatch in {col}")

    if "manifest_row_index" in meta.columns:
        # Formal manifest v2.1 does not carry an explicit manifest_row_index column;
        # case_metadata stores the original zero-based row index in the full manifest.
        if "manifest_row_index" in selected.columns:
            expected_row = selected["manifest_row_index"].to_numpy()
        else:
            expected_row = selected["_manifest_file_row"].to_numpy()
        ok = np.array_equal(expected_row, meta["manifest_row_index"].to_numpy())
        if not ok:
            failures.append("Manifest/case_metadata mismatch in manifest_row_index")
    return {
        "manifest_group_rows": int(len(selected)),
        "manifest_sha256": sha256_file(manifest_path),
    }


def validate_library_contract(
    data: CanonicalReferenceData,
    expected_group: str,
    manifest_path: str | Path,
    expected_n_case: int,
) -> dict[str, Any]:
    failures: list[str] = []
    dm = data.dataset_metadata
    pv = data.processed_validation

    _require(data.library_group == expected_group, f"library_group={data.library_group!r}, expected {expected_group!r}", failures)
    _require(str(dm.get("schema_version")) == EXPECTED_SCHEMA_VERSION, f"schema_version={dm.get('schema_version')} != 2.1", failures)
    _require(int(data.n_case) == expected_n_case, f"n_case={data.n_case}, expected {expected_n_case}", failures)
    _require(tuple(data.branch.shape) == (expected_n_case, 2), f"branch shape {data.branch.shape} invalid", failures)
    _require(tuple(data.coords.shape) == (3534, 2), f"coords shape {data.coords.shape} invalid", failures)
    _require(tuple(data.times.shape) == (73,), f"times shape {data.times.shape} invalid", failures)
    _require(tuple(data.pressure_head.shape) == (expected_n_case, 73, 3534), f"pressure_head shape {data.pressure_head.shape} invalid", failures)
    _require(tuple(data.concentration.shape) == (expected_n_case, 73, 3534), f"concentration shape {data.concentration.shape} invalid", failures)

    _require(str(data.branch.dtype) == "float32", f"branch dtype {data.branch.dtype} != float32", failures)
    _require(str(data.coords.dtype) == "float64", f"coords dtype {data.coords.dtype} != float64", failures)
    _require(str(data.times.dtype) == "float64", f"times dtype {data.times.dtype} != float64", failures)
    _require(str(data.pressure_head.dtype) == "float32", f"pressure_head dtype {data.pressure_head.dtype} != float32", failures)
    _require(str(data.concentration.dtype) == "float32", f"concentration dtype {data.concentration.dtype} != float32", failures)

    _require(dm.get("branch_columns") == EXPECTED_BRANCH_COLUMNS, f"branch_columns={dm.get('branch_columns')} invalid", failures)
    _require(dm.get("field_axis_order") == EXPECTED_AXIS_ORDER, f"field_axis_order={dm.get('field_axis_order')} invalid", failures)
    _require(dm.get("pressure_head_definition") == "pressure_pa / 9810.0", "pressure_head_definition is not pressure_pa / 9810.0", failures)
    _require(bool(dm.get("concentration_clipping", True)) is False, "concentration_clipping must be false", failures)
    _require(bool(dm.get("normalization_included", True)) is False, "canonical data must not include normalization", failures)

    canonical_times = np.arange(73, dtype=np.float64) * 3600.0
    _require(np.array_equal(np.asarray(data.times), canonical_times), "times_s.npy is not exactly 0..259200 by 3600 s", failures)
    _require(bool(pv.get("passed", False)), f"processed_validation did not pass: {pv.get('failures')}", failures)

    _validate_metadata_alignment(data, failures)
    manifest_info = _validate_manifest_alignment(data, Path(manifest_path), failures)
    expected_manifest_hash = str(dm.get("manifest_sha256", ""))
    actual_manifest_hash = str(manifest_info.get("manifest_sha256", ""))
    _require(bool(expected_manifest_hash) and expected_manifest_hash == actual_manifest_hash,
             f"dataset_metadata manifest_sha256 {expected_manifest_hash} != actual {actual_manifest_hash}", failures)

    if expected_group == "source_range":
        actual = {k: int(len(v)) for k, v in data.split_indices.items()}
        _require(actual == EXPECTED_SOURCE_SPLITS, f"source split counts {actual} != {EXPECTED_SOURCE_SPLITS}", failures)
        sets = [set(data.get_split_indices(k).tolist()) for k in ["train", "validation", "test"]]
        _require(not (sets[0] & sets[1] or sets[0] & sets[2] or sets[1] & sets[2]), "train/validation/test overlap", failures)
        _require(set.union(*sets) == set(range(data.n_case)), "source splits do not cover all cases exactly", failures)
        expected_a = np.round(np.arange(0.05, 0.6001, 0.05), 10)
        expected_h = np.array([2.50,2.55,2.60,2.65,2.70,2.75,2.80,2.90,3.00,3.10,3.20,3.30,3.40,3.50])
        actual_a = np.sort(data.case_metadata["amplitude_m"].unique().astype(float))
        actual_h = np.sort(data.case_metadata["h_land_m"].unique().astype(float))
        _require(np.allclose(actual_a, expected_a, rtol=0, atol=1e-12), f"source A levels invalid: {actual_a.tolist()}", failures)
        _require(np.allclose(actual_h, expected_h, rtol=0, atol=1e-12), f"source H levels invalid: {actual_h.tolist()}", failures)
        train_meta = data.case_metadata.iloc[data.get_split_indices("train")]
        _require(len(np.unique(train_meta["amplitude_m"].to_numpy(float))) == 12, "training split does not cover all 12 A levels", failures)
        _require(len(np.unique(train_meta["h_land_m"].to_numpy(float))) == 14, "training split does not cover all 14 H levels", failures)
    elif expected_group == "higher_amplitude":
        actual = {k: int(len(v)) for k, v in data.split_indices.items()}
        _require(actual == {"ood": 18}, f"OOD split counts {actual} != {{'ood':18}}", failures)
        expected_a = np.array([0.70,0.80,0.90,1.00,1.10,1.20])
        expected_h = np.array([2.50,2.70,3.50])
        actual_a = np.sort(data.case_metadata["amplitude_m"].unique().astype(float))
        actual_h = np.sort(data.case_metadata["h_land_m"].unique().astype(float))
        _require(np.allclose(actual_a, expected_a, rtol=0, atol=1e-12), f"OOD A levels invalid: {actual_a.tolist()}", failures)
        _require(np.allclose(actual_h, expected_h, rtol=0, atol=1e-12), f"OOD H levels invalid: {actual_h.tolist()}", failures)

    _require(_is_finite_memmap(data.pressure_head), "pressure_head contains NaN/Inf", failures)
    _require(_is_finite_memmap(data.concentration), "concentration contains NaN/Inf", failures)

    return {
        "library_group": expected_group,
        "passed": not failures,
        "failures": failures,
        "description": data.describe(),
        **manifest_info,
    }


def validate_cross_library_alignment(source: CanonicalReferenceData, ood: CanonicalReferenceData) -> dict[str, Any]:
    failures: list[str] = []
    _require(source.n_node == ood.n_node, "source/OOD n_node mismatch", failures)
    _require(source.n_time == ood.n_time, "source/OOD n_time mismatch", failures)
    _require(np.array_equal(np.asarray(source.times), np.asarray(ood.times)), "source/OOD times differ", failures)
    _require(np.allclose(np.asarray(source.coords), np.asarray(ood.coords), rtol=0.0, atol=1e-12), "source/OOD coords differ", failures)
    _require(source.dataset_metadata.get("schema_version") == ood.dataset_metadata.get("schema_version"), "source/OOD schema versions differ", failures)
    _require(source.dataset_metadata.get("pressure_head_definition") == ood.dataset_metadata.get("pressure_head_definition"), "source/OOD pressure-head definitions differ", failures)
    _require(source.dataset_metadata.get("concentration_definition") == ood.dataset_metadata.get("concentration_definition"), "source/OOD concentration definitions differ", failures)
    sm = source.dataset_metadata.get("manifest_sha256")
    om = ood.dataset_metadata.get("manifest_sha256")
    _require(bool(sm) and sm == om, f"source/OOD manifest hashes differ: {sm} vs {om}", failures)
    return {"passed": not failures, "failures": failures}


def run_full_data_contract(
    source_dir: str | Path,
    ood_dir: str | Path,
    manifest_path: str | Path,
    report_path: str | Path | None = None,
) -> dict[str, Any]:
    source = CanonicalReferenceData(source_dir)
    ood = CanonicalReferenceData(ood_dir)
    source_report = validate_library_contract(source, "source_range", manifest_path, 168)
    ood_report = validate_library_contract(ood, "higher_amplitude", manifest_path, 18)
    cross_report = validate_cross_library_alignment(source, ood)
    failures = (
        [f"source: {x}" for x in source_report["failures"]]
        + [f"ood: {x}" for x in ood_report["failures"]]
        + [f"cross: {x}" for x in cross_report["failures"]]
    )
    report = {
        "passed": not failures,
        "failures": failures,
        "source": source_report,
        "higher_amplitude": ood_report,
        "cross_library": cross_report,
    }
    if report_path is not None:
        save_json(report, report_path)
    if failures:
        raise ValueError("Canonical data contract failed:\n- " + "\n- ".join(failures))
    return report

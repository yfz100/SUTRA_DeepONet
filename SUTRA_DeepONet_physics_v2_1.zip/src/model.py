from __future__ import annotations

from typing import Iterable

import torch
from torch import nn


def make_activation(name: str) -> nn.Module:
    key = name.lower()
    if key == "tanh":
        return nn.Tanh()
    if key == "relu":
        return nn.ReLU()
    if key == "gelu":
        return nn.GELU()
    if key in {"silu", "swish"}:
        return nn.SiLU()
    raise ValueError(f"Unknown activation: {name}")


class MLP(nn.Module):
    def __init__(
        self,
        in_dim: int,
        hidden: Iterable[int],
        out_dim: int,
        activation: str = "silu",
        dropout: float = 0.0,
    ) -> None:
        super().__init__()
        dims = [int(in_dim), *[int(v) for v in hidden]]
        layers: list[nn.Module] = []
        for a, b in zip(dims[:-1], dims[1:]):
            layers.append(nn.Linear(a, b))
            layers.append(make_activation(activation))
            if float(dropout) > 0:
                layers.append(nn.Dropout(float(dropout)))
        layers.append(nn.Linear(dims[-1], int(out_dim)))
        self.net = nn.Sequential(*layers)
        self.reset_parameters()

    def reset_parameters(self) -> None:
        for module in self.modules():
            if isinstance(module, nn.Linear):
                nn.init.xavier_uniform_(module.weight)
                nn.init.zeros_(module.bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class MultiOutputDeepONet(nn.Module):
    """Two-output DeepONet for the formal operator family.

    Branch input order: [tidal amplitude A, inland head H_land].
    Trunk input order: [x/x_scale, z/z_scale, t/t_scale,
                        sin(wt), cos(wt), sin(2wt), cos(2wt)].
    Output order in normalized space: [pressure head, concentration].

    Output-specific latent blocks are retained from the previous pure-supervised model:
      B(branch) -> (output_dim, latent_dim)
      T(trunk)  -> (output_dim, latent_dim)
      y_o = sum_k B[o,k] * T[o,k] + bias[o]
    """

    def __init__(
        self,
        branch_dim: int = 2,
        trunk_dim: int = 7,
        latent_dim: int = 256,
        output_dim: int = 2,
        branch_hidden: Iterable[int] = (128, 128, 128),
        trunk_hidden: Iterable[int] = (256, 256, 256, 256),
        activation: str = "silu",
        dropout: float = 0.0,
    ) -> None:
        super().__init__()
        self.branch_dim = int(branch_dim)
        self.trunk_dim = int(trunk_dim)
        self.latent_dim = int(latent_dim)
        self.output_dim = int(output_dim)
        out_latent = self.output_dim * self.latent_dim
        self.branch_net = MLP(self.branch_dim, branch_hidden, out_latent, activation, dropout)
        self.trunk_net = MLP(self.trunk_dim, trunk_hidden, out_latent, activation, dropout)
        self.bias = nn.Parameter(torch.zeros(self.output_dim))

    def encode_branch(self, branch: torch.Tensor) -> torch.Tensor:
        return self.branch_net(branch).view(-1, self.output_dim, self.latent_dim)

    def encode_trunk(self, trunk: torch.Tensor) -> torch.Tensor:
        return self.trunk_net(trunk).view(-1, self.output_dim, self.latent_dim)

    def combine_latents(self, branch_latent: torch.Tensor, trunk_latent: torch.Tensor) -> torch.Tensor:
        # branch_latent can have batch=1 and broadcasts across trunk batches during inference.
        return torch.sum(branch_latent * trunk_latent, dim=-1) + self.bias

    def forward(self, branch: torch.Tensor, trunk: torch.Tensor) -> torch.Tensor:
        return self.combine_latents(self.encode_branch(branch), self.encode_trunk(trunk))


def build_model(config: dict) -> MultiOutputDeepONet:
    cfg = config["model"]
    return MultiOutputDeepONet(
        branch_dim=int(cfg.get("branch_dim", 2)),
        trunk_dim=int(cfg.get("trunk_dim", 7)),
        latent_dim=int(cfg.get("latent_dim", 256)),
        output_dim=int(cfg.get("output_dim", 2)),
        branch_hidden=cfg.get("branch_hidden", [128, 128, 128]),
        trunk_hidden=cfg.get("trunk_hidden", [256, 256, 256, 256]),
        activation=str(cfg.get("activation", "silu")),
        dropout=float(cfg.get("dropout", 0.0)),
    )

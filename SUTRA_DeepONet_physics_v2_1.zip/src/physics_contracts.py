from __future__ import annotations

from typing import Any

import numpy as np

from .physics_engine import DEFAULT_GROUPS, ALL_TERMS, batch_sizes_for_mode, groups_from_config
from .physics_sampling import detect_boundaries
from .reference_data import CanonicalReferenceData


def validate_physics_config(config: dict[str, Any]) -> dict[str, Any]:
    failures: list[str] = []
    mode = str(config.get("training", {}).get("mode", ""))
    if mode not in {"hybrid", "physics_only"}:
        failures.append(f"invalid training.mode={mode!r}")

    rel = config.get("physics_regularization", {}).get("relobralo", {})
    if not bool(rel.get("enabled", False)):
        failures.append("ReLoBRaLo must be enabled")
    if str(rel.get("update_level")) != "epoch_mean":
        failures.append("ReLoBRaLo update_level must be epoch_mean")
    if abs(float(rel.get("alpha_memory", -1)) - 0.95) > 1e-12:
        failures.append("ReLoBRaLo alpha_memory changed from frozen 0.95")
    if abs(float(rel.get("temperature", -1)) - 0.2) > 1e-12:
        failures.append("ReLoBRaLo temperature changed from frozen 0.2")
    if abs(float(rel.get("expected_rho", -1)) - 0.99) > 1e-12:
        failures.append("ReLoBRaLo expected_rho changed from frozen 0.99")
    if abs(float(rel.get("group_weight_min", -1)) - 0.2) > 1e-12 or abs(float(rel.get("group_weight_max", -1)) - 5.0) > 1e-12:
        failures.append("ReLoBRaLo clamp changed from frozen [0.2,5.0]")
    if int(rel.get("ramp_epochs", -1)) != 200:
        failures.append("Hybrid alpha_phys ramp must remain 200 epochs")
    if mode == "hybrid":
        alpha = float(rel.get("alpha_phys", np.nan))
        if alpha not in {0.1, 0.5}:
            failures.append(f"formal Hybrid alpha_phys must be 0.1 or 0.5, got {alpha}")
        if float(rel.get("data_anchor_weight", np.nan)) != 1.0:
            failures.append("Hybrid data anchor weight must be 1.0")
    elif rel.get("alpha_phys") is not None:
        failures.append("Physics-only must not use alpha_phys")

    try:
        groups = groups_from_config(config)
        if groups != DEFAULT_GROUPS:
            failures.append("ReLoBRaLo six-group membership differs from frozen v2.1 design")
    except Exception as exc:
        failures.append(f"physics groups invalid: {exc}")

    try:
        sizes = batch_sizes_for_mode(config, mode)
        if set(sizes) != set(ALL_TERMS):
            failures.append("physics batch-size term set incomplete")
    except Exception as exc:
        failures.append(f"physics batch sizes invalid: {exc}")

    cp = config.get("physics_regularization", {}).get("common_physics", {})
    expected = {
        "gamma_ref_pa_per_m": 9810.0,
        "gamma_sea_pa_per_m": 10055.1519,
        "rho0_kg_m3": 1000.0,
        "drho_dC_kg_m3": 700.0,
        "permeability_m2": 1.0e-10,
        "porosity": 0.46,
        "matrix_compressibility_per_pa": 1.0e-8,
        "fluid_compressibility_per_pa": 0.0,
        "swres": 0.30,
        "aa_inv_pa": 5.0e-5,
        "vg_n": 2.0,
        "alpha_l_m": 2.0e-3,
        "alpha_t_m": 2.0e-4,
        "sea_concentration": 0.0357,
        "land_concentration": 0.0,
    }
    for k, v in expected.items():
        if not np.isclose(float(cp.get(k, np.nan)), v, rtol=0.0, atol=max(abs(v) * 1e-12, 1e-15)):
            failures.append(f"formal physics constant {k} changed: {cp.get(k)} != {v}")
    if bool(cp.get("density_clip_enabled", True)):
        failures.append("density clipping must remain disabled for SUTRA-consistent linear density law")

    return {"passed": not failures, "failures": failures, "training_mode": mode}


def audit_initial_conditions(source: CanonicalReferenceData, ood: CanonicalReferenceData | None = None) -> dict[str, Any]:
    failures: list[str] = []
    c0 = np.asarray(source.concentration[:, 0, :], dtype=np.float64)
    max_abs_c0 = float(np.max(np.abs(c0)))
    if max_abs_c0 > 1.0e-7:
        failures.append(f"source t=0 concentration is not zero; max_abs={max_abs_c0}")

    max_same_h_diff = 0.0
    h_values = np.asarray(source.case_metadata["h_land_m"], dtype=float)
    for h in sorted(np.unique(h_values)):
        ids = np.where(np.isclose(h_values, h, rtol=0.0, atol=1e-12))[0]
        ref = np.asarray(source.pressure_head[int(ids[0]), 0], dtype=np.float64)
        for ci in ids[1:]:
            d = float(np.max(np.abs(np.asarray(source.pressure_head[int(ci), 0], dtype=np.float64) - ref)))
            max_same_h_diff = max(max_same_h_diff, d)
    if max_same_h_diff > 5.0e-6:
        failures.append(f"t=0 pressure is not amplitude-invariant within H groups; max_abs_diff={max_same_h_diff}")

    cross_ood_max = None
    if ood is not None:
        c0o = np.asarray(ood.concentration[:, 0, :], dtype=np.float64)
        if float(np.max(np.abs(c0o))) > 1.0e-7:
            failures.append("OOD t=0 concentration is not zero")
        cross_ood_max = 0.0
        source_h = np.asarray(source.case_metadata["h_land_m"], dtype=float)
        ood_h = np.asarray(ood.case_metadata["h_land_m"], dtype=float)
        for oi, h in enumerate(ood_h):
            matches = np.where(np.isclose(source_h, h, rtol=0.0, atol=1e-12))[0]
            if len(matches) == 0:
                failures.append(f"OOD H={h} has no source-domain IC reference")
                continue
            ref = np.asarray(source.pressure_head[int(matches[0]), 0], dtype=np.float64)
            d = float(np.max(np.abs(np.asarray(ood.pressure_head[int(oi), 0], dtype=np.float64) - ref)))
            cross_ood_max = max(cross_ood_max, d)
        if cross_ood_max > 5.0e-6:
            failures.append(f"source/OOD t=0 pressure mismatch for shared H; max_abs_diff={cross_ood_max}")

    return {
        "passed": not failures,
        "failures": failures,
        "source_t0_concentration_max_abs": max_abs_c0,
        "source_t0_pressure_max_abs_difference_within_same_H": max_same_h_diff,
        "source_ood_t0_pressure_max_abs_difference_at_shared_H": cross_ood_max,
        "interpretation": "t=0 pressure is an H-dependent prescribed COLD initial state and must be amplitude-invariant for fixed H",
    }


def audit_boundaries(data: CanonicalReferenceData, config: dict[str, Any]) -> dict[str, Any]:
    b = detect_boundaries(np.asarray(data.coords), config["physics_regularization"]["boundary_detection"])
    rep = b.describe(np.asarray(data.coords))
    failures: list[str] = []
    # Canonical pressure-boundary counts are known exactly from the formal geometry.
    if len(b.land_nodes) != 41:
        failures.append(f"land boundary count={len(b.land_nodes)} != 41")
    if len(b.sea_nodes) != 83:
        failures.append(f"sea boundary count={len(b.sea_nodes)} != 83")
    if np.intersect1d(b.bottom_nodes, np.union1d(b.land_nodes, b.sea_nodes)).size:
        failures.append("bottom no-flux set overlaps pressure-boundary nodes")
    if np.intersect1d(b.top_nodes, np.union1d(b.land_nodes, b.sea_nodes)).size:
        failures.append("top no-flux set overlaps pressure-boundary nodes")
    return {"passed": not failures, "failures": failures, **rep}

from __future__ import annotations

import numpy as np

from .normalization import Normalizer
from .reference_data import CanonicalReferenceData


def build_trunk_features(
    data: CanonicalReferenceData,
    normalizer: Normalizer,
    tidal_period_s: float,
) -> np.ndarray:
    """Return normalized 7-D trunk features with shape (time,node,7)."""
    times = np.asarray(data.times, dtype=np.float64)
    coords = np.asarray(data.coords, dtype=np.float64)
    omega = 2.0 * np.pi / float(tidal_period_s)

    out = np.empty((data.n_time, data.n_node, 7), dtype=np.float32)
    out[..., 0] = (coords[:, 0] / normalizer.x_scale_m)[None, :]
    out[..., 1] = (coords[:, 1] / normalizer.z_scale_m)[None, :]
    out[..., 2] = (times / normalizer.t_scale_s)[:, None]

    phase = omega * times
    out[..., 3] = np.sin(phase)[:, None]
    out[..., 4] = np.cos(phase)[:, None]
    out[..., 5] = np.sin(2.0 * phase)[:, None]
    out[..., 6] = np.cos(2.0 * phase)[:, None]
    return out

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np

from .features import build_trunk_features
from .normalization import Normalizer
from .reference_data import CanonicalReferenceData


@dataclass
class SampleBatch:
    branch: np.ndarray
    trunk: np.ndarray
    target: np.ndarray


class UniformTripletBatchSampler:
    """Vectorized uniform random sampling of (case,time,node) triplets."""

    def __init__(
        self,
        data: CanonicalReferenceData,
        normalizer: Normalizer,
        trunk_all: np.ndarray,
        split: str,
        seed: int,
    ) -> None:
        self.data = data
        self.normalizer = normalizer
        self.trunk_all = trunk_all
        self.case_indices = data.get_split_indices(split).astype(np.int64)
        if len(self.case_indices) == 0:
            raise ValueError(f"Split {split!r} has no cases")
        self.seed = int(seed)
        self.branch_norm = normalizer.branch_to_norm(np.asarray(data.branch))

    def batch(self, epoch: int, batch_number: int, size: int) -> SampleBatch:
        # SeedSequence avoids accidental collisions across epochs/batches.
        ss = np.random.SeedSequence([self.seed, int(epoch), int(batch_number)])
        rng = np.random.default_rng(ss)
        ci = rng.choice(self.case_indices, size=int(size), replace=True)
        ti = rng.integers(0, self.data.n_time, size=int(size), endpoint=False)
        ni = rng.integers(0, self.data.n_node, size=int(size), endpoint=False)
        branch = self.branch_norm[ci]
        trunk = self.trunk_all[ti, ni]
        raw = self.data.get_target_batch(ci, ti, ni)
        target = self.normalizer.target_to_norm(raw)
        return SampleBatch(
            branch=np.asarray(branch, dtype=np.float32),
            trunk=np.asarray(trunk, dtype=np.float32),
            target=np.asarray(target, dtype=np.float32),
        )


def create_fixed_validation_indices(
    data: CanonicalReferenceData,
    points_per_case: int,
    seed: int,
    path: str | Path,
    overwrite: bool = False,
) -> dict[str, np.ndarray]:
    path = Path(path)
    if path.exists() and not overwrite:
        loaded = dict(np.load(path))
        validate_fixed_validation_indices(data, loaded, points_per_case)
        return loaded

    case_indices = data.get_split_indices("validation")
    total_per_case = data.n_time * data.n_node
    if points_per_case > total_per_case:
        raise ValueError(f"points_per_case={points_per_case} exceeds {total_per_case}")

    all_ci: list[np.ndarray] = []
    all_ti: list[np.ndarray] = []
    all_ni: list[np.ndarray] = []
    rng = np.random.default_rng(int(seed))
    for ci in case_indices:
        flat = rng.choice(total_per_case, size=int(points_per_case), replace=False)
        ti = flat // data.n_node
        ni = flat % data.n_node
        all_ci.append(np.full(points_per_case, int(ci), dtype=np.int64))
        all_ti.append(ti.astype(np.int64))
        all_ni.append(ni.astype(np.int64))

    result = {
        "case_index": np.concatenate(all_ci),
        "time_index": np.concatenate(all_ti),
        "node_index": np.concatenate(all_ni),
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(path, **result)
    validate_fixed_validation_indices(data, result, points_per_case)
    return result


def validate_fixed_validation_indices(
    data: CanonicalReferenceData,
    sample: dict[str, np.ndarray],
    points_per_case: int,
) -> None:
    for key in ["case_index", "time_index", "node_index"]:
        if key not in sample:
            raise ValueError(f"Validation sample missing {key}")
    ci = np.asarray(sample["case_index"], dtype=np.int64)
    ti = np.asarray(sample["time_index"], dtype=np.int64)
    ni = np.asarray(sample["node_index"], dtype=np.int64)
    if not (len(ci) == len(ti) == len(ni)):
        raise ValueError("Validation index arrays differ in length")
    expected_cases = data.get_split_indices("validation")
    if len(ci) != len(expected_cases) * int(points_per_case):
        raise ValueError("Validation sample total size is incorrect")
    if not set(ci.tolist()).issubset(set(expected_cases.tolist())):
        raise ValueError("Validation sample contains non-validation cases")
    unique, counts = np.unique(ci, return_counts=True)
    if not np.array_equal(unique, expected_cases):
        raise ValueError("Validation sample does not cover every validation case")
    if not np.all(counts == int(points_per_case)):
        raise ValueError("Validation cases do not have equal sample counts")
    if np.any(ti < 0) or np.any(ti >= data.n_time) or np.any(ni < 0) or np.any(ni >= data.n_node):
        raise ValueError("Validation time/node indices out of bounds")
    # Within each case samples must be unique in flattened (time,node) space.
    for case in expected_cases:
        mask = ci == case
        flat = ti[mask] * data.n_node + ni[mask]
        if len(np.unique(flat)) != int(points_per_case):
            raise ValueError(f"Validation case {case} contains duplicate time-node samples")


def fixed_sample_arrays(
    data: CanonicalReferenceData,
    normalizer: Normalizer,
    trunk_all: np.ndarray,
    sample: dict[str, np.ndarray],
) -> SampleBatch:
    ci = np.asarray(sample["case_index"], dtype=np.int64)
    ti = np.asarray(sample["time_index"], dtype=np.int64)
    ni = np.asarray(sample["node_index"], dtype=np.int64)
    branch_norm = normalizer.branch_to_norm(np.asarray(data.branch))
    raw = data.get_target_batch(ci, ti, ni)
    return SampleBatch(
        branch=np.asarray(branch_norm[ci], dtype=np.float32),
        trunk=np.asarray(trunk_all[ti, ni], dtype=np.float32),
        target=normalizer.target_to_norm(raw),
    )

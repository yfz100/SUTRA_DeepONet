from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

from src.export_store import validate_prediction_export
from src.normalization import load_normalizer
from src.physics_contracts import audit_boundaries, audit_initial_conditions, validate_physics_config
from src.physics_engine import batch_sizes_for_mode
from src.physics_sampling import validate_fixed_physics_validation_plan
from src.reference_data import CanonicalReferenceData
from src.sampling import validate_fixed_validation_indices
from src.utils import load_json, load_yaml, save_json


def main() -> None:
    p = argparse.ArgumentParser(description="Verify a completed SUTRA DeepONet physics v2.1 run")
    p.add_argument("--config", required=True)
    p.add_argument("--run-dir", required=True)
    p.add_argument("--allow-missing-exports", action="store_true")
    args = p.parse_args()

    cfg = load_yaml(args.config)
    run = Path(args.run_dir)
    failures: list[str] = []
    mode = str(cfg["training"]["mode"])

    c = validate_physics_config(cfg)
    failures.extend([f"physics config: {x}" for x in c["failures"]])

    source = CanonicalReferenceData(cfg["paths"]["source_processed_dir"])
    ood = CanonicalReferenceData(cfg["paths"]["ood_processed_dir"])
    b = audit_boundaries(source, cfg)
    failures.extend([f"boundary contract: {x}" for x in b["failures"]])
    ic = audit_initial_conditions(source, ood)
    failures.extend([f"initial-condition contract: {x}" for x in ic["failures"]])

    norm_path = run / "normalization" / "normalizer.json"
    norm_meta_path = run / "normalization" / "normalizer_metadata.json"
    if not norm_path.exists() or not norm_meta_path.exists():
        failures.append("normalizer files missing")
    else:
        _ = load_normalizer(norm_path)
        nm = load_json(norm_meta_path)
        train_ids = source.case_metadata.iloc[source.get_split_indices("train")]["case_id"].astype(str).tolist()
        if nm.get("fit_split") != "train" or nm.get("fit_case_ids") != train_ids:
            failures.append("normalizer branch/data fit cases are not exactly source train cases")
        if mode == "hybrid":
            if nm.get("n_fit_points_per_target") != 120 * 73 * 3534:
                failures.append("Hybrid normalizer target statistics do not cover exactly the formal train fields")
        else:
            if nm.get("transient_target_statistics_used") is not False:
                failures.append("Physics-only normalizer used transient target statistics")
            if nm.get("target_scale_mode") != "physical_prior":
                failures.append("Physics-only target normalization is not physical_prior")

    if mode == "hybrid":
        val_path = run / "sampling" / "validation_sample_indices.npz"
        if not val_path.exists():
            failures.append("fixed data validation sample missing")
        else:
            try:
                sample = dict(np.load(val_path))
                validate_fixed_validation_indices(source, sample, int(cfg["training"]["val_points_per_case"]))
            except Exception as exc:
                failures.append(f"fixed data validation sample invalid: {exc}")
    else:
        val_path = run / "sampling" / "physics_validation_plan.npz"
        if not val_path.exists():
            failures.append("fixed physics validation plan missing")
        else:
            try:
                vp = cfg["physics_regularization"]["physics_validation"]
                plan = dict(np.load(val_path))
                validate_fixed_physics_validation_plan(
                    source,
                    plan,
                    batch_sizes_for_mode(cfg, mode),
                    int(vp["n_batches"]),
                    float(vp["batch_scale"]),
                )
            except Exception as exc:
                failures.append(f"fixed physics validation plan invalid: {exc}")

    for ck in ["best.pt", "last.pt"]:
        if not (run / "checkpoints" / ck).exists():
            failures.append(f"checkpoint missing: {ck}")

    hist = run / "training" / "training_history.csv"
    summary = run / "training" / "training_summary.json"
    timing = run / "training" / "timing_summary.json"
    for pth in [hist, summary, timing, run / "physics" / "relobralo_group_state.json"]:
        if not pth.exists():
            failures.append(f"training artifact missing: {pth.relative_to(run)}")
    if summary.exists():
        ts = load_json(summary)
        if ts.get("training_mode") != mode:
            failures.append("training summary mode does not match config")
        if mode == "hybrid" and float(ts.get("alpha_phys_target", -1.0)) != float(cfg["physics_regularization"]["relobralo"]["alpha_phys"]):
            failures.append("training summary alpha_phys does not match config")
        if mode == "physics_only" and ts.get("alpha_phys_target") is not None:
            failures.append("Physics-only training summary unexpectedly contains alpha_phys")

    export_presence = []
    for data, name in [(source, "source"), (ood, "higher_amplitude")]:
        export_dir = run / "exports" / name
        export_presence.append(export_dir.exists())
        if export_dir.exists():
            rep = validate_prediction_export(data, export_dir)
            failures.extend([f"{name} export: {x}" for x in rep["failures"]])
        elif not args.allow_missing_exports:
            failures.append(f"export missing: {name}")

    source_metrics = run / "metrics" / "source"
    if source_metrics.exists():
        by_case = pd.read_csv(source_metrics / "metrics_by_case.csv")
        by_time = pd.read_csv(source_metrics / "metrics_by_case_time.csv")
        if len(by_case) != 168:
            failures.append(f"source metrics_by_case rows={len(by_case)} !=168")
        if len(by_time) != 168 * 73:
            failures.append(f"source metrics_by_case_time rows={len(by_time)} !=12264")
    elif not args.allow_missing_exports:
        failures.append("source metrics missing")

    ood_metrics = run / "metrics" / "higher_amplitude"
    if ood_metrics.exists():
        by_case = pd.read_csv(ood_metrics / "metrics_by_case.csv")
        by_time = pd.read_csv(ood_metrics / "metrics_by_case_time.csv")
        if len(by_case) != 18:
            failures.append(f"OOD metrics_by_case rows={len(by_case)} !=18")
        if len(by_time) != 18 * 73:
            failures.append(f"OOD metrics_by_case_time rows={len(by_time)} !=1314")
    elif not args.allow_missing_exports:
        failures.append("OOD metrics missing")

    report = {
        "passed": not failures,
        "failures": failures,
        "training_mode": mode,
        "physics_config_contract": c,
        "boundary_contract": b,
        "initial_condition_contract": ic,
        "exports_required": not args.allow_missing_exports,
    }
    save_json(report, run / "run_verification.json")
    if failures:
        raise ValueError("Run verification failed:\n- " + "\n- ".join(failures))
    print("Run verification passed.")


if __name__ == "__main__":
    main()

from __future__ import annotations

import argparse
from pathlib import Path

from src.config_schema import validate_config
from src.physics_contracts import validate_physics_config
from src.reference_data import CanonicalReferenceData
from src.training import train_model
from src.utils import get_device, load_yaml


def main() -> None:
    p = argparse.ArgumentParser(description="Train SUTRA DeepONet physics v2.1 (Hybrid or Physics-only)")
    p.add_argument("--config", required=True)
    p.add_argument("--run-dir", required=True)
    args = p.parse_args()
    cfg = load_yaml(args.config)
    validate_config(cfg)
    rep = validate_physics_config(cfg)
    if not rep["passed"]:
        raise ValueError("Physics config contract failed:\n- " + "\n- ".join(rep["failures"]))
    data = CanonicalReferenceData(cfg["paths"]["source_processed_dir"])
    device = get_device(cfg["training"].get("device", "auto"))
    print(f"Training mode: {cfg['training']['mode']}")
    print(f"Training device: {device}")
    summary = train_model(cfg, data, Path(args.run_dir), device)
    print(summary)


if __name__ == "__main__":
    main()

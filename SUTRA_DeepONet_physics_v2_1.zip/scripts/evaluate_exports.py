from __future__ import annotations

import argparse
from pathlib import Path

from src.metrics import evaluate_prediction_export
from src.reference_data import CanonicalReferenceData
from src.utils import load_yaml


def main() -> None:
    p = argparse.ArgumentParser(description="Evaluate frozen prediction exports; does not load model")
    p.add_argument("--config", required=True)
    p.add_argument("--run-dir", required=True)
    p.add_argument("--library", choices=["source", "higher_amplitude"], required=True)
    args = p.parse_args()

    cfg = load_yaml(args.config)
    run_dir = Path(args.run_dir)
    if args.library == "source":
        data = CanonicalReferenceData(cfg["paths"]["source_processed_dir"])
        export_dir = run_dir / "exports" / "source"
        metrics_dir = run_dir / "metrics" / "source"
    else:
        data = CanonicalReferenceData(cfg["paths"]["ood_processed_dir"])
        export_dir = run_dir / "exports" / "higher_amplitude"
        metrics_dir = run_dir / "metrics" / "higher_amplitude"
    if not (export_dir / "EXPORT_COMPLETE").exists():
        raise FileNotFoundError(f"No complete prediction export: {export_dir}")
    summary = evaluate_prediction_export(data, export_dir, metrics_dir)
    print(summary)


if __name__ == "__main__":
    main()

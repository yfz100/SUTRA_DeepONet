from __future__ import annotations

import argparse
from pathlib import Path

from src.export_store import export_library_predictions, validate_prediction_export
from src.reference_data import CanonicalReferenceData
from src.utils import get_device, load_yaml, save_json


def main() -> None:
    p = argparse.ArgumentParser(description="Export full DeepONet predictions once for later metrics/plots")
    p.add_argument("--config", required=True)
    p.add_argument("--run-dir", required=True)
    p.add_argument("--library", choices=["source", "higher_amplitude"], required=True)
    p.add_argument("--checkpoint", choices=["best", "last"], default="best")
    p.add_argument("--overwrite", action="store_true")
    args = p.parse_args()

    cfg = load_yaml(args.config)
    data_dir = cfg["paths"]["source_processed_dir"] if args.library == "source" else cfg["paths"]["ood_processed_dir"]
    data = CanonicalReferenceData(data_dir)
    device = get_device(cfg["training"].get("device", "auto"))
    out = export_library_predictions(cfg, data, Path(args.run_dir), args.checkpoint, device, args.overwrite)
    report = validate_prediction_export(data, out)
    save_json(report, out / "export_validation.json")
    if not report["passed"]:
        raise ValueError("Prediction export validation failed: " + "; ".join(report["failures"]))
    print(f"Prediction export passed: {out}")


if __name__ == "__main__":
    main()

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np

from src.config_schema import ensure_input_paths_exist, validate_config
from src.contracts import run_full_data_contract
from src.physics_contracts import audit_boundaries, audit_initial_conditions, validate_physics_config
from src.reference_data import CanonicalReferenceData
from src.utils import load_yaml, save_json


def _run_model_and_physics_smoke(cfg: dict, source: CanonicalReferenceData, run_dir: Path, report: dict) -> None:
    """Run a tiny all-term autograd smoke test in the final torch environment."""
    try:
        import torch
        from src.model import build_model
        from src.normalization import fit_physics_only_normalizer, fit_train_only_normalizer
        from src.physics_engine import ALL_TERMS
        from src.physics_losses import compute_physics_term
        from src.physics_sampling import detect_boundaries, sample_physics_indices
        from src.utils import get_device
    except ModuleNotFoundError as exc:
        raise RuntimeError(
            "PyTorch is required for the physics-autograd smoke test but is not installed in this environment."
        ) from exc

    device = get_device(cfg["training"].get("device", "auto"))
    model = build_model(cfg).to(device)
    with torch.no_grad():
        b = torch.zeros((4, 2), dtype=torch.float32, device=device)
        x = torch.zeros((4, 7), dtype=torch.float32, device=device)
        y = model(b, x)
    if tuple(y.shape) != (4, 2):
        raise ValueError(f"Model smoke forward failed: output shape={tuple(y.shape)}")

    mode = str(cfg["training"]["mode"])
    if mode == "hybrid":
        norm, _ = fit_train_only_normalizer(source, cfg["physics"], eps=float(cfg["normalization"]["eps"]))
    else:
        po = cfg["normalization"]["physics_only"]
        norm, _ = fit_physics_only_normalizer(
            source,
            cfg["physics"],
            eps=float(cfg["normalization"]["eps"]),
            target_mean_physical=tuple(po["target_mean_physical"]),
            target_std_physical=tuple(po["target_std_physical"]),
        )

    binfo = detect_boundaries(np.asarray(source.coords), cfg["physics_regularization"]["boundary_detection"])
    p_cfg = dict(cfg["physics_regularization"]["common_physics"])
    p_cfg.update(cfg["physics_regularization"].get("sampling", {}))
    term_report: dict[str, dict] = {}
    losses = []
    for i, term in enumerate(ALL_TERMS):
        idx = sample_physics_indices(
            source, binfo, "train", term, 2,
            int(cfg["project"]["seed"]) + 991,
            epoch=1, batch_number=i, cfg=p_cfg,
        )
        diag = compute_physics_term(term, model, source, norm, idx, device, p_cfg, binfo)
        if not bool(torch.isfinite(diag.loss).all()):
            raise ValueError(f"Physics smoke produced non-finite normalized loss for {term}")
        if not bool(torch.isfinite(diag.raw_mse).all()):
            raise ValueError(f"Physics smoke produced non-finite raw MSE for {term}")
        term_report[term] = {
            "normalized_mse": float(diag.loss.detach().cpu()),
            "raw_mse": float(diag.raw_mse.detach().cpu()),
            "scale": float(diag.scale),
        }
        losses.append(diag.loss)

    model.zero_grad(set_to_none=True)
    total = torch.stack(losses).mean()
    total.backward()
    grad_tensors = [p.grad for p in model.parameters() if p.grad is not None]
    if not grad_tensors:
        raise ValueError("Physics smoke backward produced no model gradients")
    if not all(bool(torch.isfinite(g).all()) for g in grad_tensors):
        raise ValueError("Physics smoke backward produced non-finite model gradients")

    report["model_smoke"] = {
        "required": True,
        "device": str(device),
        "output_shape": list(y.shape),
        "passed": True,
    }
    report["physics_autograd_smoke"] = {
        "required": True,
        "training_mode": mode,
        "n_terms": len(ALL_TERMS),
        "all_terms_finite": True,
        "backward_gradients_finite": True,
        "term_diagnostics": term_report,
        "passed": True,
    }


def main() -> None:
    p = argparse.ArgumentParser(description="Fail-closed preflight for SUTRA DeepONet physics v2.1")
    p.add_argument("--config", required=True)
    p.add_argument("--run-dir", required=True)
    p.add_argument(
        "--require-torch",
        action="store_true",
        help="Also run model-forward and all-term physics-autograd smoke tests.",
    )
    args = p.parse_args()

    cfg = load_yaml(args.config)
    validate_config(cfg)
    ensure_input_paths_exist(cfg)
    run_dir = Path(args.run_dir)

    report = run_full_data_contract(
        cfg["paths"]["source_processed_dir"],
        cfg["paths"]["ood_processed_dir"],
        cfg["paths"]["manifest_path"],
        run_dir / "data_contract_report.json",
    )
    source = CanonicalReferenceData(cfg["paths"]["source_processed_dir"])
    ood = CanonicalReferenceData(cfg["paths"]["ood_processed_dir"])

    physics_report = {
        "config_contract": validate_physics_config(cfg),
        "boundary_contract": audit_boundaries(source, cfg),
        "initial_condition_contract": audit_initial_conditions(source, ood),
    }
    physics_failures = []
    for name, sub in physics_report.items():
        physics_failures.extend([f"{name}: {x}" for x in sub.get("failures", [])])
    physics_report["passed"] = not physics_failures
    physics_report["failures"] = physics_failures
    save_json(physics_report, run_dir / "physics_preflight_report.json")
    if physics_failures:
        raise ValueError("Physics preflight failed:\n- " + "\n- ".join(physics_failures))

    if args.require_torch:
        _run_model_and_physics_smoke(cfg, source, run_dir, report)
    else:
        report["model_smoke"] = {"required": False, "passed": None, "status": "skipped_data_only_preflight"}
        report["physics_autograd_smoke"] = {"required": False, "passed": None, "status": "skipped_data_only_preflight"}

    save_json(report, run_dir / "data_contract_report.json")
    print("Preflight passed.")
    print("Physics config/boundary/initial-condition contracts passed.")
    if not args.require_torch:
        print("Model/physics autograd smoke skipped (DO_TRAIN/export disabled).")


if __name__ == "__main__":
    main()

# SUTRA_DeepONet_physics_v2_1

Section 4.2 controlled comparison package for the canonical SUTRA2.2 coupled flow–transport surrogate experiment.

This package is built on the frozen Pure-supervised v2.1.2 infrastructure, while porting the audited physics residuals and group-level ReLoBRaLo logic from the previous HybridFullLite / PhysicsOnly experiments.

## Supported training modes

### 1. Physics-regularized Hybrid

```python
TRAINING_MODE = "hybrid"
ALPHA_PHYS = 0.1   # formal run 1
# or
ALPHA_PHYS = 0.5   # formal run 2
```

The total loss is

\[
L_{total}=L_{data}+\alpha_{phys}(e)\frac{1}{6}\sum_{g=1}^{6}w_gL_g,
\]

where the data loss remains anchored at weight 1, `alpha_phys` ramps linearly over the first 200 epochs, and the six physics-group weights are updated by ReLoBRaLo from epoch-mean group losses.

### 2. Physics-only

```python
TRAINING_MODE = "physics_only"
```

The loss is

\[
L_{PO}=\frac{1}{6}\sum_{g=1}^{6}w_gL_g.
\]

Physics-only has no `alpha_phys`, because there is no data term against which the entire physics contribution is scaled.

## Frozen ReLoBRaLo design

- six groups
- `alpha_memory = 0.95`
- `temperature = 0.2`
- `expected_rho = 0.99`
- group weight clamp `[0.2, 5.0]`
- renormalize after clamp
- epoch-mean update
- seed `20269692`
- Hybrid formal `alpha_phys = 0.1 / 0.5`
- 200-epoch linear `alpha_phys` ramp

The old config's per-term `lambda=0.1` fallback is intentionally **not active** under ReLoBRaLo and must not be confused with manuscript `alpha_phys`.

## Six physics groups

1. `flow_pde`
2. `transport_pde`
3. `pressure_value = {ic_psi, land_p, sea_p}`
4. `concentration_value_source = {ic_u, land_u, sea_inflow_u}`
5. `impermeable_no_flux = {bottom_flow, bottom_solute, top_flow, top_solute}`
6. `exposed_sea_no_flux = {exposed_flow, exposed_solute}`

The fifth group is the physically complete replacement for the old `bottom_no_flux` group. It preserves the six-group ReLoBRaLo structure while adding the formally required top no-flow boundary.

## Canonical physics corrections relative to the old packages

- branch input is `[A, H_land]`;
- land pressure BC uses the sampled case-specific `H_land`;
- canonical pressure head is `psi = p / 9810`;
- active sea pressure-head target is `(gamma_sea/9810)*(eta-z)`;
- Physics-only uses the H-dependent canonical COLD `t=0` pressure field as a prescribed initial condition;
- top no-flow / no-solute-flux is included;
- land and sea specified-pressure source concentrations are enforced only on predicted inflow;
- Hybrid checkpoint selection uses the frozen 24-case / 10,602-points-per-case validation sample;
- Physics-only uses a frozen physics-validation collocation plan;
- downstream export, physical-space metrics, timing, and verification inherit the pure v2.1.2 contracts.

## Continuous-physics limitation

These are differentiable continuous strong-form residuals based on SUTRA governing processes and constitutive relations. They are **not** the assembled SUTRA finite-element / time-discrete / `UP=0.5` algebraic residual.

## First run on AutoDL: preflight only

The distributed `run_pipeline.py` intentionally ships with:

```python
DO_PREFLIGHT = True
DO_TRAIN = False
```

Check only that:

```python
REFERENCE_LIBRARY_ROOT = Path("/root/reference_library")
TRAINING_MODE = "hybrid"
ALPHA_PHYS = 0.1
```

then run:

```bash
cd /root/SUTRA_DeepONet_physics_v2_1
python run_pipeline.py
```

The first gate verifies canonical data, source/OOD contracts, frozen physics configuration, boundary detection, and H-dependent initial-condition consistency. Do **not** enable formal training until that preflight report is reviewed.

## Second gate (only after preflight review)

A 1-epoch A800 smoke run should then enable `DO_TRAIN=True` with a deliberately small number of steps. When training is enabled, preflight additionally runs a tiny all-term PyTorch/autograd smoke test before entering the optimizer loop.

## Tests

Local/source-level tests:

```bash
python -m compileall -q .
pytest -q
```

Release v2.1.0-preflight: 19 tests pass.

## Key outputs

Each run freezes `config_used.yaml` and records:

- `environment.json`
- `data_contract_report.json`
- `physics_preflight_report.json`
- `normalization/*`
- `sampling/*`
- `physics/boundary_description.json`
- `physics/relobralo_group_state.json`
- `training/training_history.csv`
- `training/training_summary.json`
- `training/timing_summary.json`
- `checkpoints/best.pt`, `last.pt`
- optional frozen prediction exports and physical-space metrics

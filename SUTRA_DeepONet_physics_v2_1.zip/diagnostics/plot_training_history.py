from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def _finite_xy(df: pd.DataFrame, col: str):
    if col not in df.columns:
        return np.array([]), np.array([])
    y = df[col].to_numpy(dtype=float)
    x = df["epoch"].to_numpy(dtype=float)
    m = np.isfinite(y) & (y > 0)
    return x[m], y[m]


def main() -> None:
    p = argparse.ArgumentParser(description="Plot Hybrid/Physics-only training diagnostics")
    p.add_argument("--run-dir", required=True)
    args = p.parse_args()
    run = Path(args.run_dir)
    hist_path = run / "training" / "training_history.csv"
    if not hist_path.exists():
        raise FileNotFoundError(hist_path)
    df = pd.read_csv(hist_path)
    mode = str(df["training_mode"].dropna().iloc[0])
    out = run / "diagnostics"
    out.mkdir(parents=True, exist_ok=True)

    fig, ax = plt.subplots(figsize=(8.4, 5.2))
    for col, label in (
        ("train_total_loss", "Training total"),
        ("train_data_loss_norm", "Training data"),
        ("val_combined_mse_norm", "Validation data"),
        ("val_physics_loss", "Validation physics"),
    ):
        x, y = _finite_xy(df, col)
        if len(x):
            ax.plot(x, y, label=label)
    ax.set_yscale("log")
    ax.set_xlabel("Epoch")
    ax.set_ylabel("Loss")
    ax.set_title(f"Training history ({mode})")
    ax.grid(True, which="both", alpha=0.25)
    ax.legend()
    fig.tight_layout()
    fig.savefig(out / "training_history.png", dpi=220, bbox_inches="tight")
    plt.close(fig)

    weight_cols = [c for c in df.columns if c.startswith("group_") and c.endswith("_weight_used")]
    if weight_cols:
        fig, ax = plt.subplots(figsize=(8.4, 5.2))
        for col in weight_cols:
            label = col[len("group_") : -len("_weight_used")]
            ax.plot(df["epoch"], df[col], label=label)
        ax.set_xlabel("Epoch")
        ax.set_ylabel("ReLoBRaLo group weight")
        ax.set_title(f"ReLoBRaLo group weights ({mode})")
        ax.grid(True, alpha=0.25)
        ax.legend(fontsize=8, ncol=2)
        fig.tight_layout()
        fig.savefig(out / "relobralo_group_weights.png", dpi=220, bbox_inches="tight")
        plt.close(fig)

    group_cols = [c for c in df.columns if c.startswith("group_") and c.endswith("_mse_nd")]
    if group_cols:
        fig, ax = plt.subplots(figsize=(8.4, 5.2))
        for col in group_cols:
            x, y = _finite_xy(df, col)
            if len(x):
                label = col[len("group_") : -len("_mse_nd")]
                ax.plot(x, y, label=label)
        ax.set_yscale("log")
        ax.set_xlabel("Epoch")
        ax.set_ylabel("Normalized group MSE")
        ax.set_title(f"Physics group losses ({mode})")
        ax.grid(True, which="both", alpha=0.25)
        ax.legend(fontsize=8, ncol=2)
        fig.tight_layout()
        fig.savefig(out / "physics_group_losses.png", dpi=220, bbox_inches="tight")
        plt.close(fig)

    print(f"Diagnostics saved: {out}")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Fail-closed preflight without running adaptation epochs."""
from pathlib import Path
import os
import re
import sys


def _sanitize_openmp_environment() -> None:
    for name in ("OMP_NUM_THREADS", "OMP_THREAD_LIMIT"):
        raw = os.environ.get(name)
        if raw is None:
            continue
        value = raw.strip()
        valid = bool(re.fullmatch(r"[1-9]\d*(?:,[1-9]\d*)*", value))
        if not valid:
            print(f"WARNING: removing invalid {name}={raw!r} before numerical-library import.")
            os.environ.pop(name, None)


_sanitize_openmp_environment()

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from run_pipeline import build_config
from sutra_transfer.pipeline import preflight

if __name__ == "__main__":
    preflight(build_config())

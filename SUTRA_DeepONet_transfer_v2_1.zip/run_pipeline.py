#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SUTRA_DeepONet_transfer_v2_1
=================================
Centralized runner for the canonical v2.1 transfer-learning experiments.

Design fixed by the project protocol:
  1) no-transfer baseline;
  2) one-shot adaptation: support A=0.70 m;
  3) two-shot adaptation: support A=0.70 and 1.00 m;
  4) common evaluation for all three: A=0.80, 0.90, 1.10, 1.20 m;
  5) all target-regime cases use H_land=2.50 m;
  6) adaptation = source replay + labelled target data + SP regularization;
  7) trunk/early branch frozen; last two branch linear layers + output bias trainable;
  8) no PDE/BC/IC residual is used during transfer adaptation.

Edit the parameter block below first. The rest of the package should not need edits.
"""
from pathlib import Path
import os
import re


def _sanitize_openmp_environment() -> None:
    # Some cloud images export malformed OpenMP thread-count variables.
    # libgomp emits a warning while importing numerical libraries.  Remove only
    # malformed values; preserve valid positive integer/list settings.
    for name in ("OMP_NUM_THREADS", "OMP_THREAD_LIMIT"):
        raw = os.environ.get(name)
        if raw is None:
            continue
        value = raw.strip()
        valid = bool(re.fullmatch(r"[1-9]\d*(?:,[1-9]\d*)*", value))
        if not valid:
            print(f"WARNING: removing invalid {name}={raw!r} before numerical-library import.")
            os.environ.pop(name, None)


_sanitize_openmp_environment()

from sutra_transfer.pipeline import TransferConfig, run_pipeline


# =============================================================================
#                 A. 最常改参数汇总区 / CENTRAL PARAMETER BLOCK
# =============================================================================

PROJECT_ROOT = Path(__file__).resolve().parent

# ---- Canonical v2.1 data ----------------------------------------------------
REFERENCE_LIBRARY_ROOT = Path(r"/root/reference_library")
SOURCE_PROCESSED_DIR = REFERENCE_LIBRARY_ROOT / "source_range" / "processed"
OOD_PROCESSED_DIR = REFERENCE_LIBRARY_ROOT / "higher_amplitude" / "processed"
MANIFEST_PATH = REFERENCE_LIBRARY_ROOT / "SUTRA_case_manifest_v2.1_2026-09-29.csv"

# ---- Formal pretrained supervised source run -------------------------------
SOURCE_RUN_DIR = Path(
    r"/root/SUTRA_DeepONet_pure_v2_1/runs/"
    r"pure_supervised_v2_1_20261002_080051"
)
# None -> auto-discover under SOURCE_RUN_DIR. Set an explicit Path only if needed.
SOURCE_CHECKPOINT = None
SOURCE_NORMALIZER = None
EXPECTED_SOURCE_BEST_EPOCH = 485

# ---- Which experiments to run ----------------------------------------------
# "all" | "no_transfer" | "one_shot" | "two_shot"
RUN_SELECTION = "all"

# ---- Target-regime protocol -------------------------------------------------
TARGET_H_LAND_M = 2.50
ONE_SHOT_SUPPORT_AMPLITUDES_M = [0.70]
TWO_SHOT_SUPPORT_AMPLITUDES_M = [0.70, 1.00]
COMMON_EVAL_AMPLITUDES_M = [0.80, 0.90, 1.10, 1.20]
MATCH_ATOL = 1.0e-10

# ---- Old transfer mechanism retained ---------------------------------------
MAX_EPOCHS = 300
LEARNING_RATE = 1.0e-4
WEIGHT_DECAY = 0.0
BATCH_SIZE = 8192
REPLAY_SAMPLES_PER_EPOCH = 262_144
TARGET_SAMPLES_PER_EPOCH = 262_144
LAMBDA_TARGET = 1.0
LAMBDA_SP = 1.0e-4
GRAD_CLIP_NORM = 1.0

# Transfer validation / checkpoint selection retained from the agreed v2.1 plan.
VAL_EVERY_EPOCHS = 5
SOURCE_VAL_POINTS = 131_072
TARGET_CAL_VAL_POINTS = 131_072
VALIDATION_SEED = 21_260_605
SCHEDULER_FACTOR = 0.5
SCHEDULER_PATIENCE = 8
SCHEDULER_MIN_LR = 1.0e-6
EARLY_STOPPING_PATIENCE_EPOCHS = 60

# ---- Model / physics representation ----------------------------------------
SEED = 20_260_602
TIDAL_PERIOD_S = 43_200.0
X_SCALE_M = 10.0
Z_SCALE_M = 4.0
T_SCALE_S = 259_200.0
BRANCH_ORDER = ["amplitude_m", "h_land_m"]
TARGET_ORDER = ["pressure_head_m", "concentration"]
BRANCH_HIDDEN = [128, 128, 128]
TRUNK_HIDDEN = [256, 256, 256, 256]
LATENT_DIM = 256
OUTPUT_DIM = 2
ACTIVATION = "silu"

# ---- Runtime / export -------------------------------------------------------
DEVICE = "auto"
INFERENCE_BATCH_SIZE = 65_536
SAVE_COMMON_EVAL_PREDICTIONS = True
OVERWRITE_EXISTING = False
RUN_ROOT = PROJECT_ROOT / "runs"


# =============================================================================
#                       B. Build effective configuration
# =============================================================================

def build_config() -> TransferConfig:
    return TransferConfig(
        project_root=PROJECT_ROOT,
        source_processed_dir=SOURCE_PROCESSED_DIR,
        ood_processed_dir=OOD_PROCESSED_DIR,
        manifest_path=MANIFEST_PATH,
        source_run_dir=SOURCE_RUN_DIR,
        source_checkpoint=SOURCE_CHECKPOINT,
        source_normalizer=SOURCE_NORMALIZER,
        expected_source_best_epoch=EXPECTED_SOURCE_BEST_EPOCH,
        run_selection=RUN_SELECTION,
        target_h_land_m=TARGET_H_LAND_M,
        one_shot_support_amplitudes_m=tuple(ONE_SHOT_SUPPORT_AMPLITUDES_M),
        two_shot_support_amplitudes_m=tuple(TWO_SHOT_SUPPORT_AMPLITUDES_M),
        common_eval_amplitudes_m=tuple(COMMON_EVAL_AMPLITUDES_M),
        match_atol=MATCH_ATOL,
        max_epochs=MAX_EPOCHS,
        learning_rate=LEARNING_RATE,
        weight_decay=WEIGHT_DECAY,
        batch_size=BATCH_SIZE,
        replay_samples_per_epoch=REPLAY_SAMPLES_PER_EPOCH,
        target_samples_per_epoch=TARGET_SAMPLES_PER_EPOCH,
        lambda_target=LAMBDA_TARGET,
        lambda_sp=LAMBDA_SP,
        grad_clip_norm=GRAD_CLIP_NORM,
        val_every_epochs=VAL_EVERY_EPOCHS,
        source_val_points=SOURCE_VAL_POINTS,
        target_cal_val_points=TARGET_CAL_VAL_POINTS,
        validation_seed=VALIDATION_SEED,
        scheduler_factor=SCHEDULER_FACTOR,
        scheduler_patience=SCHEDULER_PATIENCE,
        scheduler_min_lr=SCHEDULER_MIN_LR,
        early_stopping_patience_epochs=EARLY_STOPPING_PATIENCE_EPOCHS,
        seed=SEED,
        tidal_period_s=TIDAL_PERIOD_S,
        x_scale_m=X_SCALE_M,
        z_scale_m=Z_SCALE_M,
        t_scale_s=T_SCALE_S,
        branch_order=tuple(BRANCH_ORDER),
        target_order=tuple(TARGET_ORDER),
        branch_hidden=tuple(BRANCH_HIDDEN),
        trunk_hidden=tuple(TRUNK_HIDDEN),
        latent_dim=LATENT_DIM,
        output_dim=OUTPUT_DIM,
        activation=ACTIVATION,
        device=DEVICE,
        inference_batch_size=INFERENCE_BATCH_SIZE,
        save_common_eval_predictions=SAVE_COMMON_EVAL_PREDICTIONS,
        overwrite_existing=OVERWRITE_EXISTING,
        run_root=RUN_ROOT,
    )


if __name__ == "__main__":
    run_pipeline(build_config())

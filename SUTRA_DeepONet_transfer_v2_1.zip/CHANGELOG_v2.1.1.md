# SUTRA_DeepONet_transfer_v2_1 — v2.1.1 preflight fix

This patch addresses the first real A800 preflight run.

1. `torch.device` in the resolved runtime configuration is now JSON serializable.
2. Source best-epoch provenance is checked against checkpoint metadata even when `training_summary.json` is absent.
3. Source training summaries are discovered recursively when copied into a nested source-run directory.
4. Malformed `OMP_NUM_THREADS` / `OMP_THREAD_LIMIT` values are removed before numerical-library import to avoid the `libgomp` warning; valid values are preserved.
5. Synthetic regression testing now covers device serialization as well as packed/split checkpoint mapping.

No scientific protocol, support/evaluation split, model architecture, normalization rule, loss definition, or transfer hyperparameter was changed.

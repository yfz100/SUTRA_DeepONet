# SUTRA代理模型项目总控文档更新 — Transfer v2.1 正式代码包

**日期：2026-10-06**

## 1. 本轮完成事项

已形成 `SUTRA_DeepONet_transfer_v2_1` 完整代码包，目标是在 canonical v2.1 统一 `(A,H_land)` coupled operator 基础上复现并扩展既有 few-shot transfer 方案。

正式 source model 为 `SUTRA_DeepONet_pure_v2_1` supervised best checkpoint（当前正式 run 的 best epoch=485）。transfer 不重新训练 source model，也不重新拟合 normalization。

## 2. 冻结的 transfer 设计

- target 固定 `H_land=2.50 m`；
- no-transfer：source checkpoint 直接推理；
- one-shot：support `A=0.70 m`；
- two-shot：support `A=0.70,1.00 m`；
- common evaluation：`A=0.80,0.90,1.10,1.20 m`；
- support 与 common evaluation 严格隔离。

旧机制保留：branch-last-fusion partial fine-tuning、source replay、few-shot labelled SUTRA field loss、SP regularization；不加入 physics residual。

适配损失：`L_replay + L_target + 1e-4 L_SP`。每 epoch 分别抽取 262,144 replay 和 262,144 target samples，batch size 8192，AdamW，lr=1e-4，maximum 300 epochs，gradient clipping=1.0。

## 3. v2.1 接口

- branch = `[amplitude_m, h_land_m]`；
- trunk = 7D harmonic-enhanced space-time features；
- outputs = pressure head + concentration；
- source normalizer 原样复用；
- replay 仅允许 source train split；
- canonical manifest 继续作为 split authority。

## 4. 新增公平比较

原 two-shot 结果叙事扩展为 no-transfer → one-shot → two-shot 的递进比较，三者统一在四个 common higher-amplitude cases withheld for testing 上评价，消除因不同 shot protocol 使用不同评价集合造成的比较混杂。

## 5. 下一步

在 A800 环境先运行 `python scripts/quick_check.py`，确认 formal source checkpoint、normalizer、canonical source/OOD arrays 及 checkpoint architecture mapping 全部通过；再运行 `python run_pipeline.py` 完成三组正式实验。运行完成后优先检查 common evaluation 的 pressure-head / concentration RMSE、MAE、RL2E、P95、P99、MaxAE 以及 one-shot→two-shot 的增益是否具有一致性。


## 2026-10-06 v2.1.1 preflight correction

The first A800 `quick_check.py` exposed a runtime serialization defect: after resolving `DEVICE=auto`, `TransferConfig.device_obj` contains a `torch.device`, which the original JSON helper could not serialize. This was a packaging/runtime defect only; no data split, normalization, DeepONet architecture, transfer objective, support case, evaluation case, or hyperparameter was implicated.

The corrected package now serializes `torch.device` safely, verifies the expected source best epoch against checkpoint metadata when `training_summary.json` is unavailable, recursively discovers a nested source training summary when present, and sanitizes malformed OpenMP thread-count environment variables before numerical-library import. Synthetic checkpoint mapping tests and a full synthetic preflight both pass after the correction.

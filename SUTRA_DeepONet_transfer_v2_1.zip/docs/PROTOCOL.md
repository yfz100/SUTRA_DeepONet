# Transfer v2.1 protocol freeze

## Operator interface

`(A, H_land) -> [pressure_head(x,z,t), concentration(x,z,t)]`

Trunk features:

`[x/10, z/4, t/259200, sin(wt), cos(wt), sin(2wt), cos(2wt)]`, with `w=2*pi/43200 s^-1`.

## Experiment matrix

| protocol | support at H_land=2.50 m | common evaluation at H_land=2.50 m |
|---|---|---|
| no-transfer | none | A=0.80,0.90,1.10,1.20 |
| one-shot | A=0.70 | A=0.80,0.90,1.10,1.20 |
| two-shot | A=0.70,1.00 | A=0.80,0.90,1.10,1.20 |

The support cases cannot enter the common evaluation population.

## Adaptation loss

`L_adapt = L_replay + lambda_target L_target + lambda_SP L_SP`,
with `lambda_target=1` and `lambda_SP=1e-4`.

`L_SP` is the mean squared parameter deviation from the pretrained starting point over trainable scalars only.

## Freeze policy

The trunk representation is frozen. The early branch representation is frozen. The last two branch linear stages and output bias remain trainable. For a packed terminal-latent implementation, these are the last shared branch hidden Linear layer and the final packed latent Linear layer. For a split-head implementation, these are the last shared branch Linear layer and all output-specific branch terminal heads.

## No-physics adaptation

No governing-equation, initial-condition, or boundary-condition residual enters transfer adaptation. This keeps the transfer comparison data-based and separate from the physics-regularized experiments.

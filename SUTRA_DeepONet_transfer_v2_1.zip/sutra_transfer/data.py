from __future__ import annotations

import math
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from .utils import read_csv_rows, read_json


REQUIRED_PROCESSED = (
    "branch_inputs.npy", "coords_xz_m.npy", "times_s.npy",
    "pressure_head_m.npy", "concentration.npy", "case_metadata.csv", "dataset_metadata.json"
)


@dataclass
class FixedTripletPlan:
    case_idx: np.ndarray
    time_idx: np.ndarray
    node_idx: np.ndarray

    @property
    def n(self):
        return int(len(self.case_idx))


class CanonicalLibrary:
    def __init__(self, processed_dir: Path, manifest_path: Path, expected_group: str, cfg):
        self.dir = Path(processed_dir)
        self.manifest_path = Path(manifest_path)
        self.expected_group = expected_group
        self.cfg = cfg
        self._check_files()
        self.branch = np.load(self.dir / "branch_inputs.npy", mmap_mode="r")
        self.coords = np.load(self.dir / "coords_xz_m.npy", mmap_mode="r")
        self.times = np.load(self.dir / "times_s.npy", mmap_mode="r")
        self.psi = np.load(self.dir / "pressure_head_m.npy", mmap_mode="r")
        self.conc = np.load(self.dir / "concentration.npy", mmap_mode="r")
        self.meta = read_csv_rows(self.dir / "case_metadata.csv")
        self.dataset_meta = read_json(self.dir / "dataset_metadata.json")
        self.manifest = read_csv_rows(self.manifest_path)
        self._validate()

    def _check_files(self):
        if not self.dir.is_dir():
            raise FileNotFoundError(f"Processed directory not found: {self.dir}")
        for name in REQUIRED_PROCESSED:
            if not (self.dir / name).is_file():
                raise FileNotFoundError(f"Required canonical processed file missing: {self.dir/name}")
        if not self.manifest_path.is_file():
            raise FileNotFoundError(f"Canonical manifest missing: {self.manifest_path}")

    def _validate(self):
        ncase = self.branch.shape[0]
        if self.branch.ndim != 2 or self.branch.shape[1] != 2:
            raise ValueError(f"branch_inputs.npy must have shape [N_case,2], got {self.branch.shape}")
        if len(self.meta) != ncase:
            raise ValueError(f"case_metadata rows {len(self.meta)} != branch N_case {ncase}")
        if self.coords.ndim != 2 or self.coords.shape[1] != 2:
            raise ValueError(f"coords_xz_m.npy invalid shape {self.coords.shape}")
        if self.times.ndim != 1:
            raise ValueError(f"times_s.npy invalid shape {self.times.shape}")
        expected_field = (ncase, len(self.times), len(self.coords))
        if self.psi.shape != expected_field or self.conc.shape != expected_field:
            raise ValueError(f"Field shape mismatch; expected {expected_field}, psi={self.psi.shape}, C={self.conc.shape}")
        if not np.all(np.isfinite(np.asarray(self.branch))):
            raise ValueError("branch_inputs contains NaN/Inf")
        if not np.all(np.diff(np.asarray(self.times, dtype=float)) >= 0):
            raise ValueError("times_s.npy is not monotonically nondecreasing")

        # Processed row alignment and group checks.
        for i, row in enumerate(self.meta):
            if int(row.get("case_index", i)) != i:
                raise ValueError(f"case_metadata case_index mismatch at row {i}")
            if row.get("library_group", self.expected_group) != self.expected_group:
                raise ValueError(f"Wrong library_group at processed row {i}: {row.get('library_group')}")
            a, h = float(row["amplitude_m"]), float(row["h_land_m"])
            if not np.allclose(np.asarray(self.branch[i], float), [a, h], rtol=0, atol=1e-7):
                raise ValueError(f"branch_inputs/case_metadata mismatch at row {i}")

        # Manifest is the split authority. Validate every processed case against it.
        m_by_id = {r["case_id"]: r for r in self.manifest if "case_id" in r}
        if len(m_by_id) == 0:
            raise ValueError("Manifest has no case_id column/rows.")
        for i, row in enumerate(self.meta):
            cid = row["case_id"]
            if cid not in m_by_id:
                raise ValueError(f"Processed case_id missing from canonical manifest: {cid}")
            mr = m_by_id[cid]
            if mr.get("library_group", row.get("library_group")) != row.get("library_group"):
                raise ValueError(f"Manifest library_group mismatch for {cid}")
            # Source split must agree; OOD split may use role-like labels but still must not become source train.
            if self.expected_group == "source_range":
                if mr.get("split") != row.get("split"):
                    raise ValueError(f"Manifest/processed split mismatch for {cid}: {mr.get('split')} vs {row.get('split')}")

    @property
    def ncase(self): return int(self.branch.shape[0])
    @property
    def nt(self): return int(len(self.times))
    @property
    def nnode(self): return int(len(self.coords))

    def split_indices(self, split: str) -> np.ndarray:
        idx = [i for i, r in enumerate(self.meta) if r.get("split", "").lower() == split.lower()]
        if not idx:
            raise ValueError(f"No cases found for split={split!r} in {self.expected_group}")
        return np.asarray(idx, dtype=np.int64)

    def select_exact_cases(self, amplitudes, h_land: float, atol: float) -> np.ndarray:
        amps = [float(a) for a in amplitudes]
        found = []
        for a in amps:
            hits = [i for i, r in enumerate(self.meta)
                    if abs(float(r["amplitude_m"]) - a) <= atol and abs(float(r["h_land_m"]) - h_land) <= atol]
            if len(hits) != 1:
                raise ValueError(
                    f"Expected exactly one canonical case for A={a:.6f}, H_land={h_land:.6f}; found {len(hits)}"
                )
            found.append(hits[0])
        if len(set(found)) != len(found):
            raise ValueError("Duplicate case selection detected.")
        return np.asarray(found, dtype=np.int64)

    def make_fixed_plan(self, case_indices: np.ndarray, n_points: int, seed: int) -> FixedTripletPlan:
        rng = np.random.default_rng(int(seed))
        case_indices = np.asarray(case_indices, dtype=np.int64)
        return FixedTripletPlan(
            case_idx=rng.choice(case_indices, size=int(n_points), replace=True),
            time_idx=rng.integers(0, self.nt, size=int(n_points), endpoint=False, dtype=np.int64),
            node_idx=rng.integers(0, self.nnode, size=int(n_points), endpoint=False, dtype=np.int64),
        )

    def sample_plan(self, case_indices: np.ndarray, n_points: int, rng: np.random.Generator) -> FixedTripletPlan:
        case_indices = np.asarray(case_indices, dtype=np.int64)
        return FixedTripletPlan(
            case_idx=rng.choice(case_indices, size=int(n_points), replace=True),
            time_idx=rng.integers(0, self.nt, size=int(n_points), endpoint=False, dtype=np.int64),
            node_idx=rng.integers(0, self.nnode, size=int(n_points), endpoint=False, dtype=np.int64),
        )

    def arrays_from_plan(self, plan: FixedTripletPlan, normalizer):
        c, ti, ni = plan.case_idx, plan.time_idx, plan.node_idx
        branch = np.asarray(self.branch[c], dtype=np.float32)
        xy = np.asarray(self.coords[ni], dtype=np.float32)
        t = np.asarray(self.times[ti], dtype=np.float32)
        omega = 2.0 * math.pi / float(self.cfg.tidal_period_s)
        trunk = np.column_stack([
            xy[:, 0] / float(self.cfg.x_scale_m),
            xy[:, 1] / float(self.cfg.z_scale_m),
            t / float(self.cfg.t_scale_s),
            np.sin(omega * t), np.cos(omega * t),
            np.sin(2.0 * omega * t), np.cos(2.0 * omega * t),
        ]).astype(np.float32)
        y = np.column_stack([
            np.asarray(self.psi[c, ti, ni], dtype=np.float32),
            np.asarray(self.conc[c, ti, ni], dtype=np.float32),
        ])
        return normalizer.normalize_branch(branch), trunk, normalizer.normalize_target(y)

    def full_case_query(self, case_idx: int, normalizer):
        # Flatten in [time,node] C-order so reshape back to [time,node] is exact.
        branch = np.repeat(np.asarray(self.branch[case_idx:case_idx+1], dtype=np.float32), self.nt*self.nnode, axis=0)
        coords = np.asarray(self.coords, dtype=np.float32)
        tgrid = np.repeat(np.asarray(self.times, dtype=np.float32), self.nnode)
        xgrid = np.tile(coords[:, 0], self.nt)
        zgrid = np.tile(coords[:, 1], self.nt)
        omega = 2.0 * math.pi / float(self.cfg.tidal_period_s)
        trunk = np.column_stack([
            xgrid / float(self.cfg.x_scale_m), zgrid / float(self.cfg.z_scale_m),
            tgrid / float(self.cfg.t_scale_s),
            np.sin(omega*tgrid), np.cos(omega*tgrid),
            np.sin(2.0*omega*tgrid), np.cos(2.0*omega*tgrid),
        ]).astype(np.float32)
        return normalizer.normalize_branch(branch), trunk

    def full_case_true(self, case_idx: int):
        return np.stack([
            np.asarray(self.psi[case_idx], dtype=np.float32),
            np.asarray(self.conc[case_idx], dtype=np.float32),
        ], axis=-1)

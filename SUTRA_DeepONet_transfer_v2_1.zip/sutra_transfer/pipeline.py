from __future__ import annotations

import csv
import json
import shutil
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import numpy as np
import torch

from .checkpoint import discover_checkpoint, discover_normalizer, load_canonical_source_model
from .data import CanonicalLibrary
from .evaluation import evaluate_common
from .normalizer import SourceNormalizer
from .training import adapt_model
from .utils import ensure_empty_or_create, jsonable, read_json, resolve_device, set_global_seed, sha256_file, write_csv_rows, write_json


@dataclass
class TransferConfig:
    project_root: Path
    source_processed_dir: Path
    ood_processed_dir: Path
    manifest_path: Path
    source_run_dir: Path
    source_checkpoint: Optional[Path]
    source_normalizer: Optional[Path]
    expected_source_best_epoch: Optional[int]
    run_selection: str
    target_h_land_m: float
    one_shot_support_amplitudes_m: tuple[float, ...]
    two_shot_support_amplitudes_m: tuple[float, ...]
    common_eval_amplitudes_m: tuple[float, ...]
    match_atol: float
    max_epochs: int
    learning_rate: float
    weight_decay: float
    batch_size: int
    replay_samples_per_epoch: int
    target_samples_per_epoch: int
    lambda_target: float
    lambda_sp: float
    grad_clip_norm: float
    val_every_epochs: int
    source_val_points: int
    target_cal_val_points: int
    validation_seed: int
    scheduler_factor: float
    scheduler_patience: int
    scheduler_min_lr: float
    early_stopping_patience_epochs: int
    seed: int
    tidal_period_s: float
    x_scale_m: float
    z_scale_m: float
    t_scale_s: float
    branch_order: tuple[str, ...]
    target_order: tuple[str, ...]
    branch_hidden: tuple[int, ...]
    trunk_hidden: tuple[int, ...]
    latent_dim: int
    output_dim: int
    activation: str
    device: str
    inference_batch_size: int
    save_common_eval_predictions: bool
    overwrite_existing: bool
    run_root: Path
    device_obj: object = field(default=None, init=False, repr=False)


def _validate_protocol(cfg: TransferConfig):
    allowed = {"all", "no_transfer", "one_shot", "two_shot"}
    if cfg.run_selection not in allowed:
        raise ValueError(f"RUN_SELECTION must be one of {sorted(allowed)}, got {cfg.run_selection!r}")
    common = set(map(float, cfg.common_eval_amplitudes_m))
    one = set(map(float, cfg.one_shot_support_amplitudes_m))
    two = set(map(float, cfg.two_shot_support_amplitudes_m))
    if common & one or common & two:
        raise ValueError("Support amplitudes overlap the common evaluation set. This would violate the agreed no-leakage protocol.")
    if tuple(cfg.branch_order) != ("amplitude_m", "h_land_m"):
        raise ValueError("Canonical v2.1 branch order must be [amplitude_m, h_land_m].")
    if tuple(cfg.target_order) != ("pressure_head_m", "concentration"):
        raise ValueError("Canonical v2.1 target order must be [pressure_head_m, concentration].")
    if cfg.output_dim != 2 or cfg.latent_dim != 256:
        raise ValueError("This formal transfer package expects the frozen v2.1 coupled source architecture (2 outputs, latent 256).")
    if cfg.replay_samples_per_epoch != 262_144 or cfg.target_samples_per_epoch != 262_144:
        print("WARNING: replay/target sample counts differ from the frozen transfer protocol.")


def _check_source_best_epoch(cfg):
    # Prefer the canonical run-root filename, but tolerate a copied source run
    # where the summary is stored one level deeper.  This is provenance only;
    # the checkpoint metadata is independently checked below.
    preferred = cfg.source_run_dir / "training_summary.json"
    candidates = [preferred]
    if not preferred.is_file() and cfg.source_run_dir.is_dir():
        candidates.extend(sorted(cfg.source_run_dir.rglob("training_summary*.json")))
    p = next((x for x in candidates if x.is_file()), None)
    if p is None:
        print(
            f"WARNING: source training_summary.json not found under {cfg.source_run_dir}; "
            "epoch provenance will rely on checkpoint metadata."
        )
        return None
    d = read_json(p)
    best = d.get("best_epoch")
    if cfg.expected_source_best_epoch is not None and best is not None and int(best) != int(cfg.expected_source_best_epoch):
        raise ValueError(
            f"Source best_epoch mismatch: expected {cfg.expected_source_best_epoch}, found {best} in {p}. "
            "Refusing to adapt the wrong source run."
        )
    d["_summary_path"] = str(p)
    return d


def _validate_checkpoint_epoch(cfg, source_summary, load_report):
    expected = cfg.expected_source_best_epoch
    if expected is None:
        return
    ckpt_epoch = load_report.get("checkpoint_epoch_if_present")
    summary_epoch = None if source_summary is None else source_summary.get("best_epoch")

    # If both sources exist they must agree with each other and with the
    # configured formal source best epoch.  If the summary is absent, the
    # checkpoint metadata alone is sufficient.  If neither carries an epoch,
    # fail closed rather than silently adapting an unverifiable checkpoint.
    if ckpt_epoch is not None and int(ckpt_epoch) != int(expected):
        raise ValueError(
            f"Source checkpoint epoch mismatch: expected {expected}, "
            f"checkpoint metadata reports {ckpt_epoch}. Refusing to adapt the wrong source checkpoint."
        )
    if summary_epoch is not None and int(summary_epoch) != int(expected):
        raise ValueError(
            f"Source training-summary best_epoch mismatch: expected {expected}, found {summary_epoch}."
        )
    if ckpt_epoch is not None and summary_epoch is not None and int(ckpt_epoch) != int(summary_epoch):
        raise ValueError(
            f"Source provenance conflict: checkpoint epoch={ckpt_epoch}, "
            f"training-summary best_epoch={summary_epoch}."
        )
    if ckpt_epoch is None and summary_epoch is None:
        raise ValueError(
            f"Cannot verify EXPECTED_SOURCE_BEST_EPOCH={expected}: neither the source checkpoint "
            "nor a training summary contains epoch metadata."
        )


def _make_adaptation_manifest(ood, cfg):
    rows = []
    for i, r in enumerate(ood.meta):
        a, h = float(r["amplitude_m"]), float(r["h_land_m"])
        roles = []
        if abs(h - cfg.target_h_land_m) <= cfg.match_atol:
            if any(abs(a-x) <= cfg.match_atol for x in cfg.one_shot_support_amplitudes_m): roles.append("one_shot_support")
            if any(abs(a-x) <= cfg.match_atol for x in cfg.two_shot_support_amplitudes_m): roles.append("two_shot_support")
            if any(abs(a-x) <= cfg.match_atol for x in cfg.common_eval_amplitudes_m): roles.append("common_eval")
        rows.append({
            "case_index": i, "case_id": r["case_id"], "amplitude_m": a, "h_land_m": h,
            "roles": ";".join(roles) if roles else "unused_in_transfer_v2_1",
        })
    return rows


def preflight(cfg: TransferConfig):
    _validate_protocol(cfg)
    cfg.device_obj = resolve_device(cfg.device)
    set_global_seed(cfg.seed)
    print(f"Transfer device: {cfg.device_obj}")
    checkpoint = discover_checkpoint(cfg.source_run_dir, cfg.source_checkpoint)
    normalizer_path = discover_normalizer(cfg.source_run_dir, cfg.source_normalizer)
    source_summary = _check_source_best_epoch(cfg)
    normalizer = SourceNormalizer.load(normalizer_path, cfg.branch_order, cfg.target_order)
    if not np.isclose(normalizer.x_scale_m, cfg.x_scale_m) or not np.isclose(normalizer.z_scale_m, cfg.z_scale_m) or not np.isclose(normalizer.t_scale_s, cfg.t_scale_s):
        raise ValueError("Source normalizer coordinate/time scales differ from transfer config.")

    source = CanonicalLibrary(cfg.source_processed_dir, cfg.manifest_path, "source_range", cfg)
    ood = CanonicalLibrary(cfg.ood_processed_dir, cfg.manifest_path, "higher_amplitude", cfg)
    train_idx = source.split_indices("train")
    if len(train_idx) != 120:
        raise ValueError(f"Canonical v2.1 expects 120 source training cases, found {len(train_idx)}")
    one_idx = ood.select_exact_cases(cfg.one_shot_support_amplitudes_m, cfg.target_h_land_m, cfg.match_atol)
    two_idx = ood.select_exact_cases(cfg.two_shot_support_amplitudes_m, cfg.target_h_land_m, cfg.match_atol)
    eval_idx = ood.select_exact_cases(cfg.common_eval_amplitudes_m, cfg.target_h_land_m, cfg.match_atol)
    if set(one_idx.tolist()) & set(eval_idx.tolist()) or set(two_idx.tolist()) & set(eval_idx.tolist()):
        raise RuntimeError("Support/common-evaluation case overlap detected after canonical lookup.")

    # Load once only for a compatibility preflight. Every protocol reloads a fresh copy later.
    model, load_report = load_canonical_source_model(checkpoint, cfg, cfg.device_obj)
    _validate_checkpoint_epoch(cfg, source_summary, load_report)
    _ = model.freeze_branch_last_fusion()
    del model

    cfg.run_root.mkdir(parents=True, exist_ok=True)
    write_json(cfg.run_root / "effective_config.json", cfg)
    write_csv_rows(cfg.run_root / "adaptation_manifest.csv", _make_adaptation_manifest(ood, cfg))
    write_json(cfg.run_root / "preflight_report.json", {
        "status": "passed",
        "device": str(cfg.device_obj),
        "source_checkpoint": str(checkpoint),
        "source_checkpoint_sha256": sha256_file(checkpoint),
        "source_normalizer": str(normalizer_path),
        "source_normalizer_sha256": sha256_file(normalizer_path),
        "source_best_epoch_from_training_summary": None if source_summary is None else source_summary.get("best_epoch"),
        "model_load": load_report,
        "n_source_train_cases": len(train_idx),
        "one_shot_support_case_indices": one_idx.tolist(),
        "two_shot_support_case_indices": two_idx.tolist(),
        "common_eval_case_indices": eval_idx.tolist(),
        "support_common_eval_disjoint": True,
    })
    print("Preflight passed.")
    return checkpoint, normalizer_path, normalizer, source, ood, train_idx, one_idx, two_idx, eval_idx


def _fresh_source(checkpoint, cfg):
    return load_canonical_source_model(checkpoint, cfg, cfg.device_obj)


def _run_no_transfer(checkpoint, normalizer, ood, eval_idx, cfg):
    out = cfg.run_root / "no_transfer_common_eval"
    ensure_empty_or_create(out, cfg.overwrite_existing)
    model, report = _fresh_source(checkpoint, cfg)
    write_json(out / "source_checkpoint_load_report.json", report)
    per, pooled = evaluate_common(model, ood, eval_idx, normalizer, cfg, out, "no_transfer", report)
    return per, pooled


def _run_adapt(name, support_amps, support_idx, checkpoint, normalizer, source, ood, train_idx, eval_idx, cfg):
    label = "one_shot_A0.70" if name == "one_shot" else "two_shot_A0.70_A1.00"
    out = cfg.run_root / label
    ensure_empty_or_create(out, cfg.overwrite_existing)
    model, report = _fresh_source(checkpoint, cfg)
    write_json(out / "source_checkpoint_load_report.json", report)
    write_json(out / "protocol.json", {
        "protocol": name,
        "support_amplitudes_m": list(support_amps),
        "support_h_land_m": cfg.target_h_land_m,
        "common_eval_amplitudes_m": list(cfg.common_eval_amplitudes_m),
        "common_eval_h_land_m": cfg.target_h_land_m,
        "support_and_common_eval_are_disjoint": True,
        "adaptation_objective": "L_replay + lambda_target*L_target + lambda_SP*L_SP",
        "physics_residuals_used": False,
    })
    model, summary = adapt_model(model, source, ood, train_idx, support_idx, normalizer, cfg, out, cfg.device_obj)
    best_ckpt = out / "best.pt"
    per, pooled = evaluate_common(
        model, ood, eval_idx, normalizer, cfg, out, name,
        {"path": str(best_ckpt), "epoch": summary["best_epoch"], "score": summary["best_checkpoint_score"]}
    )
    return per, pooled


def _write_comparison(cfg, all_per, all_pooled):
    out = cfg.run_root / "comparison_common_eval"
    out.mkdir(parents=True, exist_ok=True)
    write_csv_rows(out / "comparison_per_case.csv", all_per)
    write_csv_rows(out / "comparison_pooled.csv", all_pooled)
    # Simple deltas relative to no-transfer, when all three protocols are available.
    by = {(r["protocol"], r["field"]): r for r in all_pooled}
    rows = []
    for protocol in ("one_shot", "two_shot"):
        for field in ("pressure_head_m", "concentration"):
            base = by.get(("no_transfer", field)); cur = by.get((protocol, field))
            if base and cur:
                for metric in ("rmse", "mae", "rl2e", "max_abs_error", "p95_abs_error", "p99_abs_error"):
                    b = float(base[metric]); c = float(cur[metric])
                    rows.append({
                        "protocol": protocol, "field": field, "metric": metric,
                        "no_transfer": b, "adapted": c,
                        "absolute_change": c-b,
                        "improvement_percent": (b-c)/b*100.0 if b != 0 else float("nan"),
                    })
    if rows:
        write_csv_rows(out / "improvement_vs_no_transfer.csv", rows)


def run_pipeline(cfg: TransferConfig):
    checkpoint, normalizer_path, normalizer, source, ood, train_idx, one_idx, two_idx, eval_idx = preflight(cfg)
    all_per, all_pooled = [], []
    selected = ("no_transfer", "one_shot", "two_shot") if cfg.run_selection == "all" else (cfg.run_selection,)

    if "no_transfer" in selected:
        p, q = _run_no_transfer(checkpoint, normalizer, ood, eval_idx, cfg); all_per += p; all_pooled += q
    if "one_shot" in selected:
        p, q = _run_adapt("one_shot", cfg.one_shot_support_amplitudes_m, one_idx,
                          checkpoint, normalizer, source, ood, train_idx, eval_idx, cfg)
        all_per += p; all_pooled += q
    if "two_shot" in selected:
        p, q = _run_adapt("two_shot", cfg.two_shot_support_amplitudes_m, two_idx,
                          checkpoint, normalizer, source, ood, train_idx, eval_idx, cfg)
        all_per += p; all_pooled += q

    _write_comparison(cfg, all_per, all_pooled)
    print("\nTransfer pipeline completed successfully.")
    print(f"Results: {cfg.run_root}")

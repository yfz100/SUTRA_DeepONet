from __future__ import annotations

import numpy as np


METRIC_NAMES = ("rmse", "mae", "rl2e", "bias", "max_abs_error", "p95_abs_error", "p99_abs_error")


def metrics_1d(y_true, y_pred):
    yt = np.asarray(y_true, dtype=np.float64).reshape(-1)
    yp = np.asarray(y_pred, dtype=np.float64).reshape(-1)
    if yt.shape != yp.shape:
        raise ValueError("Metric arrays have different shapes.")
    err = yp - yt
    ae = np.abs(err)
    denom = float(np.sum(yt * yt, dtype=np.float64))
    num = float(np.sum(err * err, dtype=np.float64))
    return {
        "rmse": float(np.sqrt(np.mean(err * err, dtype=np.float64))),
        "mae": float(np.mean(ae, dtype=np.float64)),
        "rl2e": float(np.sqrt(num / denom)) if denom > 0 else float("nan"),
        "bias": float(np.mean(err, dtype=np.float64)),
        "max_abs_error": float(np.max(ae)),
        "p95_abs_error": float(np.percentile(ae, 95.0)),
        "p99_abs_error": float(np.percentile(ae, 99.0)),
    }

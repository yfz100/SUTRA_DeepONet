from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np

from .utils import read_json


@dataclass(frozen=True)
class SourceNormalizer:
    branch_mean: np.ndarray
    branch_std: np.ndarray
    target_mean: np.ndarray
    target_std: np.ndarray
    x_scale_m: float
    z_scale_m: float
    t_scale_s: float
    eps: float
    branch_order: tuple[str, ...]
    target_order: tuple[str, ...]

    @classmethod
    def load(cls, path: Path, expected_branch_order, expected_target_order):
        d = read_json(path)
        b_order = tuple(d["branch_order"])
        t_order = tuple(d["target_order"])
        if b_order != tuple(expected_branch_order):
            raise ValueError(f"Normalizer branch order mismatch: {b_order} != {tuple(expected_branch_order)}")
        if t_order != tuple(expected_target_order):
            raise ValueError(f"Normalizer target order mismatch: {t_order} != {tuple(expected_target_order)}")
        obj = cls(
            branch_mean=np.asarray(d["branch_mean"], dtype=np.float32),
            branch_std=np.asarray(d["branch_std"], dtype=np.float32),
            target_mean=np.asarray(d["target_mean"], dtype=np.float32),
            target_std=np.asarray(d["target_std"], dtype=np.float32),
            x_scale_m=float(d["x_scale_m"]),
            z_scale_m=float(d["z_scale_m"]),
            t_scale_s=float(d["t_scale_s"]),
            eps=float(d.get("eps", 1e-12)),
            branch_order=b_order,
            target_order=t_order,
        )
        obj._validate()
        return obj

    def _validate(self):
        if self.branch_mean.shape != self.branch_std.shape or self.branch_mean.ndim != 1:
            raise ValueError("Invalid branch normalizer shapes.")
        if self.target_mean.shape != self.target_std.shape or self.target_mean.ndim != 1:
            raise ValueError("Invalid target normalizer shapes.")
        if np.any(self.branch_std <= self.eps) or np.any(self.target_std <= self.eps):
            raise ValueError("Normalizer contains zero/near-zero standard deviation.")
        for a in (self.branch_mean, self.branch_std, self.target_mean, self.target_std):
            if not np.all(np.isfinite(a)):
                raise ValueError("Normalizer contains NaN/Inf.")

    def normalize_branch(self, x: np.ndarray) -> np.ndarray:
        return ((x - self.branch_mean) / self.branch_std).astype(np.float32, copy=False)

    def normalize_target(self, y: np.ndarray) -> np.ndarray:
        return ((y - self.target_mean) / self.target_std).astype(np.float32, copy=False)

    def denormalize_target(self, y: np.ndarray) -> np.ndarray:
        return (y * self.target_std + self.target_mean).astype(np.float32, copy=False)

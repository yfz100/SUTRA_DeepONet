from __future__ import annotations

import copy
import csv
import time
from pathlib import Path

import numpy as np
import torch

from .utils import write_json


def _tensorize(arr, device):
    return torch.as_tensor(arr, dtype=torch.float32, device=device)


def equal_output_field_loss(pred, target):
    # Equal nominal coefficient for pressure head and concentration in normalized space.
    per_output = torch.mean((pred - target) ** 2, dim=0)
    return torch.sum(per_output), per_output


def sp_loss(model, theta0: dict[str, torch.Tensor]):
    sq_sum = None
    n = 0
    for name, p in model.named_parameters():
        if not p.requires_grad:
            continue
        d = p - theta0[name]
        term = torch.sum(d * d)
        sq_sum = term if sq_sum is None else sq_sum + term
        n += p.numel()
    if n == 0:
        raise RuntimeError("No trainable parameters are open for transfer adaptation.")
    return sq_sum / float(n)


@torch.no_grad()
def eval_fixed_plan(model, lib, plan, normalizer, device, chunk=65536):
    total_sse = np.zeros(2, dtype=np.float64)
    total_n = 0
    for start in range(0, plan.n, chunk):
        sl = slice(start, min(start + chunk, plan.n))
        sub = type(plan)(plan.case_idx[sl], plan.time_idx[sl], plan.node_idx[sl])
        b, t, y = lib.arrays_from_plan(sub, normalizer)
        pred = model(_tensorize(b, device), _tensorize(t, device)).detach().cpu().numpy().astype(np.float64)
        diff = pred - y.astype(np.float64)
        total_sse += np.sum(diff * diff, axis=0, dtype=np.float64)
        total_n += len(diff)
    mse = total_sse / float(total_n)
    return {"combined": float(np.sum(mse)), "pressure_head": float(mse[0]), "concentration": float(mse[1])}


def adapt_model(model, source_lib, support_lib, source_train_idx, support_idx, normalizer, cfg, out_dir, device):
    trainable_names = model.freeze_branch_last_fusion()
    if not trainable_names:
        raise RuntimeError("Freeze policy opened no trainable parameters.")
    theta0 = {n: p.detach().clone() for n, p in model.named_parameters() if p.requires_grad}
    trainable = [p for p in model.parameters() if p.requires_grad]
    optimizer = torch.optim.AdamW(trainable, lr=cfg.learning_rate, weight_decay=cfg.weight_decay)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode="min", factor=cfg.scheduler_factor,
        patience=cfg.scheduler_patience, min_lr=cfg.scheduler_min_lr,
    )

    if cfg.replay_samples_per_epoch % cfg.batch_size != 0 or cfg.target_samples_per_epoch % cfg.batch_size != 0:
        raise ValueError("Replay/target samples per epoch must be divisible by BATCH_SIZE for the retained paired-batch protocol.")
    nsteps_r = cfg.replay_samples_per_epoch // cfg.batch_size
    nsteps_t = cfg.target_samples_per_epoch // cfg.batch_size
    if nsteps_r != nsteps_t:
        raise ValueError("Retained protocol requires equal replay and target batch counts per epoch.")

    # Deterministic monitoring plans. Common evaluation cases are never used here.
    source_val_idx = source_lib.split_indices("validation")
    src_val_plan = source_lib.make_fixed_plan(source_val_idx, cfg.source_val_points, cfg.validation_seed)
    tgt_val_plan = support_lib.make_fixed_plan(support_idx, cfg.target_cal_val_points, cfg.validation_seed + 1)

    write_json(out_dir / "trainable_parameters.json", {
        "policy": "branch_last_fusion",
        "trainable_parameter_names": trainable_names,
        "n_trainable_scalars": int(sum(p.numel() for p in trainable)),
        "n_total_scalars": int(sum(p.numel() for p in model.parameters())),
    })
    write_json(out_dir / "validation_plan.json", {
        "source_validation_total_points": cfg.source_val_points,
        "target_calibration_validation_total_points": cfg.target_cal_val_points,
        "validation_seed": cfg.validation_seed,
        "checkpoint_score": "source_validation_combined_normalized_MSE + target_calibration_combined_normalized_MSE",
        "common_eval_used_for_checkpoint_selection": False,
    })

    history = []
    best_score = float("inf")
    best_epoch = 0
    best_state = None
    start_all = time.perf_counter()

    for epoch in range(1, cfg.max_epochs + 1):
        model.train()
        rng = np.random.default_rng(cfg.seed + epoch * 10007)
        sums = np.zeros(6, dtype=np.float64)  # total,replay,target,sp,psi,C
        t0 = time.perf_counter()
        for _ in range(nsteps_r):
            rp = source_lib.sample_plan(source_train_idx, cfg.batch_size, rng)
            tp = support_lib.sample_plan(support_idx, cfg.batch_size, rng)
            rb, rt, ry = source_lib.arrays_from_plan(rp, normalizer)
            tb, tt, ty = support_lib.arrays_from_plan(tp, normalizer)

            rb, rt, ry = _tensorize(rb, device), _tensorize(rt, device), _tensorize(ry, device)
            tb, tt, ty = _tensorize(tb, device), _tensorize(tt, device), _tensorize(ty, device)
            optimizer.zero_grad(set_to_none=True)
            pr = model(rb, rt)
            pt = model(tb, tt)
            l_replay, replay_o = equal_output_field_loss(pr, ry)
            l_target, target_o = equal_output_field_loss(pt, ty)
            l_sp = sp_loss(model, theta0)
            loss = l_replay + cfg.lambda_target * l_target + cfg.lambda_sp * l_sp
            loss.backward()
            torch.nn.utils.clip_grad_norm_(trainable, cfg.grad_clip_norm)
            optimizer.step()

            sums[0] += float(loss.detach().cpu())
            sums[1] += float(l_replay.detach().cpu())
            sums[2] += float(l_target.detach().cpu())
            sums[3] += float(l_sp.detach().cpu())
            sums[4] += float((replay_o[0] + cfg.lambda_target*target_o[0]).detach().cpu())
            sums[5] += float((replay_o[1] + cfg.lambda_target*target_o[1]).detach().cpu())
        sums /= nsteps_r
        row = {
            "epoch": epoch,
            "train_total": sums[0], "train_replay": sums[1], "train_target": sums[2], "train_sp": sums[3],
            "train_pressure_component": sums[4], "train_concentration_component": sums[5],
            "lr": optimizer.param_groups[0]["lr"], "epoch_train_time_s": time.perf_counter() - t0,
            "source_val": "", "target_cal_val": "", "checkpoint_score": "", "is_best": 0,
        }

        if epoch % cfg.val_every_epochs == 0:
            model.eval()
            sv = eval_fixed_plan(model, source_lib, src_val_plan, normalizer, device, chunk=cfg.inference_batch_size)
            tv = eval_fixed_plan(model, support_lib, tgt_val_plan, normalizer, device, chunk=cfg.inference_batch_size)
            score = sv["combined"] + tv["combined"]
            row["source_val"] = sv["combined"]
            row["target_cal_val"] = tv["combined"]
            row["checkpoint_score"] = score
            scheduler.step(score)
            if score < best_score:
                best_score = score
                best_epoch = epoch
                best_state = copy.deepcopy(model.state_dict())
                row["is_best"] = 1
                torch.save({"epoch": epoch, "model_state_dict": best_state, "checkpoint_score": score}, out_dir / "best.pt")
        history.append(row)

        msg = f"Epoch {epoch:04d}: total={sums[0]:.6e}, replay={sums[1]:.6e}, target={sums[2]:.6e}, sp={sums[3]:.3e}, lr={optimizer.param_groups[0]['lr']:.3e}"
        if row["checkpoint_score"] != "":
            msg += f", val_score={float(row['checkpoint_score']):.6e}" + (" [best]" if row["is_best"] else "")
        print(msg, flush=True)

        if best_epoch > 0 and (epoch - best_epoch) >= cfg.early_stopping_patience_epochs:
            print(f"Early stopping at epoch {epoch}; best_epoch={best_epoch}, best_score={best_score:.6e}")
            break

    torch.save({"epoch": history[-1]["epoch"], "model_state_dict": model.state_dict()}, out_dir / "last.pt")
    if best_state is None:
        raise RuntimeError("No best adaptation checkpoint was created.")
    model.load_state_dict(best_state, strict=True)

    with (out_dir / "training_history.csv").open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(history[0].keys()))
        w.writeheader(); w.writerows(history)
    summary = {
        "best_epoch": best_epoch,
        "best_checkpoint_score": best_score,
        "epochs_completed": history[-1]["epoch"],
        "max_epochs": cfg.max_epochs,
        "training_wall_time_s": time.perf_counter() - start_all,
        "replay_samples_per_epoch": cfg.replay_samples_per_epoch,
        "target_samples_per_epoch": cfg.target_samples_per_epoch,
        "batch_size_per_replay_or_target_stream": cfg.batch_size,
        "paired_optimizer_steps_per_epoch": nsteps_r,
        "lambda_target": cfg.lambda_target,
        "lambda_sp": cfg.lambda_sp,
        "weight_decay": cfg.weight_decay,
        "common_eval_used_for_checkpoint_selection": False,
    }
    write_json(out_dir / "training_summary.json", summary)
    return model, summary

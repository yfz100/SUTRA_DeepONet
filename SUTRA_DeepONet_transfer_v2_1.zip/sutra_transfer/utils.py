from __future__ import annotations

import csv
import hashlib
import json
import os
import random
from dataclasses import asdict, is_dataclass
from pathlib import Path
from typing import Any, Iterable

import numpy as np


def set_global_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    try:
        import torch
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
    except Exception:
        pass


def resolve_device(requested: str):
    import torch
    r = str(requested).lower()
    if r == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if r.startswith("cuda") and not torch.cuda.is_available():
        raise RuntimeError(f"Requested device {requested!r}, but CUDA is unavailable.")
    return torch.device(requested)


def ensure_empty_or_create(path: Path, overwrite: bool) -> None:
    import shutil
    if path.exists():
        if not overwrite:
            raise FileExistsError(
                f"Result directory already exists: {path}\n"
                "Set OVERWRITE_EXISTING=True only when intentional."
            )
        shutil.rmtree(path)
    path.mkdir(parents=True, exist_ok=False)


def jsonable(obj: Any) -> Any:
    if is_dataclass(obj):
        return jsonable(asdict(obj))
    if isinstance(obj, Path):
        return str(obj)
    if isinstance(obj, dict):
        return {str(k): jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [jsonable(v) for v in obj]
    if isinstance(obj, np.generic):
        return obj.item()
    # Runtime-only objects such as torch.device can enter the effective
    # configuration after device resolution.  Serialize them explicitly
    # instead of letting json.dumps fail.  Import torch lazily so this utility
    # remains usable in environments where torch is not yet imported.
    try:
        import torch
        if isinstance(obj, torch.device):
            return str(obj)
    except Exception:
        pass
    return obj


def write_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(jsonable(obj), ensure_ascii=False, indent=2), encoding="utf-8")


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            b = f.read(chunk_size)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def read_csv_rows(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def write_csv_rows(path: Path, rows: Iterable[dict], fieldnames: list[str] | None = None) -> None:
    rows = list(rows)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        if fieldnames is None:
            path.write_text("", encoding="utf-8")
            return
    if fieldnames is None:
        fieldnames = list(rows[0].keys())
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for row in rows:
            w.writerow({k: row.get(k, "") for k in fieldnames})


def natural_key(s: str):
    import re
    return [int(x) if x.isdigit() else x.lower() for x in re.split(r"(\d+)", s)]

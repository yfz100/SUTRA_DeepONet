from __future__ import annotations

from collections import OrderedDict
from pathlib import Path
from typing import Any

import torch
from torch import nn

from .model import make_model
from .utils import natural_key, sha256_file


def discover_checkpoint(source_run_dir: Path, explicit: Path | None = None) -> Path:
    if explicit is not None:
        p = Path(explicit)
        if not p.is_file():
            raise FileNotFoundError(f"Explicit source checkpoint not found: {p}")
        return p
    preferred = [
        source_run_dir / "checkpoints" / "best.pt",
        source_run_dir / "checkpoints" / "best.pth",
        source_run_dir / "best.pt",
        source_run_dir / "best.pth",
    ]
    for p in preferred:
        if p.is_file():
            return p
    cands = sorted(
        [*source_run_dir.rglob("*best*.pt"), *source_run_dir.rglob("*best*.pth")],
        key=lambda p: (len(p.parts), natural_key(str(p))),
    )
    if not cands:
        raise FileNotFoundError(
            f"No best checkpoint found under {source_run_dir}. "
            "Set SOURCE_CHECKPOINT explicitly in run_pipeline.py."
        )
    return cands[0]


def discover_normalizer(source_run_dir: Path, explicit: Path | None = None) -> Path:
    if explicit is not None:
        p = Path(explicit)
        if not p.is_file():
            raise FileNotFoundError(f"Explicit source normalizer not found: {p}")
        return p
    preferred = [source_run_dir / "normalizer.json"]
    for p in preferred:
        if p.is_file():
            return p
    cands = sorted(source_run_dir.rglob("normalizer*.json"), key=lambda p: natural_key(str(p)))
    if not cands:
        raise FileNotFoundError(
            f"No source normalizer JSON found under {source_run_dir}. "
            "Transfer v2.1 intentionally fails closed rather than refitting a target normalizer."
        )
    return cands[0]


def _is_tensor_dict(d: Any) -> bool:
    return isinstance(d, (dict, OrderedDict)) and bool(d) and all(torch.is_tensor(v) for v in d.values())


def extract_state_dict(payload: Any) -> OrderedDict[str, torch.Tensor]:
    if isinstance(payload, nn.Module):
        return OrderedDict(payload.state_dict())
    if _is_tensor_dict(payload):
        return OrderedDict(payload)
    if isinstance(payload, dict):
        for key in ("model_state_dict", "state_dict", "model", "net", "network_state_dict", "model_state"):
            if key in payload:
                v = payload[key]
                if isinstance(v, nn.Module):
                    return OrderedDict(v.state_dict())
                if _is_tensor_dict(v):
                    return OrderedDict(v)
    raise TypeError("Could not locate a model state_dict in the source checkpoint payload.")


def _linear_records(state: OrderedDict[str, torch.Tensor]):
    records = []
    for k, v in state.items():
        if torch.is_tensor(v) and v.ndim == 2 and k.endswith("weight"):
            prefix = k[:-len("weight")]
            bk = prefix + "bias"
            bias = state.get(bk, None)
            records.append({"weight_key": k, "bias_key": bk if torch.is_tensor(bias) else None,
                            "weight": v, "bias": bias})
    return records


def _find_chain(records, expected_shapes):
    """Greedy order-preserving match by Linear weight shape; fail if impossible."""
    out = []
    pos = 0
    for shape in expected_shapes:
        found = None
        for i in range(pos, len(records)):
            if tuple(records[i]["weight"].shape) == tuple(shape):
                found = i
                break
        if found is None:
            return None
        out.append(records[found])
        pos = found + 1
    return out


def infer_layout(state: OrderedDict[str, torch.Tensor], cfg) -> str:
    records = _linear_records(state)
    b_last = int(cfg.output_dim * cfg.latent_dim)
    packed_branch_final = (b_last, int(cfg.branch_hidden[-1]))
    packed_trunk_final = (b_last, int(cfg.trunk_hidden[-1]))
    shapes = [tuple(r["weight"].shape) for r in records]
    if packed_branch_final in shapes and packed_trunk_final in shapes:
        return "packed_terminal"
    split_branch_head = (int(cfg.latent_dim), int(cfg.branch_hidden[-1]))
    # At least output_dim branch terminal heads of this shape.
    if sum(s == split_branch_head for s in shapes) >= int(cfg.output_dim):
        return "split_terminal_heads"
    raise RuntimeError(
        "Source checkpoint architecture could not be identified as the canonical packed or split-head "
        "two-output DeepONet. Linear weight shapes found: " + str(shapes)
    )


def _target_linear_lists(model):
    return model.branch_linear_modules(), model.trunk_linear_modules()


def _expected_shapes(model):
    b, t = _target_linear_lists(model)
    return [tuple(m.weight.shape) for m in b], [tuple(m.weight.shape) for m in t]


def _candidate_role_records(records, role: str):
    tagged = [r for r in records if role in r["weight_key"].lower()]
    return tagged if tagged else records


def _copy_linear_chain(target_modules, source_records, role_name: str, mapping: list[dict]):
    if len(target_modules) != len(source_records):
        raise RuntimeError(f"{role_name} linear count mismatch: target={len(target_modules)} source={len(source_records)}")
    with torch.no_grad():
        for i, (tm, sr) in enumerate(zip(target_modules, source_records)):
            if tuple(tm.weight.shape) != tuple(sr["weight"].shape):
                raise RuntimeError(
                    f"{role_name} layer {i} weight shape mismatch: target {tuple(tm.weight.shape)} "
                    f"vs source {tuple(sr['weight'].shape)} ({sr['weight_key']})"
                )
            tm.weight.copy_(sr["weight"].to(dtype=tm.weight.dtype, device=tm.weight.device))
            if tm.bias is not None:
                if sr["bias"] is None or tuple(tm.bias.shape) != tuple(sr["bias"].shape):
                    raise RuntimeError(f"Missing/incompatible bias for source linear module {sr['weight_key']}")
                tm.bias.copy_(sr["bias"].to(dtype=tm.bias.dtype, device=tm.bias.device))
            mapping.append({"target": f"{role_name}.linear[{i}]", "source_weight": sr["weight_key"],
                            "source_bias": sr["bias_key"], "shape": list(tm.weight.shape)})


def _find_output_bias(state, output_dim: int):
    candidates = []
    for k, v in state.items():
        if torch.is_tensor(v) and v.ndim == 1 and tuple(v.shape) == (output_dim,):
            candidates.append((k, v))
    if not candidates:
        return None
    # Prefer explicit output bias names, then bias-like names, then the unique candidate.
    candidates.sort(key=lambda kv: (
        0 if ("output" in kv[0].lower() and "bias" in kv[0].lower()) else
        1 if "bias" in kv[0].lower() else 2,
        natural_key(kv[0])
    ))
    return candidates[0]


def load_canonical_source_model(checkpoint_path: Path, cfg, device):
    payload = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
    state = extract_state_dict(payload)
    layout = infer_layout(state, cfg)
    model = make_model(
        layout,
        branch_dim=2,
        trunk_dim=7,
        branch_hidden=cfg.branch_hidden,
        trunk_hidden=cfg.trunk_hidden,
        latent_dim=cfg.latent_dim,
        output_dim=cfg.output_dim,
        activation=cfg.activation,
    ).to(device)

    # Architecture-level shape mapping. It is intentionally fail-closed: no silent partial loading.
    records = _linear_records(state)
    bmods, tmods = _target_linear_lists(model)
    bshapes, tshapes = _expected_shapes(model)

    # First try semantically tagged branch/trunk records; if naming differs, use all records and shape chain.
    bchain = _find_chain(_candidate_role_records(records, "branch"), bshapes)
    if bchain is None:
        bchain = _find_chain(records, bshapes)
    tchain = _find_chain(_candidate_role_records(records, "trunk"), tshapes)
    if tchain is None:
        tchain = _find_chain(records, tshapes)
    if bchain is None or tchain is None:
        raise RuntimeError(
            "Checkpoint tensors do not match the canonical v2.1 DeepONet architecture. "
            f"Expected branch shapes={bshapes}, trunk shapes={tshapes}."
        )

    mapping = []
    _copy_linear_chain(bmods, bchain, "branch", mapping)
    _copy_linear_chain(tmods, tchain, "trunk", mapping)
    ob = _find_output_bias(state, cfg.output_dim)
    if ob is None:
        raise RuntimeError("Could not identify the two-component output bias in the source checkpoint.")
    with torch.no_grad():
        model.output_bias.copy_(ob[1].to(dtype=model.output_bias.dtype, device=device))
    mapping.append({"target": "output_bias", "source": ob[0], "shape": list(model.output_bias.shape)})

    # Finite sanity check after full mapping.
    for n, p in model.named_parameters():
        if not torch.isfinite(p).all():
            raise RuntimeError(f"Non-finite parameter after checkpoint load: {n}")

    epoch = None
    if isinstance(payload, dict):
        for key in ("epoch", "best_epoch", "checkpoint_epoch"):
            if key in payload and isinstance(payload[key], (int, float)):
                epoch = int(payload[key]); break
    report = {
        "checkpoint": str(checkpoint_path),
        "checkpoint_sha256": sha256_file(checkpoint_path),
        "detected_layout": layout,
        "checkpoint_epoch_if_present": epoch,
        "mapping": mapping,
    }
    return model, report

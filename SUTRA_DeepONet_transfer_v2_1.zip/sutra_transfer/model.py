from __future__ import annotations

from typing import Sequence

import torch
from torch import nn


def activation_module(name: str) -> nn.Module:
    n = name.lower()
    if n == "silu":
        return nn.SiLU()
    if n == "tanh":
        return nn.Tanh()
    if n == "relu":
        return nn.ReLU()
    raise ValueError(f"Unsupported activation: {name}")


def _mlp(in_dim: int, hidden: Sequence[int], out_dim: int, activation: str) -> nn.Sequential:
    dims = [in_dim, *hidden, out_dim]
    mods: list[nn.Module] = []
    for i, (din, dout) in enumerate(zip(dims[:-1], dims[1:])):
        mods.append(nn.Linear(din, dout))
        if i < len(dims) - 2:
            mods.append(activation_module(activation))
    return nn.Sequential(*mods)


def linear_layers(seq: nn.Sequential) -> list[nn.Linear]:
    return [m for m in seq.modules() if isinstance(m, nn.Linear)]


class PackedMultiOutputDeepONet(nn.Module):
    """Shared hidden branch/trunk MLPs with packed output-specific terminal latent blocks."""
    layout = "packed_terminal"

    def __init__(
        self,
        branch_dim=2,
        trunk_dim=7,
        branch_hidden=(128, 128, 128),
        trunk_hidden=(256, 256, 256, 256),
        latent_dim=256,
        output_dim=2,
        activation="silu",
    ):
        super().__init__()
        self.branch_dim = int(branch_dim)
        self.trunk_dim = int(trunk_dim)
        self.latent_dim = int(latent_dim)
        self.output_dim = int(output_dim)
        self.branch_net = _mlp(branch_dim, branch_hidden, output_dim * latent_dim, activation)
        self.trunk_net = _mlp(trunk_dim, trunk_hidden, output_dim * latent_dim, activation)
        self.output_bias = nn.Parameter(torch.zeros(output_dim))

    def forward(self, branch_x: torch.Tensor, trunk_x: torch.Tensor) -> torch.Tensor:
        b = self.branch_net(branch_x).reshape(-1, self.output_dim, self.latent_dim)
        t = self.trunk_net(trunk_x).reshape(-1, self.output_dim, self.latent_dim)
        return torch.sum(b * t, dim=-1) + self.output_bias

    def branch_linear_modules(self) -> list[nn.Linear]:
        return linear_layers(self.branch_net)

    def trunk_linear_modules(self) -> list[nn.Linear]:
        return linear_layers(self.trunk_net)

    def freeze_branch_last_fusion(self) -> list[str]:
        for p in self.parameters():
            p.requires_grad = False
        bl = self.branch_linear_modules()
        if len(bl) < 2:
            raise RuntimeError("Branch network has fewer than two linear layers.")
        for layer in bl[-2:]:
            for p in layer.parameters():
                p.requires_grad = True
        self.output_bias.requires_grad = True
        return [n for n, p in self.named_parameters() if p.requires_grad]


class SplitHeadMultiOutputDeepONet(nn.Module):
    """Shared hidden branch/trunk MLPs plus separate terminal latent heads per output."""
    layout = "split_terminal_heads"

    def __init__(
        self,
        branch_dim=2,
        trunk_dim=7,
        branch_hidden=(128, 128, 128),
        trunk_hidden=(256, 256, 256, 256),
        latent_dim=256,
        output_dim=2,
        activation="silu",
    ):
        super().__init__()
        if not branch_hidden or not trunk_hidden:
            raise ValueError("Split-head layout requires non-empty hidden layer lists.")
        self.branch_dim = int(branch_dim)
        self.trunk_dim = int(trunk_dim)
        self.latent_dim = int(latent_dim)
        self.output_dim = int(output_dim)
        self.branch_shared = _mlp(branch_dim, branch_hidden[:-1], branch_hidden[-1], activation)
        self.trunk_shared = _mlp(trunk_dim, trunk_hidden[:-1], trunk_hidden[-1], activation)
        self.branch_heads = nn.ModuleList([nn.Linear(branch_hidden[-1], latent_dim) for _ in range(output_dim)])
        self.trunk_heads = nn.ModuleList([nn.Linear(trunk_hidden[-1], latent_dim) for _ in range(output_dim)])
        self.output_bias = nn.Parameter(torch.zeros(output_dim))

    def forward(self, branch_x: torch.Tensor, trunk_x: torch.Tensor) -> torch.Tensor:
        hb = self.branch_shared(branch_x)
        ht = self.trunk_shared(trunk_x)
        ys = []
        for i in range(self.output_dim):
            ys.append(torch.sum(self.branch_heads[i](hb) * self.trunk_heads[i](ht), dim=-1))
        return torch.stack(ys, dim=-1) + self.output_bias

    def branch_linear_modules(self) -> list[nn.Linear]:
        return linear_layers(self.branch_shared) + list(self.branch_heads)

    def trunk_linear_modules(self) -> list[nn.Linear]:
        return linear_layers(self.trunk_shared) + list(self.trunk_heads)

    def freeze_branch_last_fusion(self) -> list[str]:
        for p in self.parameters():
            p.requires_grad = False
        # "last two branch linear stages" = last shared branch linear layer + terminal output heads.
        shared = linear_layers(self.branch_shared)
        for p in shared[-1].parameters():
            p.requires_grad = True
        for head in self.branch_heads:
            for p in head.parameters():
                p.requires_grad = True
        self.output_bias.requires_grad = True
        return [n for n, p in self.named_parameters() if p.requires_grad]


def make_model(layout: str, **kwargs) -> nn.Module:
    if layout == "packed_terminal":
        return PackedMultiOutputDeepONet(**kwargs)
    if layout == "split_terminal_heads":
        return SplitHeadMultiOutputDeepONet(**kwargs)
    raise ValueError(f"Unknown model layout: {layout}")

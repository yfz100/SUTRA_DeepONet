from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
import torch

from .metrics import METRIC_NAMES, metrics_1d
from .utils import sha256_file, write_csv_rows, write_json


@torch.no_grad()
def predict_full_case(model, lib, case_idx: int, normalizer, device, batch_size: int):
    b, t = lib.full_case_query(case_idx, normalizer)
    out = np.empty((len(b), 2), dtype=np.float32)
    model.eval()
    for start in range(0, len(b), batch_size):
        end = min(start + batch_size, len(b))
        bt = torch.as_tensor(b[start:end], dtype=torch.float32, device=device)
        tt = torch.as_tensor(t[start:end], dtype=torch.float32, device=device)
        out[start:end] = model(bt, tt).detach().cpu().numpy().astype(np.float32)
    out = normalizer.denormalize_target(out)
    return out.reshape(lib.nt, lib.nnode, 2)


def evaluate_common(model, lib, eval_idx, normalizer, cfg, out_dir: Path, protocol_name: str, checkpoint_info: dict):
    eval_idx = np.asarray(eval_idx, dtype=np.int64)
    preds = np.empty((len(eval_idx), lib.nt, lib.nnode, 2), dtype=np.float32)
    per_case_rows = []
    all_true = [[], []]
    all_pred = [[], []]

    for j, ci in enumerate(eval_idx):
        pred = predict_full_case(model, lib, int(ci), normalizer, cfg.device_obj, cfg.inference_batch_size)
        true = lib.full_case_true(int(ci))
        preds[j] = pred
        row_meta = lib.meta[int(ci)]
        for oi, field in enumerate(("pressure_head_m", "concentration")):
            m = metrics_1d(true[..., oi], pred[..., oi])
            row = {
                "protocol": protocol_name,
                "case_id": row_meta["case_id"],
                "amplitude_m": float(row_meta["amplitude_m"]),
                "h_land_m": float(row_meta["h_land_m"]),
                "field": field,
                **m,
            }
            per_case_rows.append(row)
            all_true[oi].append(np.asarray(true[..., oi], dtype=np.float64).reshape(-1))
            all_pred[oi].append(np.asarray(pred[..., oi], dtype=np.float64).reshape(-1))
        print(f"[{protocol_name}] evaluated A={float(row_meta['amplitude_m']):.2f}, H={float(row_meta['h_land_m']):.2f}")

    pooled_rows = []
    for oi, field in enumerate(("pressure_head_m", "concentration")):
        yt = np.concatenate(all_true[oi]); yp = np.concatenate(all_pred[oi])
        pooled_rows.append({"protocol": protocol_name, "field": field, **metrics_1d(yt, yp)})

    write_csv_rows(out_dir / "metrics_per_case.csv", per_case_rows)
    write_csv_rows(out_dir / "metrics_pooled.csv", pooled_rows)

    eval_meta = []
    for new_i, ci in enumerate(eval_idx):
        r = dict(lib.meta[int(ci)])
        r["eval_index"] = new_i
        eval_meta.append(r)
    write_csv_rows(out_dir / "common_eval_case_metadata.csv", eval_meta)

    if cfg.save_common_eval_predictions:
        np.save(out_dir / "pred_pressure_head_m.npy", preds[..., 0])
        np.save(out_dir / "pred_concentration.npy", preds[..., 1])

    meta = {
        "protocol": protocol_name,
        "evaluation_role": "common_withheld_for_testing_target_evaluation",
        "common_eval_amplitudes_m": list(cfg.common_eval_amplitudes_m),
        "target_h_land_m": cfg.target_h_land_m,
        "prediction_axis_order": ["case", "time", "node"],
        "target_order": list(cfg.target_order),
        "checkpoint": checkpoint_info,
        "common_eval_used_for_training_or_checkpoint_selection": False,
    }
    write_json(out_dir / "evaluation_metadata.json", meta)
    return per_case_rows, pooled_rows

#!/usr/bin/env python3
from __future__ import annotations

import json
import tempfile
from pathlib import Path
import sys

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from sutra_transfer.model import PackedMultiOutputDeepONet, SplitHeadMultiOutputDeepONet
from sutra_transfer.checkpoint import load_canonical_source_model
from sutra_transfer.normalizer import SourceNormalizer
from sutra_transfer.utils import write_json


class Cfg:
    output_dim=2; latent_dim=256
    branch_hidden=(128,128,128); trunk_hidden=(256,256,256,256)
    activation="silu"


def main():
    # Regression: runtime torch.device must be serializable in effective_config.
    with tempfile.TemporaryDirectory() as td:
        p = Path(td) / "device.json"
        write_json(p, {"device": torch.device("cpu")})
        assert json.loads(p.read_text(encoding="utf-8"))["device"] == "cpu"

    torch.manual_seed(7)
    model = PackedMultiOutputDeepONet()
    with tempfile.TemporaryDirectory() as td:
        p = Path(td)/"best.pt"
        torch.save({"epoch": 485, "model_state_dict": model.state_dict()}, p)
        loaded, report = load_canonical_source_model(p, Cfg(), torch.device("cpu"))
        x1 = torch.randn(11,2); x2 = torch.randn(11,7)
        with torch.no_grad():
            a=model(x1,x2); b=loaded(x1,x2)
        assert torch.allclose(a,b,atol=1e-7,rtol=0), (a-b).abs().max()
        names=loaded.freeze_branch_last_fusion()
        assert any("output_bias" in n for n in names)
        assert all("trunk" not in n for n in names)
        # Packed branch has four linears; only final two linear stages should be open.
        assert len(names) == 5, names  # weight+bias for 2 linears + output_bias
    # Also verify split-head layout detection/mapping.
    torch.manual_seed(8)
    split = SplitHeadMultiOutputDeepONet()
    with tempfile.TemporaryDirectory() as td:
        p = Path(td)/"best_split.pt"
        torch.save({"epoch": 485, "model_state_dict": split.state_dict()}, p)
        loaded, report = load_canonical_source_model(p, Cfg(), torch.device("cpu"))
        x1 = torch.randn(7,2); x2 = torch.randn(7,7)
        with torch.no_grad():
            a=split(x1,x2); b=loaded(x1,x2)
        assert report["detected_layout"] == "split_terminal_heads"
        assert torch.allclose(a,b,atol=1e-7,rtol=0), (a-b).abs().max()
        names=loaded.freeze_branch_last_fusion()
        assert all("trunk" not in n for n in names)
    print("Synthetic smoke test passed for packed and split-head layouts.")

if __name__ == "__main__":
    main()

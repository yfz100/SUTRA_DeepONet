# SUTRA_DeepONet_transfer_v2_1

> **v2.1.1 preflight fix (2026-10-06):** fixes resolved `torch.device` JSON serialization, strengthens source best-epoch provenance checking, and sanitizes malformed OpenMP thread-count environment variables. Scientific protocol unchanged.

这是 canonical v2.1 数据体系下的 **coupled pressure-head + concentration** 迁移学习代码包。它不是重新设计迁移方法，而是把此前已经采用的 data replay + few-shot + starting-point (SP) regularization + branch-last-fusion 机制接到新版 `[A, H_land]` branch 接口，并增加统一的 no-transfer / one-shot / two-shot 递进比较。

## 1. 固定试验协议

- source model：`SUTRA_DeepONet_pure_v2_1` 正式 supervised best checkpoint（默认检查 `best_epoch=485`）。
- branch：`[A, H_land]`。
- outputs：`[pressure_head_m, concentration]`。
- target landward head：`H_land=2.50 m`。
- no-transfer：不更新参数，直接用 source checkpoint。
- one-shot support：`A=0.70 m`。
- two-shot support：`A=0.70, 1.00 m`。
- 三者共同评价：`A=0.80, 0.90, 1.10, 1.20 m`。
- support 与 common evaluation 强制不重叠；代码在 preflight 中 fail closed。

## 2. 保留的旧 transfer 核心机制

适配目标：

`L = L_replay + 1.0 * L_target + 1e-4 * L_SP`

其中 pressure head 与 concentration 使用 source supervised model 的同一套 normalization statistics，各自标准化后以相同 nominal coefficient 进入 field loss。

冻结策略：

- trunk 全冻结；
- branch 早期层冻结；
- 仅 branch 最后两个 linear stages 与 output bias 更新；
- 不加入 PDE、BC、IC residual。

训练参数：

- AdamW；
- maximum 300 epochs；
- lr = `1e-4`；
- weight decay = `0`；
- replay = `262,144` samples/epoch；
- target = `262,144` samples/epoch；
- batch size = `8,192` per replay/target stream；
- gradient clipping = `1.0`。

checkpoint monitoring：每 5 epochs 计算 source validation normalized field loss 与 target support calibration normalized field loss，score 为两者之和；common evaluation cases 从不参与 checkpoint selection。ReduceLROnPlateau factor=0.5、patience=8、min_lr=1e-6；early-stopping patience=60 epochs。

## 3. 使用方法

1. 确认 canonical v2.1 reference library 位于 `/root/reference_library`；如路径不同，只改 `run_pipeline.py` 顶部参数区。
2. 确认 formal source run 路径；默认：
   `/root/SUTRA_DeepONet_pure_v2_1/runs/pure_supervised_v2_1_20261002_080051`。
3. 先执行：

```bash
python scripts/quick_check.py
```

4. 正式运行：

```bash
python run_pipeline.py
```

默认 `RUN_SELECTION="all"`，依次生成 no-transfer、one-shot、two-shot。也可在参数汇总区改为其中一个模式单独运行。

## 4. 结果目录

```text
runs/
├─ effective_config.json
├─ adaptation_manifest.csv
├─ preflight_report.json
├─ no_transfer_common_eval/
├─ one_shot_A0.70/
├─ two_shot_A0.70_A1.00/
└─ comparison_common_eval/
```

每个 adaptation 目录保存 `best.pt`、`last.pt`、training history、protocol、validation plan、common-evaluation metrics；若开启预测保存，还会输出 pressure-head / concentration prediction arrays。

## 5. 关键防泄漏规则

- replay 只从 source `train` cases 抽样；source split 以 canonical manifest 为 authority。
- higher-amplitude data 不重新拟合 normalizer。
- one-/two-shot support 与 common evaluation cases 强制隔离。
- common evaluation 只在训练完成并加载 best checkpoint 后执行，不参与 optimizer、scheduler、early stopping 或 checkpoint selection。

## 6. Checkpoint 兼容性

source checkpoint 的文件名可自动发现，也可在 `run_pipeline.py` 指定。loader 支持 canonical packed terminal latent layout 和等价的 split terminal-head layout，并按网络线性层 shape/order 完整映射；任何缺失或形状不一致都会报错退出，不进行 silent partial load。
